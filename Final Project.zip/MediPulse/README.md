# MediPulse - AI-Powered Hospital Management & Analytics Platform

A full-stack hospital management system (React + Node) with a real **SQL database (SQLite)**,
a machine-learning prediction service (Python + scikit-learn), an AI assistant and live
analytics reports. Every number on every page is calculated from the same database.

```
   React frontend (Vite) :5173
            |
            v
   Node/Express API :5000 ------ /predict (sends the hospital's last 14 days) ----> Python ML service :8000
            |                                                                         (trained Random Forest)
            v
   SQLite database  server/data/medipulse.sqlite
   departments - doctors - patients - beds - admissions - appointments - labs - prescriptions - records
```

## Project structure

```
Project/
  frontend/          React app (doctor portal + patient portal)
  server/            Node/Express API
    database.js        SQLite connection, tables, constraints and triggers
    store.js           all queries and business rules (validation, admissions, dashboard, reports data)
    simulator.js       creates the demo hospital and keeps its activity up to date
    analytics.js       predictions, reports and AI assistant endpoints
    db-reset.js        npm run db:reset   -> brand-new consistent database
    db-check.js        npm run db:check   -> database health report
    legacy-db.json     the original hand-written data file (kept for reference, no longer used)
  ml/                Python ML pipeline
    generate_dataset.py   synthetic training dataset for THIS hospital (38 beds, 7 departments)
    features.py / train_model.py / predict_api.py
    data/ , models/
  docker-compose.yml  runs frontend + backend + ML API together
  branding/          logo PNG / SVG
```

## Running in VS Code (without Docker)

**Install once:**
* [Node.js 22.13 or newer](https://nodejs.org) (22 LTS recommended - the database uses Node's built-in SQLite)
* [Python 3.11+](https://www.python.org/downloads/) - tick "Add python.exe to PATH" in the installer
* [VS Code](https://code.visualstudio.com)

**1. Open the project:** VS Code -> *File -> Open Folder...* -> select the **`Project`** folder
(the one that contains `frontend`, `server`, `ml` and `docker-compose.yml`).

**2. Install dependencies (first time only).** Open *Terminal -> New Terminal* and run:
```bash
cd ml && pip install -r requirements.txt && cd ..
cd server && npm install && cd ..
cd frontend && npm install && cd ..
```
(If `pip` is not recognised on Windows use `py -m pip install -r requirements.txt`.
If PowerShell blocks scripts, run `Set-ExecutionPolicy -Scope Process Bypass` first.)

**3. Start everything - easiest way:** press `Ctrl+Shift+P` -> **Tasks: Run Task** ->
**Start MediPulse (all 3 services)**. Three terminals open (ML API, Backend, Frontend).

**...or start them manually in 3 terminals:**

| Terminal | Commands | Runs at |
|---|---|---|
| 1 - ML API | `cd ml` then `python predict_api.py` (Windows alternative: `py predict_api.py`) | http://localhost:8000 |
| 2 - Backend | `cd server` then `node index.js` | http://localhost:5000 |
| 3 - Frontend | `cd frontend` then `npm run dev` | http://localhost:5173 |

**4. Open http://localhost:5173** and log in with `doctor` / `doctor123` (doctor portal) or
`diksha` / `diksha123` (patient portal). Stop a service with `Ctrl+C` in its terminal.

The **first time the backend starts** it creates the database and fills it with a consistent demo
hospital (about 360 patients, 14 doctors, 38 beds, 15 days of activity). This takes about a second.

> The app still works if the ML service is not running: Predictions shows a clear
> error with a Retry button, Reports leaves out the prediction report, and the
> AI Assistant answers from live hospital data and says forecasts are unavailable.

## Running with Docker

Install [Docker Desktop](https://www.docker.com/products/docker-desktop/) and make sure it is running,
then from the `Project` folder (in a VS Code terminal):

| Task | Command |
|---|---|
| Build and start everything | `docker compose up --build` |
| Check container status / health | `docker compose ps` |
| View logs (all / one service) | `docker compose logs -f` / `docker compose logs -f backend` (or `ml`, `frontend`) |
| Stop (data is kept) | `docker compose down` |
| Stop and DELETE the database (fresh demo data next start) | `docker compose down -v` |
| Rebuild after code changes | `docker compose up --build` |

| Service | URL |
|---|---|
| Website (frontend) | http://localhost:5173 |
| Backend health check | http://localhost:5000/api/health |
| Database overview + consistency checks | http://localhost:5000/api/db/overview |
| ML API health check | http://localhost:8000/health |

* The database lives in the Docker volume `medipulse-data`, so your data survives restarts and rebuilds.
* To inspect it with a database viewer: `docker compose cp backend:/app/data/medipulse.sqlite .`
  and open the file with the VS Code extension **SQLite Viewer** or *DB Browser for SQLite*.
* Optional: copy `.env.example` to `.env` and set `ANTHROPIC_API_KEY` to use Claude in the AI Assistant.
* Docker and the plain commands above can both be used, but not at the same time (same ports).

## The database

MediPulse uses **SQLite**, a real relational SQL database stored in one file
(`server/data/medipulse.sqlite`). It needs no installation: it uses the SQLite engine built into Node.js 22.

```
departments 1---* doctors
departments 1---* patients ---* appointments *---1 doctors
patients    1---* admissions *---1 beds *---1 departments
patients    1---* labs / prescriptions / records
users       1---1 patients (patient logins)   |   passwords are stored as salted scrypt hashes
```

**Why the numbers always agree** - the database itself enforces the rules, not only the app:

* An admission must point to a real patient, doctor and bed (foreign keys).
* A bed holds at most one admitted patient and a patient occupies at most one bed (unique indexes).
* Admitting a patient automatically marks the bed *Occupied* and the patient *Admitted*;
  discharging frees the bed and marks the patient *Discharged* (triggers).
* A bed cannot be marked *Occupied* without a patient, or freed while its patient is still admitted.
* Appointments need a registered patient and a doctor from the same department, and a doctor cannot be double-booked.
* Dashboard, Beds, Admissions, Departments, Reports, AI Assistant and Predictions all read these same tables,
  and department / doctor / patient counts are calculated, never typed in.
  The Predictions page "Actual" line is exactly the Dashboard's weekly patient flow.

**Useful commands** (run inside `server/`):

| Command | What it does |
|---|---|
| `npm run db:check` | prints row counts and runs 9 consistency checks (all must PASS) |
| `npm run db:reset` | deletes the database and creates a fresh demo hospital |

**Demo activity:** each time the backend starts it continues the simulated hospital activity for the
days that have passed (visits, admissions, discharges), so the charts and predictions never go stale,
even if you open the project days later. Turn this off with the environment variable `SIMULATE_ACTIVITY=false`.

## Machine learning

**Pipeline:** training dataset -> feature engineering -> time-based train/test split -> model comparison ->
saved model -> prediction API -> React.

* **Training dataset** - synthetic daily records for this hospital (7 departments, 38 beds, about 40 visits a day,
  14,903 rows from 2021) with weekly and seasonal patterns and occasional surge events.
  Its hospital profile mirrors `server/simulator.js` (keep the two in sync).
* **Models** - two Random Forest regressors predicting next-day **bed occupancy (%)** and **patient visits** per department.
* **Live data from the database** - with every request the backend sends the hospital's last 14 days
  (visits, admissions, discharges, occupancy) straight from the database, and the current bed occupancy.
  The forecast therefore always reflects the real, current hospital. The first forecast day is "today";
  its occupancy is the real one, and "tomorrow" is predicted from it.
* **Charts** - "Actual" = real visits from the database; "Predicted" for past days = what the model
  would have predicted one day ahead (a live check on real data); the dashed part is the forecast.

Evaluation on a held-out test set (the most recent 120 days, never trained on):

| Target | Naive baseline R² | Linear Regression R² | **Random Forest R²** | RF error |
|---|---|---|---|---|
| Next-day patient visits (per department) | 0.878 | 0.915 | **0.927** | 0.65 visits |
| Next-day occupancy (%) | 0.487 | 0.573 | **0.580** | 10.7 pts |

Occupancy is harder to predict because each ward has only 4-8 beds, so one bed is 12-25%.
Full numbers: `ml/models/metrics.json`.

### Retraining
```bash
cd ml
python generate_dataset.py       # regenerates the training data
python train_model.py            # retrains and saves the model
```
Restart `predict_api.py` afterwards. (If the saved model cannot be loaded, for example after a
scikit-learn upgrade, the API retrains automatically on start-up.)

## AI Assistant

Works out of the box with a built-in engine over **live** database data and ML forecasts
(bed occupancy and availability, patient load, appointments, admissions, predictions, alerts,
per-department summaries). The header shows which mode answered.

To use a real LLM (Claude) instead: `cd server`, `cp .env.example .env`, and set `ANTHROPIC_API_KEY=`
(or put it in the root `.env` for Docker). Only aggregated statistics are sent - never patient names
or contact details. If the API call fails, the assistant falls back to the built-in engine.

## Reports

Real figures from the database, charts, and downloadable CSV files (operations, patients,
bed occupancy, appointments, admissions, ML predictions) plus a combined **Export Report**.

## Patient portal

Records, lab reports, prescriptions, health summary (vitals, last / next checkup) and the
activity feed all come from the database for the logged-in patient.

## Theme and logo

Teal + navy healthcare theme: primary teal `#0D9488`, dark teal `#0F766E`, light teal tints
`#E6F7F5` / `#F0FDFA` / `#CCFBF1`, navy `#0B2545` (sidebar and headings), accent navy `#1E3A5F`.
Success green, warning amber and danger red are kept for status meaning.
The logo (medical cross with a pulse line) lives in `frontend/src/components/Logo.jsx`,
`frontend/public/favicon.svg` and `frontend/public/logo.svg`; PNG exports for slides are in `branding/`.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | backend status |
| GET | `/api/db/overview` | tables, row counts and consistency checks |
| POST | `/api/login`, `/api/register` | authentication |
| GET | `/api/dashboard/stats` | dashboard numbers |
| GET/POST/DELETE | `/api/patients` | patients |
| GET/POST, PATCH `/:id/status` | `/api/appointments` | appointments (`?patient=` filter) |
| GET, PATCH `/:id` | `/api/beds` | beds |
| GET/POST, PATCH `/:id/discharge` | `/api/admissions` | admissions |
| GET | `/api/doctors`, `/api/departments` | doctors, departments (with live counts) |
| GET | `/api/labs`, `/api/prescriptions`, `/api/records` | patient documents (`?patient=` filter) |
| GET | `/api/predictions` | ML forecasts + alerts |
| GET | `/api/reports/summary` | data for the Reports page |
| POST | `/api/assistant` | `{ message, history }` -> `{ reply, source }` |
| POST | `:8000/predict` | ML service (called by the Node server) |

## Notes

* The demo data (patients, visits, admissions) is generated, not real. A real hospital's data would be
  loaded into the same tables.
* There are no login tokens: the frontend decides what to show per role. This is fine for a college
  demo but a production system needs proper session / token authentication.
* Passwords are hashed in the database; the demo accounts are `doctor` / `doctor123` and `diksha` / `diksha123`.
