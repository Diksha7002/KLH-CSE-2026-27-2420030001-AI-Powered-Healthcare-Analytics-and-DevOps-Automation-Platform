"""
MediPulse - Prediction API (Flask)
==================================

Loads the trained model and serves forecasts to the Node backend
(which in turn serves the React "Predictions", "Reports" and
"AI Assistant" pages).

The backend sends the hospital's recent history straight from the
DATABASE with every request, so forecasts are always based on the real,
current data. If no history is sent (e.g. when testing this API on its own)
the training dataset is used instead.

Run:
    python predict_api.py            # http://localhost:8000

Endpoints:
    GET  /health        -> service status
    GET  /model/info    -> training info + evaluation metrics
    POST /predict       -> multi-day forecast per department
         body (all optional):
         { "live_occupancy": {"ICU": 50.0, ...},   # current % from the live bed system
           "horizon": 3,                           # days to forecast (1-7)
           "history": [ {date, department, total_beds, occupied_beds, admissions,
                         discharges, emergency_cases, appointments, patient_visits,
                         average_stay, occupancy_rate}, ... ] }
"""

from datetime import datetime, timedelta

import joblib
import pandas as pd
from flask import Flask, jsonify, request

from features import DEPARTMENTS, FEATURE_COLUMNS, NUMERIC_FEATURES, build_features
from train_model import DATA_CSV, MODEL_PATH, train

app = Flask(__name__)

HISTORY_COLUMNS = [
    "date", "department", "total_beds", "occupied_beds", "admissions", "discharges",
    "emergency_cases", "appointments", "patient_visits", "average_stay", "occupancy_rate",
]
MIN_HISTORY_DAYS = 14


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


# ---------------------------------------------------------------------------
# Load (or train) model + fallback dataset once at start-up
# ---------------------------------------------------------------------------

def load_bundle():
    try:
        return joblib.load(MODEL_PATH)
    except Exception as exc:  # missing file or scikit-learn version mismatch
        print(f"Model not usable ({exc}). Training a fresh model...")
        train(verbose=False)
        return joblib.load(MODEL_PATH)


BUNDLE = load_bundle()
DATASET = pd.read_csv(DATA_CSV)
DATASET["date"] = pd.to_datetime(DATASET["date"])
DATASET_END = DATASET["date"].max()


class BadRequest(Exception):
    pass


def prepare_history(rows):
    """Validate and normalise history sent by the backend."""
    try:
        df = pd.DataFrame(rows)
        missing = [c for c in HISTORY_COLUMNS if c not in df.columns]
        if missing:
            raise BadRequest(f"history is missing columns: {', '.join(missing)}")
        df = df[HISTORY_COLUMNS].copy()
        df["date"] = pd.to_datetime(df["date"])
        numeric = [c for c in HISTORY_COLUMNS if c not in ("date", "department")]
        df[numeric] = df[numeric].astype(float)
    except BadRequest:
        raise
    except Exception as exc:
        raise BadRequest(f"history could not be read: {exc}")

    df = df.sort_values(["department", "date"]).reset_index(drop=True)
    counts = df.groupby("department").size()
    for dept in DEPARTMENTS:
        if counts.get(dept, 0) < MIN_HISTORY_DAYS:
            raise BadRequest(
                f"history needs at least {MIN_HISTORY_DAYS} days for every department "
                f"({dept} has {int(counts.get(dept, 0))})"
            )
    return df


# ---------------------------------------------------------------------------
# Forecasting
# ---------------------------------------------------------------------------

def predict_next(history_df):
    """Predict the day after the last row of history_df (one department)."""
    feats = build_features(history_df).dropna(subset=NUMERIC_FEATURES)
    row = feats.iloc[[-1]][FEATURE_COLUMNS]
    occ = float(BUNDLE["occupancy"].predict(row)[0])
    visits = float(BUNDLE["visits"].predict(row)[0])
    return min(max(occ, 0.0), 100.0), max(visits, 0.0)


def forecast_department(history, dept, horizon, live_pct=None):
    hist = history[history["department"] == dept].sort_values("date").tail(30).copy()
    beds = int(hist["total_beds"].iloc[-1])

    last7 = hist.tail(7)
    prev7 = hist.tail(14).head(7)
    recent_visits = float(last7["patient_visits"].mean())

    out = []
    for step in range(1, horizon + 1):
        occ, visits = predict_next(hist)
        # The first forecast day is "today": the real bed occupancy is already
        # known, so it replaces the prediction and drives the following days.
        if step == 1 and live_pct is not None:
            occ = min(max(float(live_pct), 0.0), 100.0)

        next_date = hist["date"].iloc[-1] + timedelta(days=1)
        r = hist.tail(7)
        visits_sum = max(float(r["patient_visits"].sum()), 1.0)
        new_row = {
            "date": next_date,
            "department": dept,
            "total_beds": beds,
            "occupied_beds": occ / 100 * beds,
            "admissions": float(r["admissions"].mean()) * visits / (visits_sum / 7),
            "discharges": float(r["discharges"].mean()),
            "emergency_cases": float(r["emergency_cases"].sum()) / visits_sum * visits,
            "appointments": float(r["appointments"].sum()) / visits_sum * visits,
            "patient_visits": visits,
            "average_stay": float(r["average_stay"].mean()),
            "occupancy_rate": occ,
        }
        hist = pd.concat([hist, pd.DataFrame([new_row])], ignore_index=True)
        out.append(
            {
                "date": next_date.strftime("%Y-%m-%d"),
                "occupancy": round(occ, 1),
                "visits": int(round(visits)),
            }
        )

    return {
        "department": dept,
        "total_beds_history": beds,
        "recent_visits_avg": round(recent_visits, 1),
        "trend": {
            "visits_7d": round(float(last7["patient_visits"].mean()), 1),
            "visits_prev_7d": round(float(prev7["patient_visits"].mean()), 1),
            "emergency_7d": round(float(last7["emergency_cases"].mean()), 1),
            "emergency_prev_7d": round(float(prev7["emergency_cases"].mean()), 1),
        },
        "forecast": out,
    }


def model_estimates(history):
    """What the model would have predicted for each past day (one day ahead),
    summed over all departments - a live check of the model on real data."""
    feats = build_features(history).dropna(subset=NUMERIC_FEATURES)
    feats = feats.copy()
    feats["pred_visits"] = BUNDLE["visits"].predict(feats[FEATURE_COLUMNS])
    feats["target_date"] = feats["date"] + pd.Timedelta(days=1)
    grouped = feats.groupby("target_date").agg(
        total=("pred_visits", "sum"), departments=("department", "nunique")
    )
    grouped = grouped[grouped["departments"] == len(DEPARTMENTS)]
    return {d.strftime("%Y-%m-%d"): int(round(v)) for d, v in grouped["total"].items()}


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    return jsonify(
        {
            "status": "ok",
            "model_loaded": True,
            "training_data_through": DATASET_END.strftime("%Y-%m-%d"),
        }
    )


@app.get("/model/info")
def model_info():
    return jsonify(BUNDLE["info"])


@app.route("/predict", methods=["POST", "OPTIONS"])
def predict():
    if request.method == "OPTIONS":
        return ("", 204)

    body = request.get_json(silent=True) or {}
    live = body.get("live_occupancy") or {}
    try:
        horizon = int(body.get("horizon", 3))
    except (TypeError, ValueError):
        return jsonify({"message": "horizon must be a number between 1 and 7"}), 400
    if not 1 <= horizon <= 7:
        return jsonify({"message": "horizon must be between 1 and 7"}), 400

    if body.get("history"):
        try:
            history = prepare_history(body["history"])
        except BadRequest as exc:
            return jsonify({"message": str(exc)}), 400
        source = "database"
    else:
        history = DATASET.copy()
        source = "training dataset"

    data_through = history["date"].max()
    departments = [
        forecast_department(history, d, horizon, live.get(d)) for d in DEPARTMENTS
    ]

    # Hospital-wide totals: last 7 observed days + forecast days
    daily = history.groupby("date")["patient_visits"].sum().tail(7).reset_index()
    estimates = model_estimates(history)
    history_totals = [
        {
            "date": r.date.strftime("%Y-%m-%d"),
            "visits": int(r.patient_visits),
            "model_estimate": estimates.get(r.date.strftime("%Y-%m-%d")),
        }
        for r in daily.itertuples()
    ]
    forecast_totals = [
        {
            "date": departments[0]["forecast"][i]["date"],
            "visits": sum(d["forecast"][i]["visits"] for d in departments),
        }
        for i in range(horizon)
    ]

    info = BUNDLE["info"]
    return jsonify(
        {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "data_through": data_through.strftime("%Y-%m-%d"),
            "history_source": source,
            "horizon": horizon,
            "departments": departments,
            "totals": {
                "history": history_totals,
                "forecast": forecast_totals,
                "recent_visits_avg": round(sum(d["recent_visits_avg"] for d in departments), 1),
            },
            "model": {
                "type": info["model_type"],
                "trained_at": info["trained_at"],
                "dataset_rows": info["dataset_rows"],
                "dataset_start": info["dataset_start"],
                "dataset_end": info["dataset_end"],
                "occupancy_r2": info["metrics"]["occupancy"]["random_forest"]["r2"],
                "occupancy_mae": info["metrics"]["occupancy"]["random_forest"]["mae"],
                "visits_r2": info["metrics"]["visits"]["random_forest"]["r2"],
                "visits_mae": info["metrics"]["visits"]["random_forest"]["mae"],
            },
        }
    )


if __name__ == "__main__":
    print(f"MediPulse ML API ready  |  training data through {DATASET_END.date()}  |  http://localhost:8000")
    app.run(host="0.0.0.0", port=8000, debug=False)
