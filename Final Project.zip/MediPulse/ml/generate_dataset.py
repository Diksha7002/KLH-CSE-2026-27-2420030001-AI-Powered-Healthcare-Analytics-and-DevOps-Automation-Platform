"""
MediPulse - Historical hospital dataset generator
=================================================

Generates a realistic *synthetic* daily operations dataset (one row per
department per day) used to TRAIN the prediction model.

It describes the SAME hospital as the application database: 7 departments,
38 beds, roughly 40 patient visits a day. The profile below mirrors
`PROFILE` in server/simulator.js - keep the two in sync.

The data comes from a small simulation, not random noise:
  * bed occupancy evolves day by day (occupied = previous + admissions - discharges)
  * visits follow weekly patterns (Emergency busier at weekends, Cardiology
    on weekdays) and seasonal effects (monsoon -> Pediatrics / General Medicine)
  * occasional multi-day surge events

Usage:
    python generate_dataset.py                 # 2021-01-01 .. yesterday
    python generate_dataset.py --start 2022-01-01 --end 2026-09-30
"""

import argparse
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).parent / "data"
OUTPUT_CSV = DATA_DIR / "hospital_history.csv"

# beds = total beds, usable = beds that are not under maintenance,
# stay = average length of stay (days), occ = typical occupancy,
# visits = typical visits per day, emergency = share of visits that are emergencies
DEPARTMENTS = {
    "ICU":              dict(beds=6, usable=5, stay=4.5, occ=0.68, visits=2,   emergency=0.5),
    "General Medicine": dict(beds=8, usable=8, stay=3.8, occ=0.62, visits=9,   emergency=0.15),
    "Emergency":        dict(beds=6, usable=5, stay=1.3, occ=0.62, visits=11,  emergency=0.9),
    "Pediatrics":       dict(beds=5, usable=5, stay=3.0, occ=0.55, visits=5,   emergency=0.2),
    "Cardiology":       dict(beds=5, usable=5, stay=4.2, occ=0.58, visits=5.5, emergency=0.2),
    "Neurology":        dict(beds=4, usable=4, stay=4.0, occ=0.55, visits=3.5, emergency=0.1),
    "Orthopedics":      dict(beds=4, usable=4, stay=3.5, occ=0.55, visits=4,   emergency=0.2),
}

# Day-of-week multipliers on visits (Mon..Sun)
DOW_FACTOR = {
    "ICU":              [1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00],
    "General Medicine": [1.15, 1.05, 1.00, 1.00, 1.02, 0.88, 0.80],
    "Emergency":        [1.05, 0.95, 0.95, 0.98, 1.08, 1.12, 1.10],
    "Pediatrics":       [1.10, 1.05, 1.00, 1.00, 1.00, 0.88, 0.82],
    "Cardiology":       [1.10, 1.08, 1.05, 1.05, 1.02, 0.60, 0.50],
    "Neurology":        [1.10, 1.05, 1.00, 1.00, 1.00, 0.70, 0.50],
    "Orthopedics":      [1.15, 1.10, 1.00, 1.00, 1.00, 0.80, 0.60],
}

# Month multipliers (Jan..Dec)
MONTH_FACTOR = {
    "ICU":              [1.08, 1.05, 1.00, 0.97, 0.97, 0.98, 1.02, 1.03, 1.03, 1.00, 1.02, 1.08],
    "General Medicine": [1.05, 1.00, 0.97, 0.95, 0.95, 1.00, 1.10, 1.12, 1.10, 1.00, 1.00, 1.03],
    "Emergency":        [1.00, 0.98, 1.00, 1.02, 1.05, 1.03, 1.00, 1.00, 1.00, 1.05, 1.03, 1.05],
    "Pediatrics":       [1.02, 0.98, 0.95, 0.92, 0.90, 1.00, 1.22, 1.28, 1.22, 1.05, 0.98, 1.00],
    "Cardiology":       [1.15, 1.12, 1.03, 0.97, 0.95, 0.93, 0.95, 0.95, 0.98, 1.02, 1.08, 1.15],
    "Neurology":        [1.05, 1.03, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.02, 1.05],
    "Orthopedics":      [1.00, 1.00, 1.00, 1.02, 1.05, 1.05, 1.08, 1.08, 1.05, 1.02, 1.00, 1.00],
}


def prob_round(rng, x):
    """2.4 -> 2 or 3 (3 with 40% probability), like the application simulator."""
    base = int(np.floor(x))
    return base + (1 if rng.random() < x - base else 0)


def simulate_department(name, cfg, dates, rng):
    beds, usable = cfg["beds"], cfg["usable"]
    adm_rate = (cfg["occ"] * usable / cfg["stay"]) / cfg["visits"]  # admissions per visit
    occupied = int(round(cfg["occ"] * usable))
    surge_days_left, surge_factor = 0, 1.0
    rows = []

    for d in dates:
        dow, month = d.weekday(), d.month - 1

        # occasional surge event (outbreak, accident, heat wave ...)
        if surge_days_left > 0:
            surge_days_left -= 1
        elif rng.random() < 0.010:
            surge_days_left = int(rng.integers(3, 7))
            surge_factor = float(rng.uniform(1.10, 1.30))
        surge = surge_factor if surge_days_left > 0 else 1.0

        mean = cfg["visits"] * DOW_FACTOR[name][dow] * MONTH_FACTOR[name][month] * surge
        visits = max(0, int(round(mean * (1 + rng.normal(0, 0.12)))))

        emergency_cases = int(rng.binomial(visits, cfg["emergency"])) if visits else 0
        appointments = visits - emergency_cases

        # smooth patient flow: discharges first (only people admitted earlier), then admissions
        discharges = prob_round(rng, max(0.0, occupied / cfg["stay"] * rng.normal(1.0, 0.15)))
        discharges = min(discharges, occupied)
        free_beds = usable - (occupied - discharges)
        admissions = prob_round(rng, max(0.0, visits * adm_rate * rng.normal(1.0, 0.15)))
        admissions = min(admissions, max(free_beds, 0))
        occupied = occupied - discharges + admissions

        rows.append(
            dict(
                date=d.isoformat(),
                department=name,
                total_beds=beds,
                occupied_beds=occupied,
                admissions=admissions,
                discharges=discharges,
                emergency_cases=emergency_cases,
                appointments=appointments,
                patient_visits=visits,
                average_stay=round(max(0.5, cfg["stay"] * rng.normal(1.0, 0.08)), 2),
                day_of_week=d.strftime("%A"),
                month=d.strftime("%B"),
                occupancy_rate=round(occupied / beds * 100, 2),
            )
        )
    return rows


def generate(start, end, seed=42):
    rng = np.random.default_rng(seed)
    dates = [start + timedelta(days=i) for i in range((end - start).days + 1)]
    rows = []
    for name, cfg in DEPARTMENTS.items():
        rows.extend(simulate_department(name, cfg, dates, rng))
    return pd.DataFrame(rows).sort_values(["date", "department"]).reset_index(drop=True)


def main():
    parser = argparse.ArgumentParser(description="Generate MediPulse training dataset")
    parser.add_argument("--start", default="2021-01-01")
    parser.add_argument("--end", default=(date.today() - timedelta(days=1)).isoformat())
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    if end <= start:
        raise SystemExit("--end must be after --start")

    df = generate(start, end, args.seed)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_CSV, index=False)

    print(f"Saved {len(df):,} rows -> {OUTPUT_CSV}")
    print(f"Date range : {df['date'].min()}  to  {df['date'].max()}")
    print(f"Hospital   : {sum(c['beds'] for c in DEPARTMENTS.values())} beds, "
          f"{df.groupby('date')['patient_visits'].sum().mean():.0f} visits/day on average")
    print("\nAverage occupancy by department:")
    print(df.groupby("department")["occupancy_rate"].agg(["mean", "min", "max"]).round(1))


if __name__ == "__main__":
    main()
