"""
MediPulse - ML training pipeline
================================

Historical dataset -> feature engineering -> train/test split (by time)
-> model comparison -> evaluation -> saved model.

Two Random Forest regressors are trained:
    1. next-day bed occupancy rate (%) per department
    2. next-day patient visits per department

They are compared against a naive baseline ("tomorrow = today / same
weekday last week") and a Linear Regression, using the most recent
TEST_DAYS days as a held-out test set (no shuffling - we never train on
the future).

Usage:
    python generate_dataset.py     # once, creates data/hospital_history.csv
    python train_model.py
"""

import json
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from features import DEPARTMENTS, FEATURE_COLUMNS, build_features

BASE_DIR = Path(__file__).parent
DATA_CSV = BASE_DIR / "data" / "hospital_history.csv"
MODEL_DIR = BASE_DIR / "models"
MODEL_PATH = MODEL_DIR / "medipulse_model.joblib"
METRICS_PATH = MODEL_DIR / "metrics.json"
BACKTEST_PATH = MODEL_DIR / "backtest.json"

TEST_DAYS = 120
RANDOM_STATE = 42


def new_forest():
    return RandomForestRegressor(
        n_estimators=120,
        min_samples_leaf=8,
        max_depth=16,
        n_jobs=-1,
        random_state=RANDOM_STATE,
    )


def score(y_true, y_pred):
    return {
        "mae": round(float(mean_absolute_error(y_true, y_pred)), 3),
        "rmse": round(float(np.sqrt(mean_squared_error(y_true, y_pred))), 3),
        "r2": round(float(r2_score(y_true, y_pred)), 4),
    }


def train(verbose=True):
    if not DATA_CSV.exists():
        raise FileNotFoundError(
            f"{DATA_CSV} not found. Run `python generate_dataset.py` first."
        )

    raw = pd.read_csv(DATA_CSV)
    feats = build_features(raw)
    labelled = feats.dropna(subset=FEATURE_COLUMNS + ["target_occupancy", "target_visits"])

    cutoff = labelled["date"].max() - pd.Timedelta(days=TEST_DAYS)
    train_df = labelled[labelled["date"] <= cutoff]
    test_df = labelled[labelled["date"] > cutoff]

    X_train, X_test = train_df[FEATURE_COLUMNS], test_df[FEATURE_COLUMNS]

    if verbose:
        print(f"Rows: {len(raw):,} raw | {len(labelled):,} usable | "
              f"train {len(train_df):,} | test {len(test_df):,} (last {TEST_DAYS} days)")

    metrics = {"occupancy": {}, "visits": {}}
    eval_models = {}

    for key, target, naive_col in [
        ("occupancy", "target_occupancy", "occ_lag1"),
        ("visits", "target_visits", "visits_same_dow"),
    ]:
        y_train, y_test = train_df[target], test_df[target]

        naive_pred = test_df[naive_col]
        lin = LinearRegression().fit(X_train, y_train)
        rf = new_forest().fit(X_train, y_train)
        eval_models[key] = rf

        metrics[key] = {
            "naive_baseline": score(y_test, naive_pred),
            "linear_regression": score(y_test, lin.predict(X_test)),
            "random_forest": score(y_test, rf.predict(X_test)),
        }
        if verbose:
            print(f"\n[{key}]")
            for name, m in metrics[key].items():
                print(f"  {name:<18} MAE={m['mae']:<8} RMSE={m['rmse']:<8} R2={m['r2']}")

    # ---- held-out backtest of total visits for the last 14 days (chart on the Predictions page)
    test_df = test_df.copy()
    test_df["pred_visits"] = eval_models["visits"].predict(X_test)
    test_df["pred_occ"] = eval_models["occupancy"].predict(X_test)
    test_df["target_date"] = test_df["date"] + pd.Timedelta(days=1)
    daily = (
        test_df.groupby("target_date")
        .agg(actual=("target_visits", "sum"), predicted=("pred_visits", "sum"))
        .reset_index()
        .tail(14)
    )
    backtest = [
        {
            "date": r.target_date.strftime("%Y-%m-%d"),
            "actual": int(round(r.actual)),
            "predicted": int(round(r.predicted)),
        }
        for r in daily.itertuples()
    ]

    # ---- production models: refit on ALL labelled rows
    X_all = labelled[FEATURE_COLUMNS]
    final_occ = new_forest().fit(X_all, labelled["target_occupancy"])
    final_vis = new_forest().fit(X_all, labelled["target_visits"])

    importances = sorted(
        zip(FEATURE_COLUMNS, final_occ.feature_importances_),
        key=lambda x: x[1],
        reverse=True,
    )[:6]

    info = {
        "model_type": "Random Forest Regressor (x2)",
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "sklearn_version": sklearn.__version__,
        "dataset_rows": int(len(raw)),
        "dataset_start": str(raw["date"].min()),
        "dataset_end": str(raw["date"].max()),
        "departments": DEPARTMENTS,
        "train_rows": int(len(train_df)),
        "test_rows": int(len(test_df)),
        "test_days": TEST_DAYS,
        "metrics": metrics,
        "top_features": [{"feature": f, "importance": round(float(i), 4)} for f, i in importances],
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(
        {"occupancy": final_occ, "visits": final_vis, "info": info},
        MODEL_PATH,
        compress=3,
    )
    METRICS_PATH.write_text(json.dumps(info, indent=2))
    BACKTEST_PATH.write_text(json.dumps(backtest, indent=2))

    if verbose:
        print(f"\nModel saved   -> {MODEL_PATH}")
        print(f"Metrics saved -> {METRICS_PATH}")
    return info


if __name__ == "__main__":
    train()
