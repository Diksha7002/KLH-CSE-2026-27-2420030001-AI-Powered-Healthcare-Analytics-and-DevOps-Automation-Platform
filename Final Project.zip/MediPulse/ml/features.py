"""
Shared feature engineering for training and prediction.

For every department-day *t* we build features from what is known at the
end of day t and the model predicts day t+1:
    target_occupancy  -> occupancy_rate on day t+1  (%)
    target_visits     -> patient_visits on day t+1
Using one function for both training and the live API guarantees the
model never sees different features in production than it was trained on.
"""

import numpy as np
import pandas as pd

DEPARTMENTS = [
    "ICU",
    "General Medicine",
    "Emergency",
    "Pediatrics",
    "Cardiology",
    "Neurology",
    "Orthopedics",
]

NUMERIC_FEATURES = [
    "target_dow",
    "target_month",
    "is_weekend",
    "occ_lag1",
    "occ_7d",
    "visits_lag1",
    "visits_7d",
    "visits_same_dow",
    "emergency_7d",
    "admissions_7d",
    "discharges_7d",
    "appointments_7d",
    "avg_stay_7d",
]
FEATURE_COLUMNS = NUMERIC_FEATURES + [f"dept_{d}" for d in DEPARTMENTS]

TARGETS = ["target_occupancy", "target_visits"]


def build_features(df):
    """df: raw history (columns as in hospital_history.csv). Returns feature frame."""
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["department", "date"]).reset_index(drop=True)

    parts = []
    for dept, g in df.groupby("department", sort=False):
        g = g.sort_values("date").reset_index(drop=True)
        out = pd.DataFrame({"date": g["date"], "department": dept})

        target_date = g["date"] + pd.Timedelta(days=1)
        out["target_dow"] = target_date.dt.dayofweek
        out["target_month"] = target_date.dt.month
        out["is_weekend"] = (out["target_dow"] >= 5).astype(int)

        out["occ_lag1"] = g["occupancy_rate"]
        out["occ_7d"] = g["occupancy_rate"].rolling(7, min_periods=7).mean()
        out["visits_lag1"] = g["patient_visits"]
        out["visits_7d"] = g["patient_visits"].rolling(7, min_periods=7).mean()
        # visits on the same weekday as the target day (t+1-7 = t-6)
        out["visits_same_dow"] = g["patient_visits"].shift(6)
        out["emergency_7d"] = g["emergency_cases"].rolling(7, min_periods=7).mean()
        out["admissions_7d"] = g["admissions"].rolling(7, min_periods=7).mean()
        out["discharges_7d"] = g["discharges"].rolling(7, min_periods=7).mean()
        out["appointments_7d"] = g["appointments"].rolling(7, min_periods=7).mean()
        out["avg_stay_7d"] = g["average_stay"].rolling(7, min_periods=7).mean()

        out["target_occupancy"] = g["occupancy_rate"].shift(-1)
        out["target_visits"] = g["patient_visits"].shift(-1)
        parts.append(out)

    feats = pd.concat(parts, ignore_index=True)
    for d in DEPARTMENTS:
        feats[f"dept_{d}"] = (feats["department"] == d).astype(int)
    return feats


def latest_feature_row(history_df, department):
    """Features for the most recent day of one department's history."""
    feats = build_features(history_df[history_df["department"] == department])
    row = feats.dropna(subset=NUMERIC_FEATURES).iloc[[-1]]
    return row
