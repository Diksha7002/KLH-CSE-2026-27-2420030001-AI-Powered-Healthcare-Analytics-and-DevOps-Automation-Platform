const API_BASE = "http://localhost:5000/api";

async function api(endpoint, options = {}) {
  const response = await fetch(
    `${API_BASE}${endpoint}`,
    {
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      },
      ...options
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data.message || "Something went wrong"
    );
  }

  return data;
}


// ===============================
// AUTH
// ===============================

export const loginUser = (credentials) =>
  api("/login", {
    method: "POST",
    body: JSON.stringify(credentials)
  });


export const registerPatient = (patient) =>
  api("/register", {
    method: "POST",
    body: JSON.stringify(patient)
  });


// ===============================
// DASHBOARD
// ===============================

export const getDashboardStats = () =>
  api("/dashboard/stats");


// ===============================
// PATIENTS
// ===============================

export const getPatients = () =>
  api("/patients");

export const getPatient = (id) =>
  api(`/patients/${id}`);

export const addPatient = (patient) =>
  api("/patients", {
    method: "POST",
    body: JSON.stringify(patient)
  });

export const deletePatient = (id) =>
  api(`/patients/${id}`, {
    method: "DELETE"
  });


// ===============================
// APPOINTMENTS
// ===============================

export const getAppointments = (patient) =>
  api(patient ? `/appointments?patient=${encodeURIComponent(patient)}` : "/appointments");

export const addAppointment = (appointment) =>
  api("/appointments", {
    method: "POST",
    body: JSON.stringify(appointment)
  });

export const updateAppointmentStatus = (
  id,
  status
) =>
  api(`/appointments/${id}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status })
  });


// ===============================
// DOCTORS
// ===============================

export const getDoctors = () =>
  api("/doctors");


// ===============================
// DEPARTMENTS
// ===============================

export const getDepartments = () =>
  api("/departments");


// ===============================
// BEDS
// ===============================

export const getBeds = () =>
  api("/beds");

export const updateBed = (id, data) =>
  api(`/beds/${id}`, {
    method: "PATCH",
    body: JSON.stringify(data)
  });


// ===============================
// ADMISSIONS
// ===============================

export const getAdmissions = () =>
  api("/admissions");

export const addAdmission = (admission) =>
  api("/admissions", {
    method: "POST",
    body: JSON.stringify(admission)
  });

export const dischargeAdmission = (id) =>
  api(`/admissions/${id}/discharge`, {
    method: "PATCH"
  });
  
// ===============================
// PATIENT DATA
// ===============================

export const getLabs = (patient) =>
  api(patient ? `/labs?patient=${encodeURIComponent(patient)}` : "/labs");

export const getPrescriptions = (patient) =>
  api(patient ? `/prescriptions?patient=${encodeURIComponent(patient)}` : "/prescriptions");

export const getRecords = (patient) =>
  api(patient ? `/records?patient=${encodeURIComponent(patient)}` : "/records");


// ===============================
// PREDICTIONS (ML)
// ===============================

export const getPredictions = () =>
  api("/predictions");


// ===============================
// REPORTS
// ===============================

export const getReportSummary = () =>
  api("/reports/summary");


// ===============================
// AI ASSISTANT
// ===============================

export const askAssistant = (message, history = []) =>
  api("/assistant", {
    method: "POST",
    body: JSON.stringify({ message, history })
  });
