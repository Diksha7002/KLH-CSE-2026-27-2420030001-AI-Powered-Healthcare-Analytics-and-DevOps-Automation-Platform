import Logo from "../components/Logo";
import { useEffect, useState } from "react";
import {
  FaArrowLeft,
  FaFlask,
  FaEye,
  FaDownload,
  FaUserMd,
  FaCalendarAlt,
  FaCheckCircle
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { getLabs } from "../services/api";
import { formatDisplayDate } from "../utils/dates";

function PatientLabs() {

  const navigate = useNavigate();

  const [selectedReport, setSelectedReport] = useState(null);

  const patientName = localStorage.getItem("userName") || "";
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  // ================= LOAD FROM DATABASE =================
  useEffect(() => {
    const load = async () => {
      try {
        const data = await getLabs(patientName);
        setReports(data.map((item) => ({ ...item, date: formatDisplayDate(item.date), status: item.status === "Pending" ? "Pending" : item.result })));
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [patientName]);

  return (
    <div className="patient-page">

      {/* HEADER */}

      <header className="patient-header">

        <div className="patient-brand">
          <Logo size={38} />
          <div>
            <h2>MediPulse</h2>
            <p>Patient Portal</p>
          </div>
        </div>

        <div className="patient-header-right">

          <span>{patientName}</span>

          <button
            className="logout-button"
            onClick={() => navigate("/login")}
          >
            Logout
          </button>

        </div>

      </header>


      {/* CONTENT */}

      <main className="patient-content">

        {/* BACK BUTTON */}

        <button
          className="patient-back-btn"
          onClick={() => navigate("/patient-dashboard")}
        >
          <FaArrowLeft />
          Back to Dashboard
        </button>


        {/* TITLE */}

        <div className="patient-welcome">

          <h1>Lab Reports</h1>

          <p>
            View your laboratory test results and reports.
          </p>

        </div>


        {/* SUMMARY */}

        <div className="lab-summary">

          <div className="lab-summary-card">

            <div className="lab-summary-icon">
              <FaFlask />
            </div>

            <div>
              <span>Total Reports</span>
              <h2>{reports.length}</h2>
            </div>

          </div>


          <div className="lab-summary-card">

            <div className="lab-summary-icon">
              <FaCheckCircle />
            </div>

            <div>
              <span>Normal Results</span>
              <h2>
                {reports.filter(
                  report => report.status === "Normal"
                ).length}
              </h2>
            </div>

          </div>

        </div>


        {/* REPORT CARD */}

        <div className="lab-reports-card">

          <div className="lab-reports-header">

            <div>

              <h2>Recent Lab Reports</h2>

              <p>
                Your latest diagnostic test results
              </p>

            </div>

          </div>


          {/* REPORT LIST */}

          <div className="lab-report-list">
            {!loading && reports.length === 0 && (
              <p style={{ padding: "20px", color: "#6b7280" }}>
                No lab reports available yet.
              </p>
            )}

            {reports.map((report) => (

              <div
                className="lab-report-item"
                key={report.id}
              >

                <div className="lab-report-main">

                  <div className="lab-report-icon">
                    <FaFlask />
                  </div>

                  <div>

                    <h3>{report.test}</h3>

                    <p>{report.shortName}</p>

                  </div>

                </div>


                <div className="lab-report-detail">

                  <span>
                    <FaCalendarAlt />
                    Date
                  </span>

                  <strong>
                    {report.date}
                  </strong>

                </div>


                <div className="lab-report-detail">

                  <span>
                    <FaUserMd />
                    Doctor
                  </span>

                  <strong>
                    {report.doctor}
                  </strong>

                </div>


                <div className="lab-status">
                  <FaCheckCircle />
                  {report.status}
                </div>


                <button
                  className="lab-view-btn"
                  onClick={() =>
                    setSelectedReport(report)
                  }
                >
                  <FaEye />
                  View
                </button>

              </div>

            ))}

          </div>

        </div>


        {/* REPORT MODAL */}

        {selectedReport && (

          <div className="lab-modal-overlay">

            <div className="lab-modal">

              <button
                className="lab-modal-close"
                onClick={() => setSelectedReport(null)}
              >
                ×
              </button>


              <div className="lab-modal-icon">
                <FaFlask />
              </div>


              <h2>
                {selectedReport.test}
              </h2>

              <p className="lab-modal-date">
                Report date: {selectedReport.date}
              </p>


              <div className="lab-details-grid">

                <div>
                  <span>Doctor</span>
                  <strong>
                    {selectedReport.doctor}
                  </strong>
                </div>

                <div>
                  <span>Laboratory</span>
                  <strong>
                    {selectedReport.lab}
                  </strong>
                </div>

                <div>
                  <span>Test</span>
                  <strong>
                    {selectedReport.shortName}
                  </strong>
                </div>

                <div>
                  <span>Result</span>
                  <strong className="normal-result">
                    {selectedReport.result}
                  </strong>
                </div>

              </div>


              <div className="lab-result-box">

                <FaCheckCircle />

                <div>

                  <strong>Result Summary</strong>

                  <p>
                    {selectedReport.summary}
                  </p>

                </div>

              </div>


              <div className="lab-modal-buttons">

                <button
                  className="lab-close-btn"
                  onClick={() => setSelectedReport(null)}
                >
                  Close
                </button>

                <button
                  className="lab-download-btn"
                  onClick={() =>
                    alert(
                      "Demo: Lab report download will be connected to the backend later."
                    )
                  }
                >
                  <FaDownload />
                  Download Report
                </button>

              </div>

            </div>

          </div>

        )}

      </main>

    </div>
  );
}

export default PatientLabs;