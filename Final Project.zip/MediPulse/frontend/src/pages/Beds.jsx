import { useEffect, useState } from "react";

import {
  FaBed,
  FaSearch,
  FaPlus,
  FaTools
} from "react-icons/fa";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import { getBeds } from "../services/api";

function Beds() {

  const [beds, setBeds] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);


  // LOAD BEDS FROM BACKEND
  const loadBeds = async () => {

    try {

      setLoading(true);

      const data = await getBeds();

      setBeds(data);

    } catch (error) {

      console.error("Failed to load beds:", error);

    } finally {

      setLoading(false);

    }

  };


  useEffect(() => {

    loadBeds();

  }, []);


  // SEARCH
  const filteredBeds = beds.filter((bed) => {

    const text = `
      ${bed.bedNumber || ""}
      ${bed.department || ""}
      ${bed.patient || ""}
      ${bed.status || ""}
    `.toLowerCase();

    return text.includes(search.toLowerCase());

  });


  // SUMMARY
  const totalBeds = beds.length;

  const occupiedBeds = beds.filter(
    (bed) => bed.status === "Occupied"
  ).length;

  const availableBeds = beds.filter(
    (bed) => bed.status === "Available"
  ).length;

  const maintenanceBeds = beds.filter(
    (bed) => bed.status === "Maintenance"
  ).length;


  // DEPARTMENT OCCUPANCY
  const departments = [
    "ICU",
    "General Medicine",
    "Emergency",
    "Pediatrics",
    "Cardiology"
  ];


  const getDepartmentOccupancy = (department) => {

    const departmentBeds = beds.filter(
      (bed) => bed.department === department
    );

    if (departmentBeds.length === 0) {
      return 0;
    }

    const occupied = departmentBeds.filter(
      (bed) => bed.status === "Occupied"
    ).length;

    return Math.round(
      (occupied / departmentBeds.length) * 100
    );

  };


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">


          {/* HEADER */}

          <div className="page-header">

            <div>

              <h1>
                Bed Management
              </h1>

              <p>
                Monitor hospital beds and availability
              </p>

            </div>


            <button className="add-patient-btn">

              <FaPlus />

              Add Bed

            </button>

          </div>


          {/* SUMMARY CARDS */}

          <div className="appointment-summary">


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaBed />
              </div>

              <div>

                <span>
                  Total Beds
                </span>

                <h2>
                  {totalBeds}
                </h2>

              </div>

            </div>


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaBed />
              </div>

              <div>

                <span>
                  Occupied
                </span>

                <h2>
                  {occupiedBeds}
                </h2>

              </div>

            </div>


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaBed />
              </div>

              <div>

                <span>
                  Available
                </span>

                <h2>
                  {availableBeds}
                </h2>

              </div>

            </div>


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaTools />
              </div>

              <div>

                <span>
                  Maintenance
                </span>

                <h2>
                  {maintenanceBeds}
                </h2>

              </div>

            </div>


          </div>


          {/* SEARCH */}

          <div className="patients-toolbar">

            <div className="search-box">

              <FaSearch />

              <input
                type="text"
                placeholder="Search beds, rooms or patients..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />

            </div>

          </div>


          {/* BED TABLE */}

          <div className="patients-table-card">

            <div className="table-header">

              <div>

                <h3>
                  Bed Inventory
                </h3>

                <p>
                  Current bed status across departments
                </p>

              </div>

            </div>


            <div className="table-container">

              {loading ? (

                <div className="empty-state">
                  Loading beds...
                </div>

              ) : (

                <table>

                  <thead>

                    <tr>

                      <th>Bed ID</th>
                      <th>Department</th>
                      <th>Room</th>
                      <th>Patient</th>
                      <th>Status</th>

                    </tr>

                  </thead>


                  <tbody>

                    {filteredBeds.length > 0 ? (

                      filteredBeds.map((bed) => (

                        <tr key={bed.id}>

                          <td>

                            <strong>
                              {bed.bedNumber}
                            </strong>

                          </td>

                          <td>
                            {bed.department}
                          </td>

                          <td>
                            {bed.bedNumber}
                          </td>

                          <td>
                            {bed.patient || "—"}
                          </td>

                          <td>

                            <span
                              className={`status-badge ${bed.status
                                .toLowerCase()
                                .replace(" ", "-")}`}
                            >

                              {bed.status}

                            </span>

                          </td>

                        </tr>

                      ))

                    ) : (

                      <tr>

                        <td
                          colSpan="5"
                          style={{ textAlign: "center" }}
                        >

                          No beds found

                        </td>

                      </tr>

                    )}

                  </tbody>

                </table>

              )}

            </div>

          </div>


          {/* OCCUPANCY BY DEPARTMENT */}

          <div className="chart-card bed-occupancy-card">

            <div className="card-header">

              <div>

                <h3>
                  Occupancy by Department
                </h3>

                <p>
                  Current utilization of available beds
                </p>

              </div>

            </div>


            <div className="occupancy-list">


              {departments.map((department) => {

                const percentage =
                  getDepartmentOccupancy(department);


                return (

                  <div
                    className="occupancy-item"
                    key={department}
                  >

                    <div className="occupancy-info">

                      <span>
                        {department}
                      </span>

                      <strong>
                        {percentage}%
                      </strong>

                    </div>


                    <div className="progress-bar">

                      <div
                        className="progress-fill"
                        style={{
                          width: `${percentage}%`
                        }}
                      />

                    </div>

                  </div>

                );

              })}


            </div>

          </div>


        </div>

      </main>

    </div>

  );

}


export default Beds;