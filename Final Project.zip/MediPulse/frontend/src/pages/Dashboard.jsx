import { useEffect, useState } from "react";

import {
  FaUserInjured,
  FaCalendarCheck,
  FaBed,
  FaHospital
} from "react-icons/fa";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import StatCard from "../components/StatCard";

import { getDashboardStats } from "../services/api";

function Dashboard() {
  const [stats, setStats] = useState({
    totalPatients: 0,
    todayAppointments: 0,
    occupiedBeds: 0,
    totalBeds: 0,
    occupancy: 0,
    admissions: 0,
    bedOccupancy: [],
    patientFlow: []
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // ================= GREETING =================

  const getGreeting = () => {
    const hour = new Date().getHours();

    if (hour < 12) {
      return "Good Morning";
    }

    if (hour < 17) {
      return "Good Afternoon";
    }

    if (hour < 21) {
      return "Good Evening";
    }

    return "Good Night";
  };

  // ================= LOAD DASHBOARD DATA =================

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        setLoading(true);

        const data = await getDashboardStats();

        setStats({
          totalPatients: data.totalPatients || 0,
          todayAppointments: data.todayAppointments || 0,
          occupiedBeds: data.occupiedBeds || 0,
          totalBeds: data.totalBeds || 0,
          occupancy: data.occupancy || 0,
          admissions: data.admissions || 0,
          bedOccupancy: Array.isArray(data.bedOccupancy)
            ? data.bedOccupancy
            : [],
          patientFlow: Array.isArray(data.patientFlow)
            ? data.patientFlow
            : []
        });

        setError("");
      } catch (err) {
        console.error("Dashboard API error:", err);

        setError("Unable to load dashboard data.");
      } finally {
        setLoading(false);
      }
    };

    loadDashboard();
  }, []);

  // ================= GET OCCUPANCY =================

  const getDepartmentOccupancy = (department) => {
    const item = stats.bedOccupancy.find(
      (item) => item.department === department
    );

    return item ? item.percentage : 0;
  };

  return (
    <div className="app-container">

      {/* SIDEBAR */}
      <Sidebar />

      {/* MAIN CONTENT */}
      <main className="main-content">

        {/* NAVBAR */}
        <Navbar />

        <div className="dashboard-content">

          {/* ================= WELCOME ================= */}

          <div className="welcome-section">
            <div>
              <h1>
                {getGreeting()}, Doc! 👋
              </h1>

              <p>
                Here's what's happening in your
                hospital today.
              </p>
            </div>
          </div>

          {/* ================= ERROR ================= */}

          {error && (
            <div
              className="api-error"
              style={{
                marginBottom: "20px",
                padding: "12px 16px",
                borderRadius: "8px",
                background: "#fee2e2",
                color: "#b91c1c"
              }}
            >
              {error}
            </div>
          )}

          {/* ================= STAT CARDS ================= */}

          <div className="stats-grid">

            <StatCard
              title="Total Patients"
              value={
                loading
                  ? "..."
                  : stats.totalPatients
              }
              subtitle="Registered patients"
              icon={<FaUserInjured />}
            />

            <StatCard
              title="Appointments"
              value={
                loading
                  ? "..."
                  : stats.todayAppointments
              }
              subtitle="Today's appointments"
              icon={<FaCalendarCheck />}
            />

            <StatCard
              title="Bed Occupancy"
              value={
                loading
                  ? "..."
                  : `${stats.occupancy}%`
              }
              subtitle={
                loading
                  ? "Loading..."
                  : `${stats.totalBeds - stats.occupiedBeds} beds available`
              }
              icon={<FaBed />}
            />

            <StatCard
              title="Admissions"
              value={
                loading
                  ? "..."
                  : stats.admissions
              }
              subtitle="Currently admitted"
              icon={<FaHospital />}
            />

          </div>

          {/* ================= CHARTS ================= */}

          <div className="dashboard-grid">

            {/* ================= PATIENT FLOW ================= */}

            <div className="chart-card">

              <div className="card-header">
                <div>
                  <h3>
                    Patient Flow
                  </h3>

                  <p>
                    Patient visits over the week
                  </p>
                </div>
              </div>

              <div className="chart-container">

                <ResponsiveContainer
                  width="100%"
                  height={260}
                >
                  <LineChart
                    data={stats.patientFlow}
                  >

                    <CartesianGrid
                      strokeDasharray="3 3"
                    />

                    <XAxis
                      dataKey="day"
                    />

                    <YAxis />

                    <Tooltip />

                    <Line
                      type="monotone"
                      dataKey="patients"
                      stroke="#0d9488"
                      strokeWidth={3}
                      dot={{ r: 4 }}
                    />

                  </LineChart>
                </ResponsiveContainer>

              </div>

            </div>

            {/* ================= BED OCCUPANCY ================= */}

            <div className="chart-card">

              <div className="card-header">
                <div>
                  <h3>
                    Bed Occupancy
                  </h3>

                  <p>
                    Current occupancy by department
                  </p>
                </div>
              </div>

              <div className="occupancy-list">

                {/* ICU */}

                <div className="occupancy-item">

                  <div className="occupancy-info">
                    <span>
                      ICU
                    </span>

                    <strong>
                      {getDepartmentOccupancy("ICU")}%
                    </strong>
                  </div>

                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${getDepartmentOccupancy("ICU")}%`
                      }}
                    ></div>
                  </div>

                </div>

                {/* GENERAL MEDICINE */}

                <div className="occupancy-item">

                  <div className="occupancy-info">
                    <span>
                      General Medicine
                    </span>

                    <strong>
                      {getDepartmentOccupancy("General Medicine")}%
                    </strong>
                  </div>

                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${getDepartmentOccupancy("General Medicine")}%`
                      }}
                    ></div>
                  </div>

                </div>

                {/* EMERGENCY */}

                <div className="occupancy-item">

                  <div className="occupancy-info">
                    <span>
                      Emergency
                    </span>

                    <strong>
                      {getDepartmentOccupancy("Emergency")}%
                    </strong>
                  </div>

                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${getDepartmentOccupancy("Emergency")}%`
                      }}
                    ></div>
                  </div>

                </div>

                {/* PEDIATRICS */}

                <div className="occupancy-item">

                  <div className="occupancy-info">
                    <span>
                      Pediatrics
                    </span>

                    <strong>
                      {getDepartmentOccupancy("Pediatrics")}%
                    </strong>
                  </div>

                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${getDepartmentOccupancy("Pediatrics")}%`
                      }}
                    ></div>
                  </div>

                </div>

                {/* CARDIOLOGY */}

                <div className="occupancy-item">

                  <div className="occupancy-info">
                    <span>
                      Cardiology
                    </span>

                    <strong>
                      {getDepartmentOccupancy("Cardiology")}%
                    </strong>
                  </div>

                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{
                        width: `${getDepartmentOccupancy("Cardiology")}%`
                      }}
                    ></div>
                  </div>

                </div>

              </div>

            </div>

          </div>

          {/* ================= AI INSIGHTS ================= */}

          <div className="ai-card">

            <div className="ai-header">

              <FaHospital />

              <div>
                <h3>
                  AI Insights
                </h3>

                <p>
                  Operational recommendations
                </p>
              </div>

            </div>

            {/* INSIGHT 1 */}

            <div className="insight">

              <strong>
                ⚠ Unusual Emergency Activity
              </strong>

              <p>
                Emergency patient volume is higher
                than the recent average.
              </p>

            </div>

            {/* INSIGHT 2 */}

            <div className="insight">

              <strong>
                🔮 Bed Occupancy Prediction
              </strong>

              <p>
                ICU occupancy may increase
                significantly tomorrow.
              </p>

            </div>

          </div>

        </div>

      </main>

    </div>
  );
}

export default Dashboard;