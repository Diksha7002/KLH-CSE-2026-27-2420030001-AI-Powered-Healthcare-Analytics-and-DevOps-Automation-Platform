import { useEffect, useState } from "react";

import {
  FaCalendarCheck,
  FaSearch,
  FaPlus,
  FaEye,
  FaEdit,
  FaTimes
} from "react-icons/fa";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  getAppointments,
  addAppointment,
  updateAppointmentStatus
} from "../services/api";


function Appointments() {

  const [appointments, setAppointments] = useState([]);

  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);

  const [showForm, setShowForm] = useState(false);

  const [selectedAppointment, setSelectedAppointment] =
    useState(null);


  const [form, setForm] = useState({
    patient: "",
    doctor: "",
    department: "",
    date: "",
    time: "",
    type: "Consultation",
    status: "Confirmed"
  });


  // ================= LOAD APPOINTMENTS =================

  const loadAppointments = async () => {

    try {

      setLoading(true);

      const data = await getAppointments();

      setAppointments(data);

    } catch (error) {

      console.error(
        "Failed to load appointments:",
        error
      );

    } finally {

      setLoading(false);

    }

  };


  useEffect(() => {

    loadAppointments();

  }, []);


  // ================= DATE =================

  const today = new Date()
    .toISOString()
    .split("T")[0];


  const formatDate = (date) => {

    if (!date) return "-";

    const d = new Date(date);

    if (isNaN(d.getTime())) {
      return date;
    }

    return d.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });

  };


  // ================= TODAY'S APPOINTMENTS =================

  const getAppointmentDate = (appointment) => {

    if (!appointment.date) {
      return "";
    }

    // Handles YYYY-MM-DD
    if (
      appointment.date.match &&
      appointment.date.match(/^\d{4}-\d{2}-\d{2}$/)
    ) {

      return appointment.date;

    }

    // Handles dates like "30 Aug 2026"
    const parsed = new Date(appointment.date);

    if (isNaN(parsed.getTime())) {
      return "";
    }

    return parsed
      .toISOString()
      .split("T")[0];

  };


  const todaysAppointments = appointments.filter(
    appointment =>
      getAppointmentDate(appointment) === today
  );


  // ================= SEARCH =================

  const filteredAppointments =
    appointments.filter((appointment) => {

      const searchText =
        search.toLowerCase();

      return (

        String(appointment.id)
          .toLowerCase()
          .includes(searchText) ||

        appointment.patient
          ?.toLowerCase()
          .includes(searchText) ||

        appointment.doctor
          ?.toLowerCase()
          .includes(searchText) ||

        appointment.department
          ?.toLowerCase()
          .includes(searchText) ||

        appointment.type
          ?.toLowerCase()
          .includes(searchText) ||

        appointment.status
          ?.toLowerCase()
          .includes(searchText)

      );

    });


  // ================= SUMMARY =================

  const confirmedCount =
    todaysAppointments.filter(
      appointment =>
        appointment.status === "Confirmed"
    ).length;


  const waitingCount =
    todaysAppointments.filter(
      appointment =>
        appointment.status === "Waiting"
    ).length;


  const cancelledCount =
    todaysAppointments.filter(
      appointment =>
        appointment.status === "Cancelled"
    ).length;


  // ================= FORM CHANGE =================

  const handleChange = (e) => {

    const { name, value } = e.target;

    setForm({
      ...form,
      [name]: value
    });

  };


  // ================= ADD APPOINTMENT =================

  const handleAddAppointment = async (e) => {

    e.preventDefault();


    if (
      !form.patient ||
      !form.doctor ||
      !form.department ||
      !form.date ||
      !form.time
    ) {

      alert(
        "Please fill all appointment details."
      );

      return;

    }


    try {

      const newAppointment =
        await addAppointment(form);


      setAppointments([
        ...appointments,
        newAppointment
      ]);


      setForm({
        patient: "",
        doctor: "",
        department: "",
        date: "",
        time: "",
        type: "Consultation",
        status: "Confirmed"
      });


      setShowForm(false);


      alert(
        "Appointment created successfully!"
      );

    } catch (error) {

      console.error(error);

      alert(
        error.message ||
        "Failed to create appointment."
      );

    }

  };


  // ================= STATUS UPDATE =================

  const handleStatusChange = async (
    id,
    newStatus
  ) => {

    try {

      const updated =
        await updateAppointmentStatus(
          id,
          newStatus
        );


      setAppointments(
        appointments.map(
          appointment =>
            appointment.id === id
              ? updated
              : appointment
        )
      );

    } catch (error) {

      console.error(error);

      alert(
        "Failed to update appointment status."
      );

    }

  };


  // ================= VIEW =================

  const handleView = (appointment) => {

    setSelectedAppointment(
      appointment
    );

  };


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">


          {/* ================= HEADER ================= */}

          <div className="page-header">

            <div>

              <h1>
                Appointments
              </h1>

              <p>
                Schedule and manage patient appointments
              </p>

            </div>


            <button
              className="add-patient-btn"
              onClick={() =>
                setShowForm(true)
              }
            >

              <FaPlus />

              New Appointment

            </button>

          </div>


          {/* ================= NEW APPOINTMENT FORM ================= */}

          {showForm && (

            <div className="patients-table-card">

              <div className="table-header">

                <div>

                  <h3>
                    New Appointment
                  </h3>

                  <p>
                    Schedule an appointment for a patient
                  </p>

                </div>


                <button
                  className="filter-btn"
                  onClick={() =>
                    setShowForm(false)
                  }
                >

                  <FaTimes />

                </button>

              </div>


              <form
                onSubmit={
                  handleAddAppointment
                }
                style={{
                  padding: "20px",
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2, 1fr)",
                  gap: "15px"
                }}
              >

                <input
                  type="text"
                  name="patient"
                  placeholder="Patient Name"
                  value={form.patient}
                  onChange={handleChange}
                />


                <input
                  type="text"
                  name="doctor"
                  placeholder="Doctor Name"
                  value={form.doctor}
                  onChange={handleChange}
                />


                <select
                  name="department"
                  value={form.department}
                  onChange={handleChange}
                >

                  <option value="">
                    Select Department
                  </option>

                  <option value="Cardiology">
                    Cardiology
                  </option>

                  <option value="General Medicine">
                    General Medicine
                  </option>

                  <option value="Orthopedics">
                    Orthopedics
                  </option>

                  <option value="Neurology">
                    Neurology
                  </option>

                  <option value="Pediatrics">
                    Pediatrics
                  </option>
                  <option value="Emergency">
                    Emergency
                  </option>
                  <option value="ICU">
                    ICU
                  </option>

                </select>


                <input
                  type="date"
                  name="date"
                  value={form.date}
                  min={today}
                  onChange={handleChange}
                />


                <input
                  type="time"
                  name="time"
                  value={form.time}
                  onChange={handleChange}
                />


                <select
                  name="type"
                  value={form.type}
                  onChange={handleChange}
                >

                  <option value="Consultation">
                    Consultation
                  </option>

                  <option value="Follow-up">
                    Follow-up
                  </option>

                  <option value="Routine Checkup">
                    Routine Checkup
                  </option>

                </select>


                <button
                  type="submit"
                  className="add-patient-btn"
                  style={{
                    gridColumn:
                      "1 / -1"
                  }}
                >

                  <FaCalendarCheck />

                  Create Appointment

                </button>

              </form>

            </div>

          )}


          {/* ================= SUMMARY CARDS ================= */}

          <div className="appointment-summary">


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaCalendarCheck />
              </div>

              <div>

                <span>
                  Today's Appointments
                </span>

                <h2>
                  {loading
                    ? "..."
                    : todaysAppointments.length}
                </h2>

              </div>

            </div>


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaCalendarCheck />
              </div>

              <div>

                <span>
                  Confirmed
                </span>

                <h2>
                  {loading
                    ? "..."
                    : confirmedCount}
                </h2>

              </div>

            </div>


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaCalendarCheck />
              </div>

              <div>

                <span>
                  Waiting
                </span>

                <h2>
                  {loading
                    ? "..."
                    : waitingCount}
                </h2>

              </div>

            </div>


            <div className="appointment-summary-card">

              <div className="appointment-icon">
                <FaCalendarCheck />
              </div>

              <div>

                <span>
                  Cancelled
                </span>

                <h2>
                  {loading
                    ? "..."
                    : cancelledCount}
                </h2>

              </div>

            </div>

          </div>


          {/* ================= SEARCH ================= */}

          <div className="patients-toolbar">

            <div className="search-box">

              <FaSearch />

              <input
                type="text"
                placeholder="Search appointments..."
                value={search}
                onChange={(e) =>
                  setSearch(
                    e.target.value
                  )
                }
              />

            </div>

          </div>


          {/* ================= TABLE ================= */}

          <div className="patients-table-card">

            <div className="table-header">

              <div>

                <h3>
                  Appointments
                </h3>

                <p>
                  {todaysAppointments.length} appointments today
                </p>

              </div>

            </div>


            <div className="table-container">

              <table>

                <thead>

                  <tr>

                    <th>
                      Appointment ID
                    </th>

                    <th>
                      Patient
                    </th>

                    <th>
                      Doctor
                    </th>

                    <th>
                      Department
                    </th>

                    <th>
                      Date
                    </th>

                    <th>
                      Time
                    </th>

                    <th>
                      Type
                    </th>

                    <th>
                      Status
                    </th>

                    <th>
                      Actions
                    </th>

                  </tr>

                </thead>


                <tbody>

                  {loading ? (

                    <tr>

                      <td
                        colSpan="9"
                        style={{
                          textAlign:
                            "center",
                          padding: "30px"
                        }}
                      >

                        Loading appointments...

                      </td>

                    </tr>

                  ) : filteredAppointments.length === 0 ? (

                    <tr>

                      <td
                        colSpan="9"
                        style={{
                          textAlign:
                            "center",
                          padding: "30px"
                        }}
                      >

                        No appointments found.

                      </td>

                    </tr>

                  ) : (

                    filteredAppointments.map(
                      (appointment) => (

                        <tr
                          key={
                            appointment.id
                          }
                        >

                          <td>

                            <strong>
                              {typeof appointment.id === "number"
                                ? `APT${String(appointment.id).padStart(4, "0")}`
                                : appointment.id}
                            </strong>

                          </td>


                          <td>
                            {appointment.patient}
                          </td>


                          <td>
                            {appointment.doctor}
                          </td>


                          <td>
                            {appointment.department}
                          </td>


                          <td>
                            {formatDate(
                              appointment.date
                            )}
                          </td>


                          <td>
                            {appointment.time}
                          </td>


                          <td>
                            {appointment.type}
                          </td>


                          <td>

                            <select
                              value={
                                appointment.status
                              }
                              onChange={(e) =>
                                handleStatusChange(
                                  appointment.id,
                                  e.target.value
                                )
                              }
                              style={{
                                padding:
                                  "5px 8px",
                                borderRadius:
                                  "6px",
                                border:
                                  "1px solid #ddd"
                              }}
                            >

                              <option value="Confirmed">
                                Confirmed
                              </option>

                              <option value="Waiting">
                                Waiting
                              </option>

                              <option value="Cancelled">
                                Cancelled
                              </option>

                              <option value="Completed">
                                Completed
                              </option>

                            </select>

                          </td>


                          <td>

                            <div className="action-buttons">

                              <button
                                title="View"
                                onClick={() =>
                                  handleView(
                                    appointment
                                  )
                                }
                              >

                                <FaEye />

                              </button>


                              <button
                                title="Edit"
                                onClick={() =>
                                  setShowForm(
                                    true
                                  )
                                }
                              >

                                <FaEdit />

                              </button>

                            </div>

                          </td>

                        </tr>

                      )
                    )

                  )}

                </tbody>

              </table>

            </div>

          </div>


          {/* ================= VIEW MODAL ================= */}

          {selectedAppointment && (

            <div
              style={{
                position: "fixed",
                inset: 0,
                background:
                  "rgba(0,0,0,0.45)",
                display: "flex",
                alignItems:
                  "center",
                justifyContent:
                  "center",
                zIndex: 1000
              }}
            >

              <div
                style={{
                  background: "white",
                  padding: "30px",
                  borderRadius:
                    "16px",
                  width: "420px",
                  maxWidth: "90%"
                }}
              >

                <div
                  style={{
                    display: "flex",
                    justifyContent:
                      "space-between",
                    alignItems:
                      "center"
                  }}
                >

                  <h2>
                    Appointment Details
                  </h2>


                  <button
                    className="filter-btn"
                    onClick={() =>
                      setSelectedAppointment(
                        null
                      )
                    }
                  >

                    <FaTimes />

                  </button>

                </div>


                <hr />


                <p>
                  <strong>
                    Appointment ID:
                  </strong>{" "}
                  {selectedAppointment.id}
                </p>

                <p>
                  <strong>
                    Patient:
                  </strong>{" "}
                  {selectedAppointment.patient}
                </p>

                <p>
                  <strong>
                    Doctor:
                  </strong>{" "}
                  {selectedAppointment.doctor}
                </p>

                <p>
                  <strong>
                    Department:
                  </strong>{" "}
                  {selectedAppointment.department}
                </p>

                <p>
                  <strong>
                    Date:
                  </strong>{" "}
                  {formatDate(
                    selectedAppointment.date
                  )}
                </p>

                <p>
                  <strong>
                    Time:
                  </strong>{" "}
                  {selectedAppointment.time}
                </p>

                <p>
                  <strong>
                    Type:
                  </strong>{" "}
                  {selectedAppointment.type}
                </p>

                <p>
                  <strong>
                    Status:
                  </strong>{" "}
                  {selectedAppointment.status}
                </p>


                <button
                  className="add-patient-btn"
                  onClick={() =>
                    setSelectedAppointment(
                      null
                    )
                  }
                >

                  Close

                </button>

              </div>

            </div>

          )}

        </div>

      </main>

    </div>

  );

}


export default Appointments;