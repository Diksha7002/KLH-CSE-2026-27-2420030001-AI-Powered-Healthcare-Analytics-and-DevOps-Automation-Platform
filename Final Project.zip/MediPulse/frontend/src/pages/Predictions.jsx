import { useEffect, useState } from "react";

import {
  FaBrain,
  FaUsers,
  FaBed,
  FaExclamationTriangle,
  FaArrowUp,
  FaArrowDown
} from "react-icons/fa";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import { getPredictions } from "../services/api";


function Predictions() {

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);


  // ================= LOAD ML PREDICTIONS =================

  useEffect(() => {

    const loadPredictions = async () => {

      try {

        setLoading(true);

        const result = await getPredictions();

        setData(result);
        setError("");

      } catch (err) {

        console.error("Predictions API error:", err);

        setData(null);
        setError(
          err.message === "Failed to fetch"
            ? "Unable to reach the MediPulse server. Make sure the backend is running on port 5000."
            : err.message
        );

      } finally {

        setLoading(false);

      }

    };

    loadPredictions();

  }, [reloadKey]);


  const summary = data ? data.summary : null;

  const sortedDepartments = data
    ? [...data.departments].sort(
        (a, b) => b.demandChangePct - a.demandChangePct
      )
    : [];


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">


          {/* HEADER */}

          <div className="page-header">

            <div>

              <h1>
                Predictions & Analytics
              </h1>

              <p>
                AI-powered predictions for hospital operations
              </p>

            </div>

          </div>


          {/* LOADING */}

          {loading && !data && (

            <div className="page-state">
              Running prediction model...
            </div>

          )}


          {/* ERROR */}

          {error && (

            <div className="page-state error">

              {error}

              <button onClick={() => setReloadKey((key) => key + 1)}>
                Retry
              </button>

            </div>

          )}


          {data && (

            <>

              {data.dataStaleDays > 2 && (

                <div className="prediction-note">
                  Historical data ends on {data.dataThrough}. Run
                  generate_dataset.py and train_model.py in the ml folder
                  to refresh the model with recent data.
                </div>

              )}


              {/* PREDICTION SUMMARY */}

              <div className="prediction-summary">


                <div className="prediction-card">

                  <div className="prediction-card-icon">
                    <FaUsers />
                  </div>

                  <div>

                    <span>
                      Tomorrow's Patient Demand
                    </span>

                    <h2>
                      {summary.tomorrowDemand}
                    </h2>

                    <p
                      className={
                        summary.demandChangePct >= 0
                          ? "prediction-up"
                          : "prediction-warning"
                      }
                    >
                      {summary.demandChangePct >= 0
                        ? <FaArrowUp />
                        : <FaArrowDown />}
                      {" "}
                      {Math.abs(summary.demandChangePct)}%{" "}
                      {summary.demandChangePct >= 0
                        ? "above"
                        : "below"}{" "}
                      7-day average
                    </p>

                  </div>

                </div>


                <div className="prediction-card">

                  <div className="prediction-card-icon">
                    <FaBed />
                  </div>

                  <div>

                    <span>
                      Predicted Bed Occupancy
                    </span>

                    <h2>
                      {summary.predictedOccupancy}%
                    </h2>

                    <p
                      className={
                        summary.occupancyChange >= 0
                          ? "prediction-up"
                          : "prediction-warning"
                      }
                    >
                      {summary.occupancyChange >= 0
                        ? <FaArrowUp />
                        : <FaArrowDown />}
                      {" "}
                      {Math.abs(summary.occupancyChange)}% from current (
                      {summary.currentOccupancy}%)
                    </p>

                  </div>

                </div>


                <div className="prediction-card">

                  <div className="prediction-card-icon">
                    <FaExclamationTriangle />
                  </div>

                  <div>

                    <span>
                      Risk Alerts
                    </span>

                    <h2>
                      {summary.riskAlerts}
                    </h2>

                    <p className="prediction-warning">
                      {summary.riskAlerts > 0
                        ? "Requires attention"
                        : "No active alerts"}
                    </p>

                  </div>

                </div>


              </div>


              {/* PATIENT DEMAND CHART */}

              <div className="chart-card prediction-chart-card">

                <div className="card-header">

                  <div>

                    <h3>
                      Patient Demand Prediction
                    </h3>

                    <p>
                      Historical patient volume and predicted demand
                    </p>

                  </div>


                  <div className="prediction-legend">

                    <span>
                      <i className="legend-actual"></i>
                      Actual
                    </span>

                    <span>
                      <i className="legend-predicted"></i>
                      Predicted
                    </span>

                  </div>

                </div>


                <div className="chart-container">

                  <ResponsiveContainer
                    width="100%"
                    height={320}
                  >

                    <LineChart data={data.chart}>

                      <CartesianGrid strokeDasharray="3 3" />

                      <XAxis dataKey="label" />

                      <YAxis domain={[0, "dataMax + 10"]} />

                      <Tooltip />


                      <Line
                        type="monotone"
                        dataKey="actual"
                        name="Actual"
                        stroke="#0d9488"
                        strokeWidth={3}
                        dot={{ r: 4 }}
                        connectNulls={false}
                      />


                      <Line
                        type="monotone"
                        dataKey="predicted"
                        name="Predicted"
                        stroke="#1e3a5f"
                        strokeWidth={3}
                        strokeDasharray="6 5"
                        dot={{ r: 4 }}
                      />

                    </LineChart>

                  </ResponsiveContainer>

                </div>

              </div>


              {/* TWO COLUMN SECTION */}

              <div className="prediction-grid">


                {/* DEPARTMENT FORECAST */}

                <div className="chart-card">

                  <div className="card-header">

                    <div>

                      <h3>
                        Department Forecast
                      </h3>

                      <p>
                        Expected patient demand on {data.forecastDate}
                      </p>

                    </div>

                  </div>


                  <div className="forecast-list">

                    {sortedDepartments.map((dept) => (

                      <div
                        className="forecast-item"
                        key={dept.department}
                      >

                        <div>

                          <strong>
                            {dept.department}
                          </strong>

                          <span>
                            {dept.demandLevel}
                          </span>

                          <span className="forecast-sub">
                            {dept.predictedVisits} visits ·{" "}
                            {dept.predictedOccupancy}% bed occupancy
                          </span>

                        </div>

                        <div
                          className={
                            dept.demandChangePct < 0
                              ? "forecast-value down"
                              : "forecast-value"
                          }
                        >

                          {dept.demandChangePct < 0
                            ? <FaArrowDown />
                            : <FaArrowUp />}

                          <strong>
                            {Math.abs(dept.demandChangePct)}%
                          </strong>

                        </div>

                      </div>

                    ))}

                  </div>

                </div>


                {/* RISK ALERTS */}

                <div className="chart-card">

                  <div className="card-header">

                    <div>

                      <h3>
                        Prediction Alerts
                      </h3>

                      <p>
                        Areas requiring attention
                      </p>

                    </div>

                  </div>


                  {data.alerts.length === 0 && (

                    <div className="prediction-alert-empty">
                      No risks detected. All departments are within
                      normal ranges.
                    </div>

                  )}


                  {data.alerts.map((alert) => (

                    <div
                      className="prediction-alert"
                      key={alert.id}
                    >

                      <div
                        className={
                          alert.severity === "critical"
                            ? "alert-icon critical"
                            : "alert-icon"
                        }
                      >
                        <FaExclamationTriangle />
                      </div>

                      <div>

                        <strong>
                          {alert.title}
                        </strong>

                        <p>
                          {alert.message}
                        </p>

                      </div>

                    </div>

                  ))}

                </div>


              </div>


              {/* MODEL INFORMATION */}

              <div className="ai-model-card">

                <div className="ai-model-icon">

                  <FaBrain />

                </div>


                <div>

                  <h3>
                    AI Prediction Model
                  </h3>

                  <p>
                    {data.model.type} trained on{" "}
                    {data.model.dataset_rows.toLocaleString()} historical
                    hospital records ({data.model.dataset_start} to{" "}
                    {data.model.dataset_end}), then applied to the last
                    14 days of this hospital's database and its live bed
                    occupancy.
                  </p>

                </div>


                <div className="model-metrics">

                  <div>
                    <span>Occupancy R²</span>
                    <strong>{data.model.occupancy_r2}</strong>
                  </div>

                  <div>
                    <span>Visits R²</span>
                    <strong>{data.model.visits_r2}</strong>
                  </div>

                </div>


                <div className="model-status">

                  <span>
                    Model Status
                  </span>

                  <strong>
                    Active
                  </strong>

                </div>

              </div>

            </>

          )}


        </div>

      </main>

    </div>

  );
}


export default Predictions;
