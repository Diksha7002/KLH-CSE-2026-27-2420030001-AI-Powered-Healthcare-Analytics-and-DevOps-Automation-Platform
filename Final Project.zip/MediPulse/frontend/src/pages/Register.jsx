import Logo from "../components/Logo";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  FaUser,
  FaLock,
  FaArrowLeft
} from "react-icons/fa";

import { registerPatient } from "../services/api";


function Register() {

  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    username: "",
    password: "",
    confirmPassword: "",
    age: "",
    gender: ""
  });

  const [error, setError] =
    useState("");

  const [success, setSuccess] =
    useState("");

  const [loading, setLoading] =
    useState(false);


  const handleChange = (e) => {

    const { name, value } = e.target;

    setForm({
      ...form,
      [name]: value
    });

  };


  const handleSubmit = async (e) => {

    e.preventDefault();

    setError("");
    setSuccess("");


    if (
      !form.name ||
      !form.username ||
      !form.password ||
      !form.confirmPassword
    ) {
      setError(
        "Please fill all required fields."
      );

      return;
    }


    if (
      form.password !==
      form.confirmPassword
    ) {
      setError(
        "Passwords do not match."
      );

      return;
    }


    if (form.password.length < 6) {
      setError(
        "Password must contain at least 6 characters."
      );

      return;
    }


    try {

      setLoading(true);

      await registerPatient({

        name: form.name,

        username: form.username,

        password: form.password,

        age: form.age,

        gender: form.gender

      });


      setSuccess(
        "Account created successfully! Redirecting to login..."
      );


      setTimeout(() => {

        navigate("/login");

      }, 1500);


    } catch (error) {

      setError(
        error.message ||
        "Unable to create account."
      );

    } finally {

      setLoading(false);

    }

  };


  return (

    <div className="login-page">

      <div className="login-card">

        <div className="hospital-icon">
          <Logo size={64} />
        </div>


        <h1>
          Create Patient Account
        </h1>


        <p className="login-subtitle">
          Register for MediPulse Patient Portal
        </p>


        <form onSubmit={handleSubmit}>

          {/* NAME */}

          <label>
            Full Name *
          </label>

          <div className="login-input-wrapper">

            <FaUser />

            <input
              type="text"
              name="name"
              placeholder="Enter your full name"
              value={form.name}
              onChange={handleChange}
            />

          </div>


          {/* USERNAME */}

          <label>
            Username *
          </label>

          <div className="login-input-wrapper">

            <FaUser />

            <input
              type="text"
              name="username"
              placeholder="Choose a username"
              value={form.username}
              onChange={handleChange}
            />

          </div>


          {/* AGE */}

          <label>
            Age
          </label>

          <div className="login-input-wrapper">

            <input
              type="number"
              name="age"
              placeholder="Enter your age"
              value={form.age}
              onChange={handleChange}
            />

          </div>


          {/* GENDER */}

          <label>
            Gender
          </label>

          <div className="login-input-wrapper">

            <select
              name="gender"
              value={form.gender}
              onChange={handleChange}
            >

              <option value="">
                Select gender
              </option>

              <option value="Male">
                Male
              </option>

              <option value="Female">
                Female
              </option>

              <option value="Other">
                Other
              </option>

            </select>

          </div>


          {/* PASSWORD */}

          <label>
            Password *
          </label>

          <div className="login-input-wrapper">

            <FaLock />

            <input
              type="password"
              name="password"
              placeholder="Create a password"
              value={form.password}
              onChange={handleChange}
            />

          </div>


          {/* CONFIRM PASSWORD */}

          <label>
            Confirm Password *
          </label>

          <div className="login-input-wrapper">

            <FaLock />

            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirm your password"
              value={
                form.confirmPassword
              }
              onChange={handleChange}
            />

          </div>


          {/* ERROR */}

          {error && (

            <p className="login-error">
              {error}
            </p>

          )}


          {/* SUCCESS */}

          {success && (

            <p
              style={{
                color: "green",
                marginTop: "10px"
              }}
            >
              {success}
            </p>

          )}


          {/* SUBMIT */}

          <button
            type="submit"
            disabled={loading}
          >

            {loading
              ? "Creating Account..."
              : "Create Account"}

          </button>


        </form>


        {/* BACK TO LOGIN */}

        <button
          type="button"
          className="register-link"
          onClick={() =>
            navigate("/login")
          }
          style={{
            marginTop: "15px"
          }}
        >

          <FaArrowLeft />
          {" "} Back to Login

        </button>


      </div>

    </div>

  );

}


export default Register;