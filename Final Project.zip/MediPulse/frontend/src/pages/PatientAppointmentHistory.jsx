import Logo from "../components/Logo";
import { useState, useEffect } from "react";
import {
  FaCalendarCheck,
  FaArrowLeft,
  FaClock,
  FaUserMd,
  FaTimesCircle
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import {
  getAppointments,
  updateAppointmentStatus
} from "../services/api";

function PatientAppointmentHistory() {

  const navigate = useNavigate();

  // ================= PATIENT NAME =================

  const patientName =
    localStorage.getItem("userName") || "Rahul Sharma";


  // ================= APPOINTMENTS =================

  const [appointments, setAppointments] = useState([]);

  const [loading, setLoading] = useState(true);


  // ================= LOAD APPOINTMENTS =================

  useEffect(() => {

    const loadAppointments = async () => {

      try {

        const data = await getAppointments();

        // Show only appointments belonging
        // to the currently logged-in patient
        const patientAppointments = data.filter(
          (appointment) =>
            appointment.patient === patientName
        );

        setAppointments(patientAppointments);

      } catch (error) {

        console.error(
          "Failed to load appointments:",
          error
        );

      } finally {

        setLoading(false);

      }

    };

    loadAppointments();

  }, [patientName]);


  // ================= CANCEL APPOINTMENT =================

  const cancelAppointment = async (id) => {

    const confirmed = window.confirm(
      "Are you sure you want to cancel this appointment?"
    );

    if (!confirmed) {
      return;
    }

    try {

      const updatedAppointment =
        await updateAppointmentStatus(
          id,
          "Cancelled"
        );

      setAppointments((currentAppointments) =>
        currentAppointments.map((appointment) =>
          appointment.id === id
            ? updatedAppointment
            : appointment
        )
      );

    } catch (error) {

      console.error(
        "Failed to cancel appointment:",
        error
      );

      alert(
        "Unable to cancel appointment. Please try again."
      );

    }

  };


  // ================= COUNTS =================

  const upcomingCount =
    appointments.filter(
      (appointment) =>
        appointment.status === "Upcoming" ||
        appointment.status === "Confirmed"
    ).length;


  const completedCount =
    appointments.filter(
      (appointment) =>
        appointment.status === "Completed"
    ).length;


  // ================= RETURN =================

  return (

    <div className="patient-page">


      {/* ================= HEADER ================= */}

      <header className="patient-header">

        <div className="patient-brand">
          <Logo size={38} />
          <div>
            <h2>MediPulse</h2>
            <p>Patient Portal</p>
          </div>
        </div>


        <div className="patient-header-right">

          <span>
            {patientName}
          </span>


          <button
            className="logout-button"
            onClick={() =>
              navigate("/login")
            }
          >
            Logout
          </button>

        </div>

      </header>


      {/* ================= CONTENT ================= */}

      <main className="patient-content">


        {/* ================= BACK BUTTON ================= */}

        <button
          className="patient-back-btn"
          onClick={() =>
            navigate("/patient-dashboard")
          }
        >

          <FaArrowLeft />

          Back to Dashboard

        </button>


        {/* ================= PAGE HEADER ================= */}

        <div className="patient-welcome">

          <h1>
            My Appointments
          </h1>

          <p>
            View and manage your upcoming and previous appointments.
          </p>

        </div>


        {/* ================= SUMMARY ================= */}

        <div className="patient-cards">


          {/* UPCOMING */}

          <div className="patient-card">

            <div className="patient-card-icon">

              <FaCalendarCheck />

            </div>


            <div>

              <p>
                Upcoming
              </p>

              <h2>
                {upcomingCount}
              </h2>

              <span>
                Scheduled appointments
              </span>

            </div>

          </div>


          {/* COMPLETED */}

          <div className="patient-card">

            <div className="patient-card-icon">

              <FaClock />

            </div>


            <div>

              <p>
                Completed
              </p>

              <h2>
                {completedCount}
              </h2>

              <span>
                Previous visits
              </span>

            </div>

          </div>


        </div>


        {/* ================= APPOINTMENT LIST ================= */}

        <div className="patient-section">


          {/* HEADER */}

          <div className="patient-appointment-header">

            <div>

              <h2>
                Appointment History
              </h2>

              <p>
                Your recent and upcoming appointments
              </p>

            </div>


            <button
              className="new-appointment-btn"
              onClick={() =>
                navigate("/patient/appointments")
              }
            >

              <FaCalendarCheck />

              Book Appointment

            </button>

          </div>


          {/* LIST */}

          <div className="patient-appointment-list">


            {/* LOADING */}

            {loading && (

              <div className="empty-appointment">

                <FaCalendarCheck />

                <p>
                  Loading appointments...
                </p>

              </div>

            )}


            {/* NO APPOINTMENTS */}

            {!loading &&
              appointments.length === 0 && (

                <div className="empty-appointment">

                  <FaCalendarCheck />

                  <p>
                    No appointments found.
                  </p>


                  <button
                    onClick={() =>
                      navigate(
                        "/patient/appointments"
                      )
                    }
                    className="confirm-booking-btn"
                  >

                    Book an Appointment

                  </button>

                </div>

              )}


            {/* APPOINTMENTS */}

            {!loading &&
              appointments.map(
                (appointment) => (

                  <div
                    className="patient-appointment-item"
                    key={appointment.id}
                  >


                    {/* ================= DOCTOR ================= */}

                    <div className="appointment-doctor">

                      <div className="doctor-small-avatar">

                        <FaUserMd />

                      </div>


                      <div>

                        <strong>
                          {appointment.doctor}
                        </strong>

                        <span>
                          {appointment.department}
                        </span>

                      </div>

                    </div>


                    {/* ================= DATE ================= */}

                    <div className="appointment-detail">

                      <span>
                        Date
                      </span>

                      <strong>
                        {appointment.date}
                      </strong>

                    </div>


                    {/* ================= TIME ================= */}

                    <div className="appointment-detail">

                      <span>
                        Time
                      </span>

                      <strong>
                        {appointment.time}
                      </strong>

                    </div>


                    {/* ================= TYPE ================= */}

                    <div className="appointment-detail">

                      <span>
                        Type
                      </span>

                      <strong>
                        {appointment.type}
                      </strong>

                    </div>


                    {/* ================= STATUS ================= */}

                    <div className="appointment-actions">


                      <span
                        className={`appointment-status ${
                          appointment.status
                            .toLowerCase()
                            .replace(/\s+/g, "-")
                        }`}
                      >
                        {appointment.status}
                      </span>


                      {/* CANCEL */}

                      {(appointment.status === "Upcoming" ||
                        appointment.status === "Confirmed") && (

                        <button
                          className="cancel-appointment-btn"
                          onClick={() =>
                            cancelAppointment(
                              appointment.id
                            )
                          }
                        >

                          <FaTimesCircle />

                          Cancel

                        </button>

                      )}

                    </div>


                  </div>

                )
              )}

          </div>

        </div>


      </main>

    </div>

  );
}

export default PatientAppointmentHistory;