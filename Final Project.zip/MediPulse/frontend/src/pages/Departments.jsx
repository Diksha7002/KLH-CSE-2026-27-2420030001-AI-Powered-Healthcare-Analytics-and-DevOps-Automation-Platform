import { useEffect, useState } from "react";

import {
  FaBuilding,
  FaUserMd,
  FaUserInjured,
  FaBed,
  FaSearch
} from "react-icons/fa";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import { getDepartments, getBeds } from "../services/api";


function Departments() {

  const [departments, setDepartments] = useState([]);
  const [beds, setBeds] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);


  // LOAD DEPARTMENTS AND BEDS
  const loadData = async () => {

    try {

      setLoading(true);

      const [departmentData, bedData] = await Promise.all([
        getDepartments(),
        getBeds()
      ]);

      setDepartments(departmentData);
      setBeds(bedData);

    } catch (error) {

      console.error("Failed to load department data:", error);

    } finally {

      setLoading(false);

    }

  };


  useEffect(() => {

    loadData();

  }, []);


  // CALCULATE BED INFORMATION
  const getBedStats = (departmentName) => {

    const departmentBeds = beds.filter(
      (bed) => bed.department === departmentName
    );

    const totalBeds = departmentBeds.length;

    const occupiedBeds = departmentBeds.filter(
      (bed) => bed.status === "Occupied"
    ).length;

    const availableBeds = departmentBeds.filter(
      (bed) => bed.status === "Available"
    ).length;

    const occupancy =
      totalBeds === 0
        ? 0
        : Math.round((occupiedBeds / totalBeds) * 100);

    return {
      totalBeds,
      availableBeds,
      occupancy
    };

  };


  // SEARCH
  const filteredDepartments = departments.filter((department) => {

    const text = `
      ${department.name || ""}
      ${department.code || ""}
    `.toLowerCase();

    return text.includes(search.toLowerCase());

  });


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">


          {/* HEADER */}

          <div className="page-header">

            <div>

              <h1>
                Departments
              </h1>

              <p>
                Monitor department performance and resource utilization
              </p>

            </div>

          </div>


          {/* SEARCH */}

          <div className="patients-toolbar">

            <div className="search-box">

              <FaSearch />

              <input
                type="text"
                placeholder="Search departments..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />

            </div>

          </div>


          {/* LOADING */}

          {loading ? (

            <div className="empty-state">
              Loading departments...
            </div>

          ) : (


            /* DEPARTMENT CARDS */

            <div className="department-grid">

              {filteredDepartments.length > 0 ? (

                filteredDepartments.map((department) => {

                  const bedStats =
                    getBedStats(department.name);


                  return (

                    <div
                      className="department-card"
                      key={department.id}
                    >


                      {/* CARD HEADER */}

                      <div className="department-card-header">

                        <div className="department-icon">

                          <FaBuilding />

                        </div>

                        <div>

                          <h3>
                            {department.name}
                          </h3>

                          <span>
                            {department.name
                              .substring(0, 4)
                              .toUpperCase()}
                          </span>

                        </div>

                      </div>


                      {/* STATISTICS */}

                      <div className="department-stats">


                        <div className="department-stat">

                          <FaUserMd />

                          <div>

                            <span>
                              Doctors
                            </span>

                            <strong>
                              {department.doctorCount}
                            </strong>

                          </div>

                        </div>


                        <div className="department-stat">

                          <FaUserInjured />

                          <div>

                            <span>
                              Patients
                            </span>

                            <strong>
                              {department.patientCount}
                            </strong>

                          </div>

                        </div>


                        <div className="department-stat">

                          <FaBed />

                          <div>

                            <span>
                              Available Beds
                            </span>

                            <strong>
                              {bedStats.availableBeds}
                            </strong>

                          </div>

                        </div>


                      </div>


                      {/* OCCUPANCY */}

                      <div className="department-occupancy">

                        <div className="occupancy-info">

                          <span>
                            Bed Occupancy
                          </span>

                          <strong>
                            {bedStats.occupancy}%
                          </strong>

                        </div>


                        <div className="progress-bar">

                          <div
                            className="progress-fill"
                            style={{
                              width: `${bedStats.occupancy}%`
                            }}
                          ></div>

                        </div>

                      </div>


                      {/* FOOTER */}

                      <div className="department-footer">

                        <span>
                          {bedStats.totalBeds} Total Beds
                        </span>

                        <span>
                          {bedStats.availableBeds} Available
                        </span>

                      </div>


                    </div>

                  );

                })

              ) : (

                <div className="empty-state">
                  No departments found
                </div>

              )}

            </div>

          )}


        </div>

      </main>

    </div>

  );

}


export default Departments;