import Logo from "../components/Logo";
import { useEffect, useState } from "react";

import {
  FaHospital,
  FaUserInjured,
  FaBed,
  FaUserMd,
  FaPlus,
  FaTimes,
  FaSignOutAlt
} from "react-icons/fa";

import {
  getAdmissions,
  addAdmission,
  dischargeAdmission,
  getPatients,
  getBeds,
  getDoctors
} from "../services/api";


function Admissions() {

  // ================= STATE =================

  const [admissions, setAdmissions] = useState([]);

  const [patients, setPatients] = useState([]);

  const [beds, setBeds] = useState([]);

  const [doctors, setDoctors] = useState([]);

  const [showForm, setShowForm] = useState(false);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");


  const [form, setForm] = useState({
    patient: "",
    department: "",
    doctor: "",
    bed: "",
    date: ""
  });


  // ================= LOAD DATA =================

  const loadData = async () => {

    try {

      setLoading(true);
      setError("");

      const [
        admissionsData,
        patientsData,
        bedsData,
        doctorsData
      ] = await Promise.all([
        getAdmissions(),
        getPatients(),
        getBeds(),
        getDoctors()
      ]);

      setAdmissions(admissionsData);
      setPatients(patientsData);
      setBeds(bedsData);
      setDoctors(doctorsData);

    } catch (err) {

      console.error(err);

      setError(
        "Unable to load admissions data."
      );

    } finally {

      setLoading(false);

    }
  };


  useEffect(() => {

    loadData();

  }, []);


  // ================= FORM CHANGE =================

  const handleChange = (e) => {

    const { name, value } = e.target;

    setForm({
      ...form,
      [name]: value
    });

  };


  // ================= ADD ADMISSION =================

  const handleSubmit = async (e) => {

    e.preventDefault();

    if (
      !form.patient ||
      !form.department ||
      !form.doctor ||
      !form.bed ||
      !form.date
    ) {

      alert(
        "Please fill all admission details."
      );

      return;

    }


    try {

      await addAdmission(form);

      alert(
        "Patient admitted successfully!"
      );

      setForm({
        patient: "",
        department: "",
        doctor: "",
        bed: "",
        date: ""
      });

      setShowForm(false);

      await loadData();

    } catch (err) {

      console.error(err);

      alert(
        err.message ||
        "Unable to create admission."
      );

    }

  };


  // ================= DISCHARGE =================

  const handleDischarge = async (id) => {

    const confirmDischarge =
      window.confirm(
        "Are you sure you want to discharge this patient?"
      );

    if (!confirmDischarge) return;


    try {

      await dischargeAdmission(id);

      await loadData();

    } catch (err) {

      console.error(err);

      alert(
        err.message ||
        "Unable to discharge patient."
      );

    }

  };


  // ================= AVAILABLE BEDS =================

  const availableBeds =
    beds.filter(
      (bed) =>
        bed.status === "Available"
    );


  // ================= ACTIVE ADMISSIONS =================

  const activeAdmissions =
    admissions.filter(
      (a) =>
        a.status === "Admitted"
    );


  const dischargedAdmissions =
    admissions.filter(
      (a) =>
        a.status === "Discharged"
    );


  // ================= UI =================

  return (

    <div className="app-container">


      {/* ================= SIDEBAR ================= */}

      <aside className="sidebar">

        <div className="sidebar-logo">

          <Logo size={38} />

          <div>

            <h2>MediPulse</h2>

            <span>
              Analytics
            </span>

          </div>

        </div>


        <nav>

          <a href="/dashboard">
            Dashboard
          </a>

          <a href="/patients">
            Patients
          </a>

          <a href="/appointments">
            Appointments
          </a>

          <a
            href="/admissions"
            className="active"
          >
            Admissions
          </a>

          <a href="/beds">
            Beds
          </a>

          <a href="/departments">
            Departments
          </a>

          <a href="/predictions">
            Predictions
          </a>

          <a href="/ai-assistant">
            AI Assistant
          </a>

          <a href="/reports">
            Reports
          </a>

        </nav>


        <div className="sidebar-bottom">

          <button
            onClick={() => {

              localStorage.clear();

              window.location.href =
                "/login";

            }}
          >

            <FaSignOutAlt />

            Logout

          </button>

        </div>

      </aside>


      {/* ================= MAIN ================= */}

      <main className="main-content">


        {/* HEADER */}

        <div className="top-navbar">

          <div>

            <h2>
              Admissions
            </h2>

            <span>
              Hospital admission management
            </span>

          </div>


          <button
            className="add-btn"
            onClick={() =>
              setShowForm(true)
            }
          >

            <FaPlus />

            New Admission

          </button>

        </div>


        {/* ERROR */}

        {error && (

          <div
            style={{
              background: "#fee2e2",
              color: "#b91c1c",
              padding: "12px 16px",
              borderRadius: "8px",
              marginBottom: "20px"
            }}
          >

            {error}

          </div>

        )}


        {/* ================= SUMMARY ================= */}

        <section className="stats-grid">


          <div className="stat-card">

            <div className="stat-icon">

              <FaHospital />

            </div>

            <div>

              <p>
                Active Admissions
              </p>

              <h2>
                {activeAdmissions.length}
              </h2>

              <span>
                Currently admitted
              </span>

            </div>

          </div>


          <div className="stat-card">

            <div className="stat-icon">

              <FaBed />

            </div>

            <div>

              <p>
                Available Beds
              </p>

              <h2>
                {availableBeds.length}
              </h2>

              <span>
                Ready for admission
              </span>

            </div>

          </div>


          <div className="stat-card">

            <div className="stat-icon">

              <FaUserInjured />

            </div>

            <div>

              <p>
                Total Admissions
              </p>

              <h2>
                {admissions.length}
              </h2>

              <span>
                All admission records
              </span>

            </div>

          </div>


          <div className="stat-card">

            <div className="stat-icon">

              <FaSignOutAlt />

            </div>

            <div>

              <p>
                Discharged
              </p>

              <h2>
                {dischargedAdmissions.length}
              </h2>

              <span>
                Completed admissions
              </span>

            </div>

          </div>


        </section>


        {/* ================= TABLE ================= */}

        <section className="content-card">

          <div className="card-header">

            <div>

              <h3>
                Current Admissions
              </h3>

              <p>
                Patients currently admitted
              </p>

            </div>

          </div>


          {loading ? (

            <div className="empty-state">

              Loading admissions...

            </div>

          ) : activeAdmissions.length === 0 ? (

            <div className="empty-state">

              No active admissions.

            </div>

          ) : (

            <div className="table-container">

              <table>

                <thead>

                  <tr>

                    <th>
                      Patient
                    </th>

                    <th>
                      Department
                    </th>

                    <th>
                      Doctor
                    </th>

                    <th>
                      Bed
                    </th>

                    <th>
                      Admission Date
                    </th>

                    <th>
                      Status
                    </th>

                    <th>
                      Action
                    </th>

                  </tr>

                </thead>


                <tbody>

                  {activeAdmissions.map(
                    (admission) => (

                      <tr
                        key={admission.id}
                      >

                        <td>

                          <strong>
                            {admission.patient}
                          </strong>

                        </td>


                        <td>
                          {admission.department}
                        </td>


                        <td>
                          {admission.doctor}
                        </td>


                        <td>

                          <span className="bed-badge">

                            {admission.bed}

                          </span>

                        </td>


                        <td>
                          {admission.date}
                        </td>


                        <td>

                          <span className="status-badge confirmed">

                            {admission.status}

                          </span>

                        </td>


                        <td>

                          <button
                            className="delete-btn"
                            onClick={() =>
                              handleDischarge(
                                admission.id
                              )
                            }
                          >

                            Discharge

                          </button>

                        </td>

                      </tr>

                    )
                  )}

                </tbody>

              </table>

            </div>

          )}

        </section>


        {/* ================= FORM MODAL ================= */}

        {showForm && (

          <div className="modal-overlay">

            <div className="modal-card">


              <div className="modal-header">

                <div>

                  <h2>
                    New Admission
                  </h2>

                  <p>
                    Admit a patient to the hospital
                  </p>

                </div>


                <button
                  onClick={() =>
                    setShowForm(false)
                  }
                >

                  <FaTimes />

                </button>

              </div>


              <form
                onSubmit={handleSubmit}
                className="appointment-form"
              >


                {/* PATIENT */}

                <label>
                  Patient
                </label>

                <select
                  name="patient"
                  value={form.patient}
                  onChange={handleChange}
                >

                  <option value="">
                    Select patient
                  </option>

                  {patients.map(
                    (patient) => (

                      <option
                        key={patient.id}
                        value={patient.name}
                      >

                        {patient.name}

                      </option>

                    )
                  )}

                </select>


                {/* DEPARTMENT */}

                <label>
                  Department
                </label>

                <select
                  name="department"
                  value={form.department}
                  onChange={handleChange}
                >

                  <option value="">
                    Select department
                  </option>

                  <option value="Cardiology">
                    Cardiology
                  </option>

                  <option value="General Medicine">
                    General Medicine
                  </option>

                  <option value="Neurology">
                    Neurology
                  </option>

                  <option value="Orthopedics">
                    Orthopedics
                  </option>

                  <option value="Pediatrics">
                    Pediatrics
                  </option>
                  <option value="Emergency">
                    Emergency
                  </option>
                  <option value="ICU">
                    ICU
                  </option>

                </select>


                {/* DOCTOR */}

                <label>
                  Doctor
                </label>

                <select
                  name="doctor"
                  value={form.doctor}
                  onChange={handleChange}
                >

                  <option value="">
                    Select doctor
                  </option>

                  {doctors.map(
                    (doctor) => (

                      <option
                        key={doctor.id}
                        value={doctor.name}
                      >

                        {doctor.name}

                      </option>

                    )
                  )}

                </select>


                {/* BED */}

                <label>
                  Bed
                </label>

                <select
                  name="bed"
                  value={form.bed}
                  onChange={handleChange}
                >

                  <option value="">
                    Select available bed
                  </option>

                  {availableBeds.map(
                    (bed) => (

                      <option
                        key={bed.id}
                        value={bed.bedNumber}
                      >

                        {bed.bedNumber}
                        {" - "}
                        {bed.department}

                      </option>

                    )
                  )}

                </select>


                {/* DATE */}

                <label>
                  Admission Date
                </label>

                <input
                  type="date"
                  name="date"
                  value={form.date}
                  onChange={handleChange}
                />


                {/* ACTIONS */}

                <div className="modal-actions">

                  <button
                    type="button"
                    onClick={() =>
                      setShowForm(false)
                    }
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="primary-btn"
                  >
                    Admit Patient
                  </button>

                </div>


              </form>

            </div>

          </div>

        )}

      </main>

    </div>

  );
}

export default Admissions;