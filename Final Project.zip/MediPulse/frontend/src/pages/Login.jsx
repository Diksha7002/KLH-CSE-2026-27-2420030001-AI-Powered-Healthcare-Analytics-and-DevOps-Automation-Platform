import Logo from "../components/Logo";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FaUser,
  FaLock,
  FaEye,
  FaEyeSlash
} from "react-icons/fa";

import { loginUser } from "../services/api";

function Login() {
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [showPassword, setShowPassword] =
    useState(false);

  const [error, setError] = useState("");

  const [loading, setLoading] =
    useState(false);


  const handleLogin = async (e) => {
    e.preventDefault();

    setError("");

    if (!username || !password) {
      setError(
        "Please enter username and password."
      );
      return;
    }

    try {
      setLoading(true);

      const data = await loginUser({
        username,
        password
      });

      const user = data.user;

      // Save logged-in user
      localStorage.setItem(
        "userId",
        user.id
      );

      localStorage.setItem(
        "userName",
        user.name
      );

      localStorage.setItem(
        "userRole",
        user.role
      );

      localStorage.setItem(
        "loggedInUsername",
        user.username
      );


      // Redirect according to role
      if (user.role === "doctor") {
        navigate("/dashboard");
      } else {
        navigate("/patient-dashboard");
      }

    } catch (error) {
      setError(
        error.message ||
        "Invalid username or password"
      );
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="login-page">

      <div className="login-card">

        <div className="hospital-icon">
          <Logo size={64} />
        </div>

        <h1>Welcome to MediPulse</h1>

        <p className="login-subtitle">
          Hospital Analytics & Management Platform
        </p>


        <form onSubmit={handleLogin}>

          <label>Username</label>

          <div className="login-input-wrapper">

            <FaUser />

            <input
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) =>
                setUsername(e.target.value)
              }
            />

          </div>


          <label>Password</label>

          <div className="login-input-wrapper">

            <FaLock />

            <input
              type={
                showPassword
                  ? "text"
                  : "password"
              }
              placeholder="Enter your password"
              value={password}
              onChange={(e) =>
                setPassword(e.target.value)
              }
            />

            <button
              type="button"
              className="password-toggle"
              onClick={() =>
                setShowPassword(
                  !showPassword
                )
              }
              title={
                showPassword
                  ? "Hide password"
                  : "Show password"
              }
            >
              {showPassword ? (
                <FaEyeSlash />
              ) : (
                <FaEye />
              )}
            </button>

          </div>


          {error && (
            <p className="login-error">
              {error}
            </p>
          )}


          <button
            type="submit"
            disabled={loading}
          >
            {loading
              ? "Logging in..."
              : "Login"}
          </button>

        </form>


        <div className="register-section">

          <p>
            Don't have a patient account?
          </p>

          <button
            type="button"
            className="register-link"
            onClick={() =>
              navigate("/register")
            }
          >
            Create Patient Account
          </button>

        </div>

      </div>

    </div>
  );
}

export default Login;