import Logo from "../components/Logo";
import { useEffect, useState } from "react";
import {
  FaArrowLeft,
  FaFileMedical,
  FaEye,
  FaDownload,
  FaCalendarAlt,
  FaUserMd
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { getRecords } from "../services/api";
import { formatDisplayDate } from "../utils/dates";

function PatientRecords() {

  const navigate = useNavigate();

  const [selectedRecord, setSelectedRecord] = useState(null);

  const patientName = localStorage.getItem("userName") || "";
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  // ================= LOAD FROM DATABASE =================
  useEffect(() => {
    const load = async () => {
      try {
        const data = await getRecords(patientName);
        setRecords(data.map((item) => ({ ...item, date: formatDisplayDate(item.date) })));
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [patientName]);

  return (
    <div className="patient-page">

      {/* HEADER */}

      <header className="patient-header">

        <div className="patient-brand">
          <Logo size={38} />
          <div>
            <h2>MediPulse</h2>
            <p>Patient Portal</p>
          </div>
        </div>

        <div className="patient-header-right">

          <span>{patientName}</span>

          <button
            className="logout-button"
            onClick={() => navigate("/login")}
          >
            Logout
          </button>

        </div>

      </header>


      {/* MAIN CONTENT */}

      <main className="patient-content">

        {/* BACK BUTTON */}

        <button
          className="patient-back-btn"
          onClick={() => navigate("/patient-dashboard")}
        >
          <FaArrowLeft />
          Back to Dashboard
        </button>


        {/* PAGE TITLE */}

        <div className="patient-welcome">

          <div>
            <h1>Medical Records</h1>

            <p>
              View your medical history and consultation records.
            </p>
          </div>

        </div>


        {/* RECORDS CARD */}

        <div className="records-card">

          <div className="records-header">

            <div className="records-title">

              <div className="records-icon">
                <FaFileMedical />
              </div>

              <div>
                <h2>Your Medical Records</h2>
                <p>
                  {records.length} medical records available
                </p>
              </div>

            </div>

          </div>


          {/* RECORD LIST */}

          <div className="records-list">
            {!loading && records.length === 0 && (
              <p style={{ padding: "20px", color: "#6b7280" }}>
                No medical records on file yet.
              </p>
            )}

            {records.map((record) => (

              <div
                className="record-item"
                key={record.id}
              >

                <div className="record-main">

                  <div className="record-file-icon">
                    <FaFileMedical />
                  </div>

                  <div className="record-info">

                    <h3>{record.type}</h3>

                    <p>
                      <FaUserMd />
                      {record.doctor}
                    </p>

                    <span>
                      {record.department}
                    </span>

                  </div>

                </div>


                <div className="record-date">

                  <FaCalendarAlt />

                  <span>
                    {record.date}
                  </span>

                </div>


                <div className="record-status">
                  {record.status}
                </div>


                <button
                  className="record-view-btn"
                  onClick={() => setSelectedRecord(record)}
                >
                  <FaEye />
                  View
                </button>

              </div>

            ))}

          </div>

        </div>


        {/* RECORD DETAILS MODAL */}

        {selectedRecord && (

          <div className="record-modal-overlay">

            <div className="record-modal">

              <button
                className="record-modal-close"
                onClick={() => setSelectedRecord(null)}
              >
                ×
              </button>

              <div className="modal-icon">
                <FaFileMedical />
              </div>

              <h2>{selectedRecord.type}</h2>

              <p className="modal-date">
                {selectedRecord.date}
              </p>


              <div className="modal-details">

                <div>
                  <span>Doctor</span>
                  <strong>
                    {selectedRecord.doctor}
                  </strong>
                </div>

                <div>
                  <span>Department</span>
                  <strong>
                    {selectedRecord.department}
                  </strong>
                </div>

                <div>
                  <span>Diagnosis</span>
                  <strong>
                    {selectedRecord.diagnosis}
                  </strong>
                </div>

                <div>
                  <span>Status</span>
                  <strong>
                    {selectedRecord.status}
                  </strong>
                </div>

              </div>


              <button
                className="modal-download-btn"
                onClick={() => alert("Medical record download feature will be connected to the backend later.")}
              >
                <FaDownload />
                Download Record
              </button>

            </div>

          </div>

        )}

      </main>

    </div>
  );
}

export default PatientRecords;