import Logo from "../components/Logo";
import {
  FaUserCircle,
  FaCalendarCheck,
  FaFileMedical,
  FaPrescriptionBottleAlt,
  FaFlask,
  FaHeartbeat,
  FaUserMd,
  FaClock,
  FaSignOutAlt
} from "react-icons/fa";

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import {
  getAppointments,
  getLabs,
  getPatients,
  getPrescriptions,
  getRecords
} from "../services/api";
import { formatShortDay, formatYear, timeAgo } from "../utils/dates";

function PatientDashboard() {

  const navigate = useNavigate();


  // ================= PATIENT NAME =================

  const patientName =
    localStorage.getItem("userName") || "Rahul Sharma";


  // ================= APPOINTMENTS =================

  const [upcomingAppointments, setUpcomingAppointments] =
    useState([]);

  const [loadingAppointments, setLoadingAppointments] =
    useState(true);


  // ================= LOAD APPOINTMENTS =================

 useEffect(() => {

  const loadAppointments = async () => {

    try {

      const data = await getAppointments();

      const patientAppointments =
        data.filter(
          (appointment) =>
            appointment.patient === patientName
        );

      const upcoming =
        patientAppointments.filter(
          (appointment) =>
            appointment.status === "Upcoming" ||
            appointment.status === "Confirmed"
        );

      setUpcomingAppointments(
        upcoming
      );

    } catch (error) {

      console.error(
        "Failed to load appointments:",
        error
      );

    } finally {

      setLoadingAppointments(false);

    }

  };

  loadAppointments();

}, [patientName]);

  // ================= PORTAL DATA FROM THE DATABASE =================

  const [portal, setPortal] = useState({
    records: 0,
    labs: 0,
    activePrescriptions: 0,
    profile: null,
    lastCheckup: null,
    nextAppointment: null,
    latestLab: null,
    latestPrescription: null
  });

  useEffect(() => {

    const loadPortal = async () => {

      try {

        const today = new Date().toISOString().split("T")[0];

        const [records, labs, prescriptions, patients, appointments] =
          await Promise.all([
            getRecords(patientName),
            getLabs(patientName),
            getPrescriptions(patientName),
            getPatients(),
            getAppointments(patientName)
          ]);

        const completed = appointments
          .filter((item) => item.status === "Completed" && item.date <= today)
          .sort((a, b) => b.date.localeCompare(a.date));

        const upcoming = appointments
          .filter(
            (item) =>
              (item.status === "Upcoming" || item.status === "Confirmed") &&
              item.date >= today
          )
          .sort((a, b) => a.date.localeCompare(b.date));

        setPortal({
          records: records.length,
          labs: labs.length,
          activePrescriptions: prescriptions.filter(
            (item) => item.status === "Active"
          ).length,
          profile: patients.find((item) => item.name === patientName) || null,
          lastCheckup: completed.length ? completed[0].date : null,
          nextAppointment: upcoming.length ? upcoming[0] : null,
          latestLab: labs.length ? labs[0] : null,
          latestPrescription: prescriptions.length ? prescriptions[0] : null
        });

      } catch (error) {

        console.error("Failed to load patient portal data:", error);

      }

    };

    loadPortal();

  }, [patientName]);


  // ================= LOGOUT =================

  const handleLogout = () => {

    localStorage.removeItem("userRole");
    localStorage.removeItem("userName");

    navigate("/login");

  };


  // ================= RETURN =================

  return (

    <div className="patient-page">


      {/* ================= HEADER ================= */}

      <header className="patient-header">

        <div className="patient-brand">

          <Logo size={38} />

          <div>

            <h2>MediPulse</h2>

            <p>Patient Portal</p>

          </div>

        </div>


        <div className="patient-header-right">

          <div className="patient-notification">
            🔔
          </div>


          <div className="patient-profile">

            <FaUserCircle />

            <div>

              <strong>
                {patientName}
              </strong>

              <span>
                Patient
              </span>

            </div>

          </div>


          <button
            className="logout-button"
            onClick={handleLogout}
          >

            <FaSignOutAlt />

            Logout

          </button>

        </div>

      </header>


      {/* ================= CONTENT ================= */}

      <main className="patient-content">


        {/* ================= WELCOME ================= */}

        <section className="patient-welcome">

          <div>

            <p className="patient-small-title">
              PATIENT PORTAL
            </p>

            <h1>
              Welcome back,{" "}
              {patientName.split(" ")[0]} 👋
            </h1>

            <p>
              Manage your appointments, medical records
              and healthcare information.
            </p>

          </div>


          <div className="health-status">

            <FaHeartbeat />

            <div>

              <span>
                Health Status
              </span>

              <strong>
                Active
              </strong>

            </div>

          </div>

        </section>


        {/* ================= QUICK STATS ================= */}

        <section className="patient-cards">


          {/* APPOINTMENTS */}

          <div className="patient-card">

            <div className="patient-card-icon">

              <FaCalendarCheck />

            </div>

            <div>

              <p>
                Upcoming Appointments
              </p>

              <h2>
                {upcomingAppointments.length}
              </h2>

              <span>
                Scheduled consultations
              </span>

            </div>

          </div>


          {/* MEDICAL RECORDS */}

          <div className="patient-card">

            <div className="patient-card-icon">

              <FaFileMedical />

            </div>

            <div>

              <p>
                Medical Records
              </p>

              <h2>
                {portal.records}
              </h2>

              <span>
                Available records
              </span>

            </div>

          </div>


          {/* PRESCRIPTIONS */}

          <div className="patient-card">

            <div className="patient-card-icon">

              <FaPrescriptionBottleAlt />

            </div>

            <div>

              <p>
                Active Prescriptions
              </p>

              <h2>
                {portal.activePrescriptions}
              </h2>

              <span>
                Current medications
              </span>

            </div>

          </div>


          {/* LAB REPORTS */}

          <div className="patient-card">

            <div className="patient-card-icon">

              <FaFlask />

            </div>

            <div>

              <p>
                Lab Reports
              </p>

              <h2>
                {portal.labs}
              </h2>

              <span>
                Available reports
              </span>

            </div>

          </div>

        </section>


        {/* ================= MAIN GRID ================= */}

        <section className="patient-dashboard-grid">


          {/* ================= UPCOMING APPOINTMENTS ================= */}

          <div className="patient-section">

            <div className="patient-card-header">

              <div>

                <h2>
                  Upcoming Appointments
                </h2>

                <p>
                  Your scheduled consultations
                </p>

              </div>


              <button
                onClick={() =>
                  navigate("/patient/my-appointments")
                }
                className="patient-view-btn"
              >

                View All

              </button>

            </div>


            <div className="appointment-list">


              {/* LOADING */}

              {loadingAppointments && (

                <div className="empty-appointment">

                  <FaCalendarCheck />

                  <p>
                    Loading appointments...
                  </p>

                </div>

              )}


              {/* NO APPOINTMENTS */}

              {!loadingAppointments &&
                upcomingAppointments.length === 0 && (

                <div className="empty-appointment">

                  <FaCalendarCheck />

                  <p>
                    No upcoming appointments.
                  </p>

                  <button
                    onClick={() =>
                      navigate("/patient/appointments")
                    }
                    className="confirm-booking-btn"
                  >

                    Book an Appointment

                  </button>

                </div>

              )}


              {/* APPOINTMENTS */}

              {!loadingAppointments &&
                upcomingAppointments
                  .slice(-3)
                  .map((appointment) => (

                  <div
                    className="patient-appointment"
                    key={appointment.id}
                  >


                    {/* DOCTOR ICON */}

                    <div className="doctor-icon">

                      <FaUserMd />

                    </div>


                    {/* DETAILS */}

                    <div className="appointment-details">

                      <strong>
                        {appointment.doctor}
                      </strong>

                      <span>
                        {appointment.department}
                      </span>


                      <div className="appointment-time">

                        <FaCalendarCheck />

                        {appointment.date}

                        <FaClock />

                        {appointment.time}

                      </div>

                    </div>


                    {/* STATUS */}

                    <span
                      className={`confirmed-badge ${appointment.status.toLowerCase()}`}
                    >
                      {appointment.status}
                    </span>

                  </div>

                ))}

            </div>

          </div>


          {/* ================= HEALTH SUMMARY ================= */}

          <div className="patient-section">

            <div className="patient-card-header">

              <div>

                <h2>
                  Health Summary
                </h2>

                <p>
                  Your latest health information
                </p>

              </div>

            </div>


            <div className="health-summary">


              <div className="health-item">

                <span>
                  Blood Pressure
                </span>

                <strong>
                  {portal.profile?.bloodPressure || "-"}
                </strong>

                <small>
                  mmHg
                </small>

              </div>


              <div className="health-item">

                <span>
                  Heart Rate
                </span>

                <strong>
                  {portal.profile?.heartRate || "-"}
                </strong>

                <small>
                  bpm
                </small>

              </div>


              <div className="health-item">

                <span>
                  Last Checkup
                </span>

                <strong>
                  {portal.lastCheckup ? formatShortDay(portal.lastCheckup) : "-"}
                </strong>

                <small>
                  {formatYear(portal.lastCheckup)}
                </small>

              </div>


              <div className="health-item">

                <span>
                  Next Checkup
                </span>

                <strong>
                  {portal.nextAppointment ? formatShortDay(portal.nextAppointment.date) : "-"}
                </strong>

                <small>
                  {formatYear(portal.nextAppointment && portal.nextAppointment.date)}
                </small>

              </div>

            </div>

          </div>

        </section>


        {/* ================= QUICK ACTIONS ================= */}

        <section className="patient-section quick-actions-card">

          <div className="patient-card-header">

            <div>

              <h2>
                Quick Actions
              </h2>

              <p>
                Access your healthcare services
              </p>

            </div>

          </div>


          <div className="quick-actions">


            {/* BOOK APPOINTMENT */}

            <button
              onClick={() =>
                navigate("/patient/appointments")
              }
            >

              <FaCalendarCheck />

              <span>
                Book Appointment
              </span>

            </button>


            {/* MEDICAL RECORDS */}

            <button
              onClick={() =>
                navigate("/patient/records")
              }
            >

              <FaFileMedical />

              <span>
                Medical Records
              </span>

            </button>


            {/* PRESCRIPTIONS */}

            <button
              onClick={() =>
                navigate("/patient/prescriptions")
              }
            >

              <FaPrescriptionBottleAlt />

              <span>
                Prescriptions
              </span>

            </button>


            {/* LAB REPORTS */}

            <button
              onClick={() =>
                navigate("/patient/labs")
              }
            >

              <FaFlask />

              <span>
                Lab Reports
              </span>

            </button>

          </div>

        </section>


        {/* ================= RECENT ACTIVITY ================= */}

        <section className="patient-section">

          <div className="patient-card-header">

            <div>

              <h2>
                Recent Activity
              </h2>

              <p>
                Latest updates from your healthcare journey
              </p>

            </div>

          </div>


          <div className="activity-list">


            {/* ACTIVITY 1 */}

            <div className="activity-item">

              <div className="activity-icon">

                <FaCalendarCheck />

              </div>

              <div>

                <strong>
                  {portal.nextAppointment ? "Upcoming appointment" : "No upcoming appointments"}
                </strong>

                <span>
                  {portal.nextAppointment
                    ? `${portal.nextAppointment.doctor} - ${portal.nextAppointment.department}, ${portal.nextAppointment.time}`
                    : "Book one from Quick Actions"}
                </span>

              </div>

              <small>
                {portal.nextAppointment ? formatShortDay(portal.nextAppointment.date) : "-"}
              </small>

            </div>


            {/* ACTIVITY 2 */}

            <div className="activity-item">

              <div className="activity-icon">

                <FaFlask />

              </div>

              <div>

                <strong>
                  {portal.latestLab ? (portal.latestLab.status === "Pending" ? "Lab report pending" : "Lab report available") : "No lab reports yet"}
                </strong>

                <span>
                  {portal.latestLab ? `${portal.latestLab.test} - ${portal.latestLab.status === "Pending" ? "awaiting results" : portal.latestLab.result}` : "Your lab results will appear here"}
                </span>

              </div>

              <small>
                {portal.latestLab ? timeAgo(portal.latestLab.date) : "-"}
              </small>

            </div>


            {/* ACTIVITY 3 */}

            <div className="activity-item">

              <div className="activity-icon">

                <FaPrescriptionBottleAlt />

              </div>

              <div>

                <strong>
                  {portal.latestPrescription ? "Prescription issued" : "No prescriptions yet"}
                </strong>

                <span>
                  {portal.latestPrescription ? `${portal.latestPrescription.medicine} - ${portal.latestPrescription.doctor}` : "Your medications will appear here"}
                </span>

              </div>

              <small>
                {portal.latestPrescription ? timeAgo(portal.latestPrescription.date) : "-"}
              </small>

            </div>


          </div>

        </section>


      </main>

    </div>

  );
}

export default PatientDashboard;