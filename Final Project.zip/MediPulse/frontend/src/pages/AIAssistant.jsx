import {
  FaRobot,
  FaPaperPlane,
  FaChartLine,
  FaBed,
  FaUserInjured,
  FaCalendarCheck
} from "react-icons/fa";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import { useState, useEffect, useRef } from "react";

import {
  askAssistant,
  getDashboardStats,
  getPredictions
} from "../services/api";


function AIAssistant() {

  const [message, setMessage] = useState("");

  const [sending, setSending] = useState(false);

  const [mode, setMode] = useState("");

  const [insights, setInsights] = useState({
    stats: null,
    predictions: null,
    loaded: false
  });

  const [messages, setMessages] = useState([
    {
      type: "ai",
      text: "Hello Doctor! I'm MediPulse AI. I can help you understand hospital operations, patient flow, appointments, bed occupancy and predictions."
    }
  ]);

  const messagesEndRef = useRef(null);


  const suggestions = [
    "Which department has the highest patient load?",
    "What is the current bed occupancy?",
    "Are emergency visits increasing?",
    "Show me today's operational insights",
    "How many beds are available?",
    "Predict tomorrow's patient demand"
  ];


  // ================= LIVE QUICK INSIGHTS =================

  useEffect(() => {

    const loadInsights = async () => {

      const [stats, predictions] = await Promise.allSettled([
        getDashboardStats(),
        getPredictions()
      ]);

      setInsights({
        stats: stats.status === "fulfilled" ? stats.value : null,
        predictions:
          predictions.status === "fulfilled" ? predictions.value : null,
        loaded: true
      });

    };

    loadInsights();

  }, []);


  // ================= AUTO SCROLL =================

  useEffect(() => {

    const container = messagesEndRef.current;

    if (container) {
      container.scrollTop = container.scrollHeight;
    }

  }, [messages, sending]);


  // ================= SEND MESSAGE =================

  const sendMessage = async (text = message) => {

    const question = text.trim();

    if (!question || sending) {
      return;
    }


    // Conversation history sent to the backend (excludes the greeting)
    const history = messages
      .slice(1)
      .map((item) => ({
        role: item.type === "user" ? "user" : "assistant",
        content: item.text
      }));


    setMessages((previous) => [
      ...previous,
      { type: "user", text: question }
    ]);

    setMessage("");
    setSending(true);


    try {

      const response = await askAssistant(question, history);

      setMode(response.source);

      setMessages((previous) => [
        ...previous,
        { type: "ai", text: response.reply }
      ]);

    } catch (err) {

      console.error("Assistant API error:", err);

      setMessages((previous) => [
        ...previous,
        {
          type: "ai",
          text:
            err.message === "Failed to fetch"
              ? "I can't reach the MediPulse server right now. Please make sure the backend is running on port 5000 and try again."
              : `Sorry, I couldn't answer that: ${err.message}`
        }
      ]);

    } finally {

      setSending(false);

    }

  };


  const { stats, predictions, loaded } = insights;


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">


          {/* HEADER */}

          <div className="page-header">

            <div>

              <h1>
                AI Assistant
              </h1>

              <p>
                Ask MediPulse AI about hospital operations and analytics
              </p>

            </div>

          </div>


          <div className="ai-assistant-layout">


            {/* CHAT */}

            <div className="ai-chat-card">


              <div className="ai-chat-header">

                <div className="ai-chat-avatar">

                  <FaRobot />

                </div>

                <div>

                  <h3>
                    MediPulse AI
                  </h3>

                  <span>
                    Hospital Analytics Assistant
                  </span>

                </div>

                <div className="ai-online">
                  Online
                  {mode === "ai" && " · Claude"}
                  {mode === "data-engine" && " · Live data engine"}
                </div>

              </div>


              {/* MESSAGES */}

              <div className="chat-messages" ref={messagesEndRef}>

                {messages.map((item, index) => (

                  <div
                    key={index}
                    className={
                      item.type === "user"
                        ? "chat-message user-message"
                        : "chat-message ai-message"
                    }
                  >

                    {item.type === "ai" && (

                      <div className="small-ai-icon">
                        <FaRobot />
                      </div>

                    )}

                    <div className="message-bubble">

                      {item.text}

                    </div>

                  </div>

                ))}


                {sending && (

                  <div className="chat-message ai-message">

                    <div className="small-ai-icon">
                      <FaRobot />
                    </div>

                    <div className="message-bubble">

                      <span className="typing-dots">
                        <i></i><i></i><i></i>
                      </span>

                    </div>

                  </div>

                )}

              </div>


              {/* INPUT */}

              <div className="chat-input-area">

                <input
                  type="text"
                  placeholder="Ask something about the hospital..."
                  value={message}
                  disabled={sending}
                  onChange={(e) =>
                    setMessage(e.target.value)
                  }
                  onKeyDown={(e) => {

                    if (e.key === "Enter") {
                      sendMessage();
                    }

                  }}
                />

                <button
                  disabled={sending}
                  onClick={() => sendMessage()}
                >

                  <FaPaperPlane />

                </button>

              </div>


            </div>


            {/* RIGHT SIDE */}

            <div className="ai-side-panel">


              {/* QUICK QUESTIONS */}

              <div className="chart-card">

                <div className="card-header">

                  <div>

                    <h3>
                      Suggested Questions
                    </h3>

                    <p>
                      Ask the AI assistant
                    </p>

                  </div>

                </div>


                <div className="suggestion-list">

                  {suggestions.map((suggestion, index) => (

                    <button
                      key={index}
                      disabled={sending}
                      onClick={() =>
                        sendMessage(suggestion)
                      }
                    >

                      {suggestion}

                    </button>

                  ))}

                </div>

              </div>


              {/* QUICK INSIGHTS */}

              <div className="chart-card">

                <div className="card-header">

                  <div>

                    <h3>
                      Quick Insights
                    </h3>

                    <p>
                      Current hospital indicators
                    </p>

                  </div>

                </div>


                <div className="quick-insight">

                  <FaBed />

                  <div>

                    <strong>
                      Bed Occupancy
                    </strong>

                    <span>
                      {stats
                        ? `${stats.occupancy}% currently occupied (${stats.occupiedBeds}/${stats.totalBeds} beds)`
                        : loaded
                          ? "Data unavailable"
                          : "Loading..."}
                    </span>

                  </div>

                </div>


                <div className="quick-insight">

                  <FaUserInjured />

                  <div>

                    <strong>
                      Patient Activity
                    </strong>

                    <span>
                      {stats
                        ? `${stats.totalPatients} patients, ${stats.admissions} currently admitted`
                        : loaded
                          ? "Data unavailable"
                          : "Loading..."}
                    </span>

                  </div>

                </div>


                <div className="quick-insight">

                  <FaCalendarCheck />

                  <div>

                    <strong>
                      Appointments
                    </strong>

                    <span>
                      {stats
                        ? `${stats.todayAppointments} scheduled today`
                        : loaded
                          ? "Data unavailable"
                          : "Loading..."}
                    </span>

                  </div>

                </div>


                <div className="quick-insight">

                  <FaChartLine />

                  <div>

                    <strong>
                      Prediction Status
                    </strong>

                    <span>
                      {predictions
                        ? `Model is active · ~${predictions.summary.tomorrowDemand} visits forecast`
                        : loaded
                          ? "Prediction service offline"
                          : "Loading..."}
                    </span>

                  </div>

                </div>


              </div>


            </div>


          </div>


        </div>

      </main>

    </div>

  );
}


export default AIAssistant;
