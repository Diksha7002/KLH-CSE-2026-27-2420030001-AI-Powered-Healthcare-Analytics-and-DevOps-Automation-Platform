import Logo from "../components/Logo";
import { useState } from "react";
import { FaCalendarCheck, FaArrowLeft } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { addAppointment } from "../services/api";

function PatientAppointments() {

  const navigate = useNavigate();

  // Get the currently logged-in patient's name
  const patientName =
    localStorage.getItem("userName") || "Rahul Sharma";

  const [form, setForm] = useState({
    department: "",
    doctor: "",
    date: "",
    time: "",
    type: "Consultation"
  });

  const [booked, setBooked] = useState(false);

  const doctors = {
    Cardiology: ["Dr. Arjun Mehta"],
    "General Medicine": ["Dr. Priya Nair"],
    Neurology: ["Dr. Iyer"],
    Orthopedics: ["Dr. Kapoor"],
    Pediatrics: ["Dr. Shah"]
  };


  // ================= HANDLE CHANGE =================

  const handleChange = (e) => {

    const { name, value } = e.target;

    setForm({
      ...form,
      [name]: value,
      ...(name === "department"
        ? { doctor: "" }
        : {})
    });

  };


  // ================= BOOK APPOINTMENT =================

  const handleSubmit = async (e) => {

    e.preventDefault();

    if (
      !form.department ||
      !form.doctor ||
      !form.date ||
      !form.time
    ) {

      alert(
        "Please fill all appointment details."
      );

      return;
    }


    try {

      const newAppointment = {

        patient: patientName,

        department: form.department,

        doctor: form.doctor,

        date: form.date,

        time: form.time,

        type: form.type,

        status: "Upcoming"

      };


      await addAppointment(
        newAppointment
      );


      setBooked(true);

    } catch (error) {

      console.error(
        "Appointment booking failed:",
        error
      );

      alert(
        error.message ||
        "Unable to book appointment. Please try again."
      );

    }

  };


  // ================= RETURN =================

  return (

    <div className="patient-page">


      {/* ================= HEADER ================= */}

      <header className="patient-header">

        <div className="patient-brand">
          <Logo size={38} />
          <div>
            <h2>MediPulse</h2>
            <p>Patient Portal</p>
          </div>
        </div>


        <div className="patient-header-right">

          <span>
            {patientName}
          </span>


          <button
            className="logout-button"
            onClick={() =>
              navigate("/login")
            }
          >
            Logout
          </button>

        </div>

      </header>


      {/* ================= CONTENT ================= */}

      <main className="patient-content">


        <button
          className="patient-back-btn"
          onClick={() =>
            navigate("/patient-dashboard")
          }
        >

          <FaArrowLeft />

          Back to Dashboard

        </button>


        <div className="patient-welcome">

          <h1>
            Book an Appointment
          </h1>

          <p>
            Schedule a consultation with one of our doctors.
          </p>

        </div>


        {/* ================= BOOKING CARD ================= */}

        <div className="patient-booking-card">


          {booked ? (

            <div className="booking-success">


              <div className="success-icon">

                <FaCalendarCheck />

              </div>


              <h2>
                Appointment Booked Successfully!
              </h2>


              <p>

                Your appointment with{" "}

                <strong>
                  {form.doctor}
                </strong>{" "}

                has been scheduled.

              </p>


              <div className="booking-summary">


                <div>

                  <span>
                    Patient
                  </span>

                  <strong>
                    {patientName}
                  </strong>

                </div>


                <div>

                  <span>
                    Department
                  </span>

                  <strong>
                    {form.department}
                  </strong>

                </div>


                <div>

                  <span>
                    Date
                  </span>

                  <strong>
                    {form.date}
                  </strong>

                </div>


                <div>

                  <span>
                    Time
                  </span>

                  <strong>
                    {form.time}
                  </strong>

                </div>


                <div>

                  <span>
                    Type
                  </span>

                  <strong>
                    {form.type}
                  </strong>

                </div>


              </div>


              <button
                className="book-another-btn"
                onClick={() =>
                  setBooked(false)
                }
              >
                Book Another Appointment
              </button>


              <button
                className="dashboard-return-btn"
                onClick={() =>
                  navigate(
                    "/patient-dashboard"
                  )
                }
              >
                Return to Dashboard
              </button>


            </div>

          ) : (


            <form
              onSubmit={handleSubmit}
            >


              <div className="booking-card-header">


                <div className="booking-icon">

                  <FaCalendarCheck />

                </div>


                <div>

                  <h2>
                    Appointment Details
                  </h2>

                  <p>
                    Choose your preferred doctor and consultation time.
                  </p>

                </div>


              </div>


              <div className="booking-form-grid">


                {/* DEPARTMENT */}

                <div className="booking-field">

                  <label>
                    Department
                  </label>


                  <select
                    name="department"
                    value={form.department}
                    onChange={handleChange}
                  >

                    <option value="">
                      Select Department
                    </option>


                    {Object.keys(doctors).map(
                      (department) => (

                        <option
                          key={department}
                          value={department}
                        >
                          {department}
                        </option>

                      )
                    )}

                  </select>

                </div>


                {/* DOCTOR */}

                <div className="booking-field">

                  <label>
                    Doctor
                  </label>


                  <select
                    name="doctor"
                    value={form.doctor}
                    onChange={handleChange}
                    disabled={
                      !form.department
                    }
                  >

                    <option value="">
                      Select Doctor
                    </option>


                    {form.department &&
                      doctors[
                        form.department
                      ].map(
                        (doctor) => (

                          <option
                            key={doctor}
                            value={doctor}
                          >
                            {doctor}
                          </option>

                        )
                      )}

                  </select>

                </div>


                {/* DATE */}

                <div className="booking-field">

                  <label>
                    Appointment Date
                  </label>


                  <input
                    type="date"
                    name="date"
                    value={form.date}
                    onChange={handleChange}
                    min={
                      new Date()
                        .toISOString()
                        .split("T")[0]
                    }
                  />

                </div>


                {/* TIME */}

                <div className="booking-field">

                  <label>
                    Preferred Time
                  </label>


                  <select
                    name="time"
                    value={form.time}
                    onChange={handleChange}
                  >

                    <option value="">
                      Select Time
                    </option>

                    <option value="09:00 AM">
                      09:00 AM
                    </option>

                    <option value="10:00 AM">
                      10:00 AM
                    </option>

                    <option value="11:00 AM">
                      11:00 AM
                    </option>

                    <option value="02:00 PM">
                      02:00 PM
                    </option>

                    <option value="03:00 PM">
                      03:00 PM
                    </option>

                    <option value="04:00 PM">
                      04:00 PM
                    </option>

                  </select>

                </div>


                {/* TYPE */}

                <div className="booking-field">

                  <label>
                    Appointment Type
                  </label>


                  <select
                    name="type"
                    value={form.type}
                    onChange={handleChange}
                  >

                    <option value="Consultation">
                      Consultation
                    </option>

                    <option value="Follow-up">
                      Follow-up
                    </option>

                    <option value="Routine Checkup">
                      Routine Checkup
                    </option>

                  </select>

                </div>


              </div>


              <button
                type="submit"
                className="confirm-booking-btn"
              >

                <FaCalendarCheck />

                Book Appointment

              </button>


            </form>

          )}

        </div>


      </main>

    </div>

  );

}

export default PatientAppointments;