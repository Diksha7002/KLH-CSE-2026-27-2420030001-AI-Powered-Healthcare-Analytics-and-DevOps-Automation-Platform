import { useEffect, useMemo, useState } from "react";

import {
  FaFileAlt,
  FaDownload,
  FaChartLine,
  FaBed,
  FaUserInjured,
  FaCalendarCheck,
  FaHospital
} from "react-icons/fa";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import { getReportSummary } from "../services/api";


// ================= CSV HELPERS =================

const csvCell = (value) => {
  const text = value === null || value === undefined ? "" : String(value);

  return /[",\n]/.test(text)
    ? `"${text.replace(/"/g, '""')}"`
    : text;
};

const toCsv = (rows) =>
  rows.map((row) => row.map(csvCell).join(",")).join("\r\n");

const formatSize = (bytes) =>
  bytes < 1024
    ? `${bytes} B`
    : `${(bytes / 1024).toFixed(1)} KB`;

const formatDate = (iso) =>
  new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric"
  });

const downloadCsv = (filename, rows) => {
  const blob = new Blob(["\uFEFF" + toCsv(rows)], {
    type: "text/csv;charset=utf-8;"
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;

  document.body.appendChild(link);
  link.click();
  link.remove();

  URL.revokeObjectURL(url);
};


// ================= REPORT DEFINITIONS =================

function buildReports(summary) {

  const day = summary.generatedAt.split("T")[0];

  const t = summary.totals;

  const reports = [
    {
      key: "operations",
      name: "Daily Hospital Operations Report",
      type: "Operational",
      file: `medipulse-operations-${day}.csv`,
      rows: [
        ["Metric", "Value"],
        ["Total Patients", t.patients],
        ["Total Appointments", t.appointments],
        ["Appointments Today", t.todayAppointments],
        ["Total Beds", t.totalBeds],
        ["Occupied Beds", t.occupiedBeds],
        ["Bed Occupancy %", t.occupancy],
        ["Active Admissions", t.activeAdmissions],
        ["Doctors", t.doctors],
        ["Departments", t.departments]
      ]
    },
    {
      key: "patients",
      name: "Patient Flow Analysis",
      type: "Analytics",
      file: `medipulse-patients-${day}.csv`,
      rows: [
        ["Department", "Total Patients", "Active", "Male", "Female"],
        ...summary.patientsByDepartment.map((d) => [
          d.department, d.total, d.active, d.male, d.female
        ])
      ]
    },
    {
      key: "beds",
      name: "Bed Occupancy Report",
      type: "Resource",
      file: `medipulse-bed-occupancy-${day}.csv`,
      rows: [
        ["Department", "Total Beds", "Occupied", "Available", "Maintenance", "Occupancy %"],
        ...summary.bedsByDepartment.map((d) => [
          d.department, d.total, d.occupied, d.available, d.maintenance, d.percentage
        ])
      ]
    },
    {
      key: "appointments",
      name: "Appointment Performance Report",
      type: "Appointments",
      file: `medipulse-appointments-${day}.csv`,
      rows: [
        ["Department", "Total", ...summary.appointmentStatuses],
        ...summary.appointmentsByDepartment.map((d) => [
          d.department,
          d.total,
          ...summary.appointmentStatuses.map((s) => d[s] || 0)
        ])
      ]
    },
    {
      key: "admissions",
      name: "Admissions & Discharges Report",
      type: "Operational",
      file: `medipulse-admissions-${day}.csv`,
      rows: [
        ["Department", "Currently Admitted", "Discharged", "Total"],
        ...summary.admissionsByDepartment.map((d) => [
          d.department, d.admitted, d.discharged, d.total
        ])
      ]
    }
  ];

  if (summary.prediction) {
    reports.push({
      key: "predictions",
      name: "ML Prediction Summary",
      type: "Analytics",
      file: `medipulse-predictions-${day}.csv`,
      rows: [
        [
          "Department",
          "Current Occupancy %",
          "Predicted Occupancy %",
          "Predicted Visits",
          "Demand Change % vs 7-day avg",
          "Demand Level",
          "Predicted Available Beds"
        ],
        ...summary.prediction.departments.map((d) => [
          d.department,
          d.currentOccupancy,
          d.predictedOccupancy,
          d.predictedVisits,
          d.demandChangePct,
          d.demandLevel,
          d.predictedAvailableBeds
        ])
      ]
    });
  }

  return reports;
}


function Reports() {

  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);


  // ================= LOAD REPORT DATA =================

  useEffect(() => {

    const loadReports = async () => {

      try {

        setLoading(true);

        const data = await getReportSummary();

        setSummary(data);
        setError("");

      } catch (err) {

        console.error("Reports API error:", err);

        setSummary(null);
        setError(
          err.message === "Failed to fetch"
            ? "Unable to reach the MediPulse server. Make sure the backend is running on port 5000."
            : err.message
        );

      } finally {

        setLoading(false);

      }

    };

    loadReports();

  }, [reloadKey]);


  const reports = useMemo(
    () => (summary ? buildReports(summary) : []),
    [summary]
  );


  const exportAll = () => {

    const day = summary.generatedAt.split("T")[0];

    const rows = [
      ["MediPulse Hospital Report"],
      ["Generated", summary.generatedAt],
      []
    ];

    reports.forEach((report) => {
      rows.push([report.name]);
      rows.push(...report.rows);
      rows.push([]);
    });

    downloadCsv(`medipulse-full-report-${day}.csv`, rows);
  };


  const prediction = summary ? summary.prediction : null;


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">


          {/* HEADER */}

          <div className="page-header">

            <div>

              <h1>
                Reports
              </h1>

              <p>
                Hospital analytics and operational reports
              </p>

            </div>


            <button
              className="add-patient-btn"
              onClick={exportAll}
              disabled={!summary}
            >

              <FaDownload />

              Export Report

            </button>

          </div>


          {/* LOADING / ERROR */}

          {loading && !summary && (

            <div className="page-state">
              Generating reports...
            </div>

          )}

          {error && (

            <div className="page-state error">

              {error}

              <button onClick={() => setReloadKey((key) => key + 1)}>
                Retry
              </button>

            </div>

          )}


          {summary && (

            <>

              {/* REPORT SUMMARY */}

              <div className="report-summary">


                <div className="report-stat-card">

                  <div className="report-stat-icon">
                    <FaUserInjured />
                  </div>

                  <div>

                    <span>
                      Total Patients
                    </span>

                    <h2>
                      {summary.totals.patients}
                    </h2>

                  </div>

                </div>


                <div className="report-stat-card">

                  <div className="report-stat-icon">
                    <FaCalendarCheck />
                  </div>

                  <div>

                    <span>
                      Appointments
                    </span>

                    <h2>
                      {summary.totals.appointments}
                    </h2>

                  </div>

                </div>


                <div className="report-stat-card">

                  <div className="report-stat-icon">
                    <FaBed />
                  </div>

                  <div>

                    <span>
                      Bed Occupancy
                    </span>

                    <h2>
                      {summary.totals.occupancy}%
                    </h2>

                  </div>

                </div>


                <div className="report-stat-card">

                  <div className="report-stat-icon">
                    <FaHospital />
                  </div>

                  <div>

                    <span>
                      Active Admissions
                    </span>

                    <h2>
                      {summary.totals.activeAdmissions}
                    </h2>

                  </div>

                </div>


              </div>


              {/* REPORT TABLE */}

              <div className="patients-table-card">

                <div className="table-header">

                  <div>

                    <h3>
                      Recent Reports
                    </h3>

                    <p>
                      Generated from live hospital data - download as CSV
                    </p>

                  </div>

                </div>


                <div className="table-container">

                  <table>

                    <thead>

                      <tr>

                        <th>Report</th>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Size</th>
                        <th>Action</th>

                      </tr>

                    </thead>


                    <tbody>

                      {reports.map((report) => (

                        <tr key={report.key}>

                          <td>

                            <div className="report-name">

                              <div className="report-file-icon">

                                <FaFileAlt />

                              </div>

                              <strong>
                                {report.name}
                              </strong>

                            </div>

                          </td>


                          <td>

                            <span className="report-type">

                              {report.type}

                            </span>

                          </td>


                          <td>
                            {formatDate(summary.generatedAt)}
                          </td>


                          <td>
                            {formatSize(
                              new Blob([toCsv(report.rows)]).size
                            )}
                          </td>


                          <td>

                            <button
                              className="download-report-btn"
                              onClick={() =>
                                downloadCsv(report.file, report.rows)
                              }
                            >

                              <FaDownload />

                              Download

                            </button>

                          </td>

                        </tr>

                      ))}


                      {!prediction && (

                        <tr>

                          <td>

                            <div className="report-name">

                              <div className="report-file-icon">

                                <FaFileAlt />

                              </div>

                              <strong>
                                ML Prediction Summary
                              </strong>

                            </div>

                          </td>

                          <td>

                            <span className="report-type">
                              Analytics
                            </span>

                          </td>

                          <td>-</td>
                          <td>-</td>

                          <td>

                            <button
                              className="download-report-btn"
                              disabled
                              title="Start the ML prediction service to enable this report"
                            >

                              <FaDownload />

                              Unavailable

                            </button>

                          </td>

                        </tr>

                      )}

                    </tbody>

                  </table>

                </div>

              </div>


              {/* CHARTS */}

              <div className="report-charts">


                <div className="chart-card">

                  <div className="card-header">

                    <div>

                      <h3>
                        Bed Utilization by Department
                      </h3>

                      <p>
                        Occupied vs available beds
                      </p>

                    </div>

                  </div>


                  <div className="report-chart-wrap">

                    <ResponsiveContainer width="100%" height="100%">

                      <BarChart data={summary.bedsByDepartment}>

                        <CartesianGrid strokeDasharray="3 3" />

                        <XAxis dataKey="department" fontSize={11} />

                        <YAxis allowDecimals={false} />

                        <Tooltip />

                        <Legend />

                        <Bar
                          dataKey="occupied"
                          name="Occupied"
                          fill="#1e3a5f"
                          radius={[4, 4, 0, 0]}
                        />

                        <Bar
                          dataKey="available"
                          name="Available"
                          fill="#0d9488"
                          radius={[4, 4, 0, 0]}
                        />

                      </BarChart>

                    </ResponsiveContainer>

                  </div>

                </div>


                <div className="chart-card">

                  <div className="card-header">

                    <div>

                      <h3>
                        Appointments by Status
                      </h3>

                      <p>
                        Scheduling performance
                      </p>

                    </div>

                  </div>


                  <div className="report-chart-wrap">

                    <ResponsiveContainer width="100%" height="100%">

                      <BarChart data={summary.appointmentsByStatus}>

                        <CartesianGrid strokeDasharray="3 3" />

                        <XAxis dataKey="status" fontSize={11} />

                        <YAxis allowDecimals={false} />

                        <Tooltip />

                        <Bar
                          dataKey="count"
                          name="Appointments"
                          fill="#0d9488"
                          radius={[4, 4, 0, 0]}
                        />

                      </BarChart>

                    </ResponsiveContainer>

                  </div>

                </div>


              </div>


              {/* PREDICTION SUMMARY */}

              <div className="chart-card report-prediction-card">

                <div className="card-header">

                  <div>

                    <h3>
                      Prediction Summary
                    </h3>

                    <p>
                      {prediction
                        ? `ML forecast for ${prediction.forecastDate}`
                        : "Start the ML prediction service to include forecasts in your reports"}
                    </p>

                  </div>

                </div>


                {prediction && (

                  <div className="report-prediction-summary">

                    <div>
                      <span>Expected patient visits</span>
                      <strong>{prediction.summary.tomorrowDemand}</strong>
                    </div>

                    <div>
                      <span>Predicted bed occupancy</span>
                      <strong>{prediction.summary.predictedOccupancy}%</strong>
                    </div>

                    <div>
                      <span>Current bed occupancy</span>
                      <strong>{prediction.summary.currentOccupancy}%</strong>
                    </div>

                    <div>
                      <span>Risk alerts</span>
                      <strong>{prediction.summary.riskAlerts}</strong>
                    </div>

                  </div>

                )}

              </div>


              {/* REPORT TYPES */}

              <div className="chart-card report-types-card">

                <div className="card-header">

                  <div>

                    <h3>
                      Available Report Categories
                    </h3>

                    <p>
                      Generate reports based on hospital data
                    </p>

                  </div>

                </div>


                <div className="report-category-grid">


                  <div className="report-category">

                    <FaUserInjured />

                    <h4>
                      Patient Reports
                    </h4>

                    <p>
                      Patient flow, admissions and demographics
                    </p>

                  </div>


                  <div className="report-category">

                    <FaCalendarCheck />

                    <h4>
                      Appointment Reports
                    </h4>

                    <p>
                      Appointment trends and scheduling performance
                    </p>

                  </div>


                  <div className="report-category">

                    <FaBed />

                    <h4>
                      Resource Reports
                    </h4>

                    <p>
                      Bed occupancy and resource utilization
                    </p>

                  </div>


                  <div className="report-category">

                    <FaChartLine />

                    <h4>
                      Analytics Reports
                    </h4>

                    <p>
                      Predictions, trends and operational insights
                    </p>

                  </div>


                </div>

              </div>

            </>

          )}


        </div>

      </main>

    </div>

  );
}


export default Reports;
