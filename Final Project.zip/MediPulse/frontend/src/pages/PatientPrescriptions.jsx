import Logo from "../components/Logo";
import { useEffect, useState } from "react";
import {
  FaArrowLeft,
  FaPills,
  FaEye,
  FaCalendarAlt,
  FaUserMd,
  FaClock
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { getPrescriptions } from "../services/api";
import { formatDisplayDate } from "../utils/dates";

function PatientPrescriptions() {

  const navigate = useNavigate();

  const [selectedPrescription, setSelectedPrescription] = useState(null);

  const patientName = localStorage.getItem("userName") || "";
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  // ================= LOAD FROM DATABASE =================
  useEffect(() => {
    const load = async () => {
      try {
        const data = await getPrescriptions(patientName);
        setPrescriptions(data.map((item) => ({ ...item, date: formatDisplayDate(item.date) })));
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [patientName]);

  return (
    <div className="patient-page">

      {/* HEADER */}

      <header className="patient-header">

        <div className="patient-brand">
          <Logo size={38} />
          <div>
            <h2>MediPulse</h2>
            <p>Patient Portal</p>
          </div>
        </div>

        <div className="patient-header-right">

          <span>{patientName}</span>

          <button
            className="logout-button"
            onClick={() => navigate("/login")}
          >
            Logout
          </button>

        </div>

      </header>


      {/* MAIN CONTENT */}

      <main className="patient-content">

        {/* BACK BUTTON */}

        <button
          className="patient-back-btn"
          onClick={() => navigate("/patient-dashboard")}
        >
          <FaArrowLeft />
          Back to Dashboard
        </button>


        {/* PAGE TITLE */}

        <div className="patient-welcome">

          <div>

            <h1>Prescriptions</h1>

            <p>
              View your current medications and prescription details.
            </p>

          </div>

        </div>


        {/* PRESCRIPTION CARD */}

        <div className="prescriptions-card">

          <div className="prescriptions-header">

            <div className="prescriptions-title">

              <div className="prescriptions-icon">
                <FaPills />
              </div>

              <div>

                <h2>Active Prescriptions</h2>

                <p>
                  {prescriptions.filter((item) => item.status === "Active").length} active prescriptions
                </p>

              </div>

            </div>

          </div>


          {/* PRESCRIPTION LIST */}

          <div className="prescriptions-list">

            {!loading && prescriptions.length === 0 && (
            <p style={{ padding: "20px", color: "#6b7280" }}>
              No prescriptions on file yet.
            </p>
          )}
          {prescriptions.map((prescription) => (

              <div
                className="prescription-item"
                key={prescription.id}
              >

                <div className="prescription-main">

                  <div className="prescription-medicine-icon">
                    <FaPills />
                  </div>

                  <div className="prescription-info">

                    <h3>{prescription.medicine}</h3>

                    <p>
                      <FaUserMd />
                      {prescription.doctor}
                    </p>

                    <span>
                      {prescription.department}
                    </span>

                  </div>

                </div>


                <div className="prescription-dosage">

                  <span>Dosage</span>

                  <strong>
                    {prescription.dosage}
                  </strong>

                </div>


                <div className="prescription-frequency">

                  <span>Frequency</span>

                  <strong>
                    {prescription.frequency}
                  </strong>

                </div>


                <div className="prescription-duration">

                  <span>Duration</span>

                  <strong>
                    {prescription.duration}
                  </strong>

                </div>


                <div className="prescription-status">
                  {prescription.status}
                </div>


                <button
                  className="prescription-view-btn"
                  onClick={() =>
                    setSelectedPrescription(prescription)
                  }
                >
                  <FaEye />
                  View
                </button>

              </div>

            ))}

          </div>

        </div>


        {/* DETAILS MODAL */}

        {selectedPrescription && (

          <div className="prescription-modal-overlay">

            <div className="prescription-modal">

              <button
                className="prescription-modal-close"
                onClick={() => setSelectedPrescription(null)}
              >
                ×
              </button>


              <div className="prescription-modal-icon">
                <FaPills />
              </div>


              <h2>
                {selectedPrescription.medicine}
              </h2>

              <p className="prescription-modal-date">
                Prescribed on {selectedPrescription.date}
              </p>


              <div className="prescription-details-grid">

                <div>
                  <span>Doctor</span>
                  <strong>
                    {selectedPrescription.doctor}
                  </strong>
                </div>

                <div>
                  <span>Department</span>
                  <strong>
                    {selectedPrescription.department}
                  </strong>
                </div>

                <div>
                  <span>Dosage</span>
                  <strong>
                    {selectedPrescription.dosage}
                  </strong>
                </div>

                <div>
                  <span>Frequency</span>
                  <strong>
                    {selectedPrescription.frequency}
                  </strong>
                </div>

                <div>
                  <span>Duration</span>
                  <strong>
                    {selectedPrescription.duration}
                  </strong>
                </div>

                <div>
                  <span>Status</span>
                  <strong>
                    {selectedPrescription.status}
                  </strong>
                </div>

              </div>


              <div className="prescription-instructions">

                <div className="instructions-icon">
                  <FaClock />
                </div>

                <div>

                  <span>Instructions</span>

                  <p>
                    {selectedPrescription.instructions}
                  </p>

                </div>

              </div>


              <button
                className="prescription-close-btn"
                onClick={() => setSelectedPrescription(null)}
              >
                Close
              </button>

            </div>

          </div>

        )}

      </main>

    </div>
  );
}

export default PatientPrescriptions;