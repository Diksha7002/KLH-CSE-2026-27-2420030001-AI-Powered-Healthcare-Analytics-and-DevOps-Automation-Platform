import { useEffect, useState } from "react";

import {
  FaSearch,
  FaUserPlus,
  FaEye,
  FaEdit,
  FaTrash,
  FaFilter,
  FaTimes
} from "react-icons/fa";

import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";

import {
  getPatients,
  addPatient,
  deletePatient
} from "../services/api";


function Patients() {

  const [patients, setPatients] = useState([]);

  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);

  const [showAddForm, setShowAddForm] = useState(false);

  const [form, setForm] = useState({
    name: "",
    age: "",
    gender: "",
    department: "",
    doctor: "",
    status: "Active"
  });


  // ================= LOAD PATIENTS =================

  const loadPatients = async () => {

    try {

      setLoading(true);

      const data = await getPatients();

      setPatients(data);

    } catch (error) {

      console.error(
        "Failed to load patients:",
        error
      );

    } finally {

      setLoading(false);

    }

  };


  useEffect(() => {

    loadPatients();

  }, []);


  // ================= SEARCH =================

  const filteredPatients = patients.filter((patient) => {

    const searchText = search.toLowerCase();

    return (
      String(patient.id)
        .toLowerCase()
        .includes(searchText) ||

      patient.name
        ?.toLowerCase()
        .includes(searchText) ||

      patient.department
        ?.toLowerCase()
        .includes(searchText) ||

      patient.doctor
        ?.toLowerCase()
        .includes(searchText) ||

      patient.status
        ?.toLowerCase()
        .includes(searchText)
    );

  });


  // ================= FORM CHANGE =================

  const handleChange = (e) => {

    const { name, value } = e.target;

    setForm({
      ...form,
      [name]: value
    });

  };


  // ================= ADD PATIENT =================

  const handleAddPatient = async (e) => {

    e.preventDefault();

    if (
      !form.name ||
      !form.age ||
      !form.gender ||
      !form.department ||
      !form.doctor
    ) {

      alert("Please fill all patient details.");

      return;

    }


    try {

      const newPatient = await addPatient({
        ...form,
        age: Number(form.age)
      });

      setPatients([
        ...patients,
        newPatient
      ]);

      setForm({
        name: "",
        age: "",
        gender: "",
        department: "",
        doctor: "",
        status: "Active"
      });

      setShowAddForm(false);

      alert("Patient added successfully!");

    } catch (error) {

      console.error(error);

      alert(error.message || "Failed to add patient.");

    }

  };


  // ================= DELETE PATIENT =================

  const handleDelete = async (id) => {

    const confirmDelete = window.confirm(
      "Are you sure you want to delete this patient?"
    );

    if (!confirmDelete) {
      return;
    }


    try {

      await deletePatient(id);

      setPatients(
        patients.filter(
          patient => patient.id !== id
        )
      );

      alert("Patient deleted successfully!");

    } catch (error) {

      console.error(error);

      alert(error.message || "Failed to delete patient.");

    }

  };


  // ================= VIEW =================

  const handleView = (patient) => {

    alert(
      `Patient Details\n\n` +
      `Name: ${patient.name}\n` +
      `Age: ${patient.age}\n` +
      `Gender: ${patient.gender}\n` +
      `Department: ${patient.department}\n` +
      `Doctor: ${patient.doctor}\n` +
      `Status: ${patient.status}`
    );

  };


  return (

    <div className="app-container">

      <Sidebar />

      <main className="main-content">

        <Navbar />

        <div className="dashboard-content">

          {/* ================= HEADER ================= */}

          <div className="page-header">

            <div>

              <h1>
                Patients
              </h1>

              <p>
                Manage and monitor patient information
              </p>

            </div>


            <button
              className="add-patient-btn"
              onClick={() => setShowAddForm(true)}
            >

              <FaUserPlus />

              Add Patient

            </button>

          </div>


          {/* ================= ADD PATIENT FORM ================= */}

          {showAddForm && (

            <div className="patients-table-card">

              <div className="table-header">

                <div>

                  <h3>
                    Add New Patient
                  </h3>

                  <p>
                    Enter patient information
                  </p>

                </div>


                <button
                  onClick={() => setShowAddForm(false)}
                  className="filter-btn"
                >

                  <FaTimes />

                </button>

              </div>


              <form
                onSubmit={handleAddPatient}
                style={{
                  padding: "20px",
                  display: "grid",
                  gridTemplateColumns:
                    "repeat(2, 1fr)",
                  gap: "15px"
                }}
              >

                <input
                  type="text"
                  name="name"
                  placeholder="Patient Name"
                  value={form.name}
                  onChange={handleChange}
                />


                <input
                  type="number"
                  name="age"
                  placeholder="Age"
                  value={form.age}
                  onChange={handleChange}
                />


                <select
                  name="gender"
                  value={form.gender}
                  onChange={handleChange}
                >

                  <option value="">
                    Select Gender
                  </option>

                  <option value="Male">
                    Male
                  </option>

                  <option value="Female">
                    Female
                  </option>

                  <option value="Other">
                    Other
                  </option>

                </select>


                <select
                  name="department"
                  value={form.department}
                  onChange={handleChange}
                >

                  <option value="">
                    Select Department
                  </option>

                  <option value="Cardiology">
                    Cardiology
                  </option>

                  <option value="General Medicine">
                    General Medicine
                  </option>

                  <option value="Orthopedics">
                    Orthopedics
                  </option>

                  <option value="Neurology">
                    Neurology
                  </option>

                  <option value="Pediatrics">
                    Pediatrics
                  </option>
                  <option value="Emergency">
                    Emergency
                  </option>
                  <option value="ICU">
                    ICU
                  </option>

                </select>


                <input
                  type="text"
                  name="doctor"
                  placeholder="Doctor"
                  value={form.doctor}
                  onChange={handleChange}
                />


                <select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                >

                  <option value="Active">
                    Active
                  </option>

                  <option value="Admitted">
                    Admitted
                  </option>

                  <option value="Discharged">
                    Discharged
                  </option>

                </select>


                <button
                  type="submit"
                  className="add-patient-btn"
                  style={{
                    gridColumn: "1 / -1"
                  }}
                >

                  <FaUserPlus />

                  Add Patient

                </button>

              </form>

            </div>

          )}


          {/* ================= SEARCH ================= */}

          <div className="patients-toolbar">

            <div className="search-box">

              <FaSearch />

              <input
                type="text"
                placeholder="Search patients..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
              />

            </div>


            <button className="filter-btn">

              <FaFilter />

              Filter

            </button>

          </div>


          {/* ================= TABLE ================= */}

          <div className="patients-table-card">

            <div className="table-header">

              <div>

                <h3>
                  Patient Records
                </h3>

                <p>
                  {filteredPatients.length} patients found
                </p>

              </div>

            </div>


            <div className="table-container">

              <table>

                <thead>

                  <tr>

                    <th>
                      Patient ID
                    </th>

                    <th>
                      Patient
                    </th>

                    <th>
                      Age
                    </th>

                    <th>
                      Gender
                    </th>

                    <th>
                      Department
                    </th>

                    <th>
                      Doctor
                    </th>

                    <th>
                      Status
                    </th>

                    <th>
                      Actions
                    </th>

                  </tr>

                </thead>


                <tbody>

                  {loading ? (

                    <tr>

                      <td
                        colSpan="8"
                        style={{
                          textAlign: "center",
                          padding: "30px"
                        }}
                      >
                        Loading patients...

                      </td>

                    </tr>

                  ) : filteredPatients.length === 0 ? (

                    <tr>

                      <td
                        colSpan="8"
                        style={{
                          textAlign: "center",
                          padding: "30px"
                        }}
                      >

                        No patients found.

                      </td>

                    </tr>

                  ) : (

                    filteredPatients.map(
                      (patient) => (

                        <tr key={patient.id}>

                          <td>

                            <strong>
                              {typeof patient.id === "number"
                                ? `MP${String(patient.id).padStart(4, "0")}`
                                : patient.id}
                            </strong>

                          </td>


                          <td>

                            <div className="patient-name">

                              <div className="patient-avatar">

                                {patient.name
                                  ?.charAt(0)
                                  .toUpperCase()}

                              </div>

                              <span>
                                {patient.name}
                              </span>

                            </div>

                          </td>


                          <td>
                            {patient.age}
                          </td>


                          <td>
                            {patient.gender}
                          </td>


                          <td>
                            {patient.department}
                          </td>


                          <td>
                            {patient.doctor}
                          </td>


                          <td>

                            <span
                              className={`status-badge ${
                                patient.status
                                  ?.toLowerCase()
                                  .replace(" ", "-")
                              }`}
                            >

                              {patient.status}

                            </span>

                          </td>


                          <td>

                            <div className="action-buttons">

                              <button
                                title="View"
                                onClick={() =>
                                  handleView(patient)
                                }
                              >

                                <FaEye />

                              </button>


                              <button
                                title="Edit"
                                onClick={() =>
                                  alert(
                                    "Edit functionality will be connected next."
                                  )
                                }
                              >

                                <FaEdit />

                              </button>


                              <button
                                title="Delete"
                                className="delete-btn"
                                onClick={() =>
                                  handleDelete(patient.id)
                                }
                              >

                                <FaTrash />

                              </button>

                            </div>

                          </td>

                        </tr>

                      )
                    )

                  )}

                </tbody>

              </table>

            </div>

          </div>

        </div>

      </main>

    </div>

  );

}


export default Patients;