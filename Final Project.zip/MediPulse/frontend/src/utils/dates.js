// Small date helpers for the patient portal (dates arrive from the database as YYYY-MM-DD)

const parse = (iso) => new Date(`${iso}T00:00:00Z`);

// 26 Aug 2026
export const formatDisplayDate = (iso) =>
  iso
    ? parse(iso).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        timeZone: "UTC"
      })
    : "-";

// 26 Aug
export const formatShortDay = (iso) =>
  iso
    ? parse(iso).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        timeZone: "UTC"
      })
    : "-";

// 2026
export const formatYear = (iso) => (iso ? iso.slice(0, 4) : "");

// Today / Yesterday / 5 days ago
export const timeAgo = (iso) => {
  if (!iso) return "-";

  const today = new Date().toISOString().split("T")[0];
  const days = Math.round((parse(today) - parse(iso)) / 86400000);

  if (days <= 0) return "Today";
  if (days === 1) return "Yesterday";
  return `${days} days ago`;
};
