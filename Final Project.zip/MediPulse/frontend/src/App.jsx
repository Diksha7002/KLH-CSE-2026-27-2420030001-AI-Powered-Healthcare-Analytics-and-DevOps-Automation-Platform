import {
  BrowserRouter,
  Routes,
  Route,
  Navigate
} from "react-router-dom";

// Login
import Login from "./pages/Login";

// Doctor/Admin pages
import Dashboard from "./pages/Dashboard";
import Patients from "./pages/Patients";
import Appointments from "./pages/Appointments";
import Admissions from "./pages/Admissions";
import Beds from "./pages/Beds";
import Departments from "./pages/Departments";
import Predictions from "./pages/Predictions";
import AIAssistant from "./pages/AIAssistant";
import Reports from "./pages/Reports";

// Patient pages
import PatientDashboard from "./pages/PatientDashboard";
import PatientAppointments from "./pages/PatientAppointments";
import PatientRecords from "./pages/PatientRecords";
import PatientPrescriptions from "./pages/PatientPrescriptions";
import PatientLabs from "./pages/PatientLabs";
import PatientAppointmentHistory from "./pages/PatientAppointmentHistory";
import Register from "./pages/Register";

function App() {
  return (
    <BrowserRouter>

      <Routes>

        {/* ================= LOGIN ================= */}

        <Route
          path="/"
          element={<Navigate to="/login" replace />}
        />

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
  path="/register"
  element={<Register />}
/>

        {/* ================= DOCTOR / ADMIN SIDE ================= */}

        <Route
          path="/dashboard"
          element={<Dashboard />}
        />

        <Route
          path="/patients"
          element={<Patients />}
        />

        <Route
          path="/appointments"
          element={<Appointments />}
        />

        <Route
          path="/admissions"
          element={<Admissions />}
        />

        <Route
          path="/beds"
          element={<Beds />}
        />

        <Route
          path="/departments"
          element={<Departments />}
        />

        <Route
          path="/predictions"
          element={<Predictions />}
        />

        <Route
          path="/ai-assistant"
          element={<AIAssistant />}
        />

        <Route
          path="/reports"
          element={<Reports />}
        />


        {/* ================= PATIENT SIDE ================= */}

        <Route
          path="/patient-dashboard"
          element={<PatientDashboard />}
        />

        <Route
          path="/patient/appointments"
          element={<PatientAppointments />}
        />

<Route
  path="/patient/my-appointments"
  element={<PatientAppointmentHistory />}
/>

        <Route
          path="/patient/records"
          element={<PatientRecords />}
        />

        <Route
          path="/patient/prescriptions"
          element={<PatientPrescriptions />}
        />

        <Route
          path="/patient/labs"
          element={<PatientLabs />}
        />


        {/* ================= UNKNOWN URL ================= */}

        <Route
          path="*"
          element={<Navigate to="/login" replace />}
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;