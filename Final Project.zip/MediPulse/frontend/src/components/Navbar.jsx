import { FaBell, FaUserMd, FaSignOutAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";


function Navbar() {

  const navigate = useNavigate();

  const doctorName =
    localStorage.getItem("doctorName") || "Dr. Arjun Mehta";

  const specialization =
    localStorage.getItem("doctorSpecialization") || "Cardiologist";


  const handleLogout = () => {

    localStorage.removeItem("userRole");
    localStorage.removeItem("doctorName");
    localStorage.removeItem("doctorSpecialization");

    navigate("/");

  };


  return (

    <header className="navbar">

      <div className="navbar-title">

        <h2>
          Hospital Dashboard
        </h2>

        <p>
          Monitor hospital operations and performance
        </p>

      </div>


      <div className="navbar-right">


        {/* NOTIFICATIONS */}

        <button className="notification-btn">

          <FaBell />

          <span className="notification-dot"></span>

        </button>


        {/* DOCTOR PROFILE */}

        <div className="doctor-profile">

          <div className="doctor-avatar">

            <FaUserMd />

          </div>


          <div className="doctor-info">

            <strong>
              {doctorName}
            </strong>

            <span>
              {specialization}
            </span>

          </div>


          <button
            className="logout-btn"
            onClick={handleLogout}
            title="Logout"
          >

            <FaSignOutAlt />

          </button>

        </div>


      </div>

    </header>

  );
}


export default Navbar;