import Logo from "./Logo";
import {
  FaChartPie,
  FaUserInjured,
  FaCalendarCheck,
  FaBed,
  FaHospitalUser,
  FaBuilding,
  FaBrain,
  FaFileAlt,
  FaRobot
} from "react-icons/fa";

import { Link, useLocation } from "react-router-dom";


function Sidebar() {

  const location = useLocation();


  return (

    <aside className="sidebar">

      {/* LOGO */}

      <div className="sidebar-logo">

        <Logo size={38} />

        <div>

          <h2>MediPulse</h2>

          <span>Analytics</span>

        </div>

      </div>


      <div className="menu-title">
        MAIN MENU
      </div>


      <nav>

        {/* DASHBOARD */}

        <Link
          to="/dashboard"
          className={
            location.pathname === "/dashboard"
              ? "active"
              : ""
          }
        >

          <FaChartPie />

          <span>
            Dashboard
          </span>

        </Link>


        {/* PATIENTS */}

        <Link
          to="/patients"
          className={
            location.pathname === "/patients"
              ? "active"
              : ""
          }
        >

          <FaUserInjured />

          <span>
            Patients
          </span>

        </Link>


        {/* APPOINTMENTS */}

        <Link
          to="/appointments"
          className={
            location.pathname === "/appointments"
              ? "active"
              : ""
          }
        >

          <FaCalendarCheck />

          <span>
            Appointments
          </span>

        </Link>


        {/* ADMISSIONS */}

        <Link
          to="/admissions"
          className={
            location.pathname === "/admissions"
              ? "active"
              : ""
          }
        >

          <FaHospitalUser />

          <span>
            Admissions
          </span>

        </Link>


        {/* BEDS */}

        <Link
          to="/beds"
          className={
            location.pathname === "/beds"
              ? "active"
              : ""
          }
        >

          <FaBed />

          <span>
            Beds
          </span>

        </Link>


        {/* DEPARTMENTS */}

        <Link
          to="/departments"
          className={
            location.pathname === "/departments"
              ? "active"
              : ""
          }
        >

          <FaBuilding />

          <span>
            Departments
          </span>

        </Link>


        {/* ANALYTICS */}

        <div className="menu-title">
          ANALYTICS
        </div>


        {/* PREDICTIONS */}

        <Link
          to="/predictions"
          className={
            location.pathname === "/predictions"
              ? "active"
              : ""
          }
        >

          <FaBrain />

          <span>
            Predictions
          </span>

        </Link>


        {/* AI ASSISTANT */}

        <Link
          to="/ai-assistant"
          className={
            location.pathname === "/ai-assistant"
              ? "active"
              : ""
          }
        >

          <FaRobot />

          <span>
            AI Assistant
          </span>

        </Link>


        {/* REPORTS */}

        <Link
          to="/reports"
          className={
            location.pathname === "/reports"
              ? "active"
              : ""
          }
        >

          <FaFileAlt />

          <span>
            Reports
          </span>

        </Link>

      </nav>

    </aside>

  );
}


export default Sidebar;