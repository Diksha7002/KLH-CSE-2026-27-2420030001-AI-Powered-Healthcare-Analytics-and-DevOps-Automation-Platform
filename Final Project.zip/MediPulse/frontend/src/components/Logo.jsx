// MediPulse logo mark: medical cross with a pulse line (teal + navy).
// Plain inline SVG - no extra dependencies.

function Logo({ size = 36 }) {

  return (

    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      role="img"
      aria-label="MediPulse logo"
    >

      <defs>
        <linearGradient
          id="mp-logo-grad"
          x1="8"
          y1="4"
          x2="56"
          y2="60"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#14B8A6" />
          <stop offset="1" stopColor="#0F766E" />
        </linearGradient>
      </defs>

      <rect width="64" height="64" rx="16" fill="url(#mp-logo-grad)" />

      <path
        d="M26 12h12a3 3 0 0 1 3 3v8h8a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3h-8v8a3 3 0 0 1-3 3H26a3 3 0 0 1-3-3v-8h-8a3 3 0 0 1-3-3V26a3 3 0 0 1 3-3h8v-8a3 3 0 0 1 3-3z"
        fill="#fff"
      />

      <path
        d="M6 33h13l5-10 7 22 6-16 3 4h18"
        stroke="#0B2545"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

    </svg>

  );
}


export default Logo;
