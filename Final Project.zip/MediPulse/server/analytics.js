// ======================================================================
// MediPulse - Analytics module
// ----------------------------------------------------------------------
// Adds three feature areas on top of the existing API without touching it:
//   GET  /api/predictions      -> ML forecasts (via the Python ML service)
//   GET  /api/reports/summary  -> aggregated analytics for the Reports page
//   POST /api/assistant        -> AI Assistant (Claude if an API key is
//                                 configured, otherwise a built-in
//                                 data-driven engine - both use LIVE data)
// ======================================================================

const ML_API_URL = process.env.ML_API_URL || "http://localhost:8000";

// Departments the ML model is trained on (same ones used by the Beds module)
const ML_DEPARTMENTS = [
  "ICU",
  "General Medicine",
  "Emergency",
  "Pediatrics",
  "Cardiology",
  "Neurology",
  "Orthopedics"
];

// Supplies the hospital's recent history (from the database) to the ML service
let mlHistoryProvider = null;

const addDaysISO = (iso, days) => {
  const date = new Date(`${iso}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().split("T")[0];
};

const todayISO = () => new Date().toISOString().split("T")[0];

const pct = (part, total) =>
  total === 0 ? 0 : Math.round((part / total) * 100);

const countBy = (items, keyFn) => {
  const result = {};
  items.forEach((item) => {
    const key = keyFn(item) || "Unknown";
    result[key] = (result[key] || 0) + 1;
  });
  return result;
};


// ======================================================================
// DATA HELPERS (all read from the live db.json)
// ======================================================================

function bedsByDepartment(db) {
  const names = [
    ...new Set([...ML_DEPARTMENTS, ...db.beds.map((b) => b.department)])
  ];

  return names
    .map((department) => {
      const beds = db.beds.filter((b) => b.department === department);
      const occupied = beds.filter((b) => b.status === "Occupied").length;
      const maintenance = beds.filter((b) => b.status === "Maintenance").length;
      const available = beds.filter((b) => b.status === "Available").length;

      return {
        department,
        total: beds.length,
        occupied,
        available,
        maintenance,
        percentage: pct(occupied, beds.length)
      };
    })
    .filter((d) => d.total > 0);
}

function departmentNames(db) {
  return [
    ...new Set([
      ...db.departments.map((d) => d.name),
      ...db.patients.map((p) => p.department),
      ...db.appointments.map((a) => a.department),
      ...db.admissions.map((a) => a.department),
      ...db.beds.map((b) => b.department)
    ].filter(Boolean))
  ];
}


// ======================================================================
// ML SERVICE
// ======================================================================

async function callMlService(path, options = {}) {
  const response = await fetch(`${ML_API_URL}${path}`, {
    signal: AbortSignal.timeout(8000),
    ...options
  });

  if (!response.ok) {
    throw new Error(`ML service responded with ${response.status}`);
  }

  return response.json();
}

const demandLevel = (change) => {
  if (change >= 10) return "High demand";
  if (change >= 3) return "Moderate demand";
  if (change > -3) return "Stable demand";
  return "Lower demand";
};

const shortDate = (isoDate) =>
  new Date(`${isoDate}T00:00:00Z`).toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    timeZone: "UTC"
  });

function buildAlerts(departments) {
  const alerts = [];

  departments.forEach((d) => {
    if (d.predictedOccupancy >= 85) {
      alerts.push({
        severity: "critical",
        title: `${d.department} Occupancy`,
        message: `Occupancy is predicted to reach ${d.predictedOccupancy}% within 24 hours.`
      });
    } else if (d.predictedOccupancy >= 70) {
      alerts.push({
        severity: "warning",
        title: `${d.department} Occupancy`,
        message: `Occupancy is expected to rise to ${d.predictedOccupancy}% (currently ${d.currentOccupancy}%).`
      });
    }

    if (d.predictedAvailableBeds <= 1 && d.predictedOccupancy < 85) {
      alerts.push({
        severity: "warning",
        title: `${d.department} Bed Availability`,
        message: `Only ${d.predictedAvailableBeds} bed(s) are expected to be available tomorrow.`
      });
    }

    if (d.demandChangePct >= 15) {
      alerts.push({
        severity: "warning",
        title: `${d.department} Demand`,
        message: `Patient demand is expected to be ${d.demandChangePct}% above the recent 7-day average.`
      });
    }
  });

  const order = { critical: 0, warning: 1 };
  return alerts
    .sort((a, b) => order[a.severity] - order[b.severity])
    .slice(0, 6)
    .map((alert, index) => ({ id: index + 1, ...alert }));
}

async function fetchPredictions(db) {
  const beds = bedsByDepartment(db);

  const liveOccupancy = {};
  ML_DEPARTMENTS.forEach((name) => {
    const bed = beds.find((b) => b.department === name);
    if (bed) liveOccupancy[name] = bed.percentage;
  });

  const ml = await callMlService("/predict", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      live_occupancy: liveOccupancy,
      horizon: 4,
      history: mlHistoryProvider ? mlHistoryProvider() : undefined
    })
  });

  // History ends yesterday, so the forecast starts today; "tomorrow" is the next entry
  const tomorrow = addDaysISO(todayISO(), 1);

  const tomorrowIndex = (list) => {
    const index = list.findIndex((f) => f.date === tomorrow);
    return index >= 0 ? index : 0;
  };

  const departments = ml.departments.map((item) => {
    const bed = beds.find((b) => b.department === item.department) || {
      total: 0,
      occupied: 0,
      available: 0,
      maintenance: 0,
      percentage: 0
    };

    const next = item.forecast[tomorrowIndex(item.forecast)];
    const predictedOccupiedBeds = Math.round((next.occupancy / 100) * bed.total);
    const predictedAvailableBeds = Math.max(
      0,
      bed.total - bed.maintenance - predictedOccupiedBeds
    );
    // Daily counts per department are small, so a change of less than ~1.5 visits is noise
    const visitDiff = next.visits - item.recent_visits_avg;
    const demandChangePct =
      item.recent_visits_avg && Math.abs(visitDiff) >= 1.5
        ? Math.round((visitDiff / item.recent_visits_avg) * 100)
        : 0;

    return {
      department: item.department,
      totalBeds: bed.total,
      occupiedBeds: bed.occupied,
      availableBeds: bed.available,
      currentOccupancy: bed.percentage,
      predictedOccupancy: Math.round(next.occupancy),
      predictedOccupiedBeds,
      predictedAvailableBeds,
      predictedVisits: next.visits,
      recentAvgVisits: Math.round(item.recent_visits_avg),
      demandChangePct,
      demandLevel: demandLevel(demandChangePct),
      trend: item.trend,
      forecast: item.forecast
    };
  });

  const totalBeds = departments.reduce((s, d) => s + d.totalBeds, 0);
  const currentOccupied = departments.reduce((s, d) => s + d.occupiedBeds, 0);
  const predictedOccupied = departments.reduce(
    (s, d) => s + (d.predictedOccupancy / 100) * d.totalBeds,
    0
  );

  const currentOccupancy = pct(currentOccupied, totalBeds);
  const predictedOccupancy = pct(predictedOccupied, totalBeds);

  const tomorrowDemand = ml.totals.forecast[tomorrowIndex(ml.totals.forecast)].visits;
  const demandChangePct = ml.totals.recent_visits_avg
    ? Math.round(((tomorrowDemand - ml.totals.recent_visits_avg) / ml.totals.recent_visits_avg) * 100)
    : 0;

  const alerts = buildAlerts(departments);

  const chart = [
    ...ml.totals.history.map((h) => ({
      date: h.date,
      label: shortDate(h.date),
      actual: h.visits,
      predicted: h.model_estimate ?? null
    })),
    ...ml.totals.forecast.map((f) => ({
      date: f.date,
      label: shortDate(f.date),
      actual: null,
      predicted: f.visits
    }))
  ];

  const forecastDate = ml.totals.forecast[tomorrowIndex(ml.totals.forecast)].date;
  const staleDays = Math.round(
    (new Date(`${todayISO()}T00:00:00Z`) - new Date(`${ml.data_through}T00:00:00Z`)) / 86400000
  );

  return {
    generatedAt: ml.generated_at,
    dataThrough: ml.data_through,
    forecastDate,
    dataStaleDays: Math.max(0, staleDays),
    summary: {
      tomorrowDemand,
      demandChangePct,
      currentOccupancy,
      predictedOccupancy,
      occupancyChange: predictedOccupancy - currentOccupancy,
      riskAlerts: alerts.length
    },
    chart,
    departments,
    alerts,
    model: ml.model
  };
}

function mlUnavailableMessage() {
  return "The prediction service is not running. Start it with: cd ml && python predict_api.py";
}


// ======================================================================
// REPORT SUMMARY
// ======================================================================

function buildReportSummary(db) {
  const departments = departmentNames(db);
  const beds = bedsByDepartment(db);

  const totalBeds = db.beds.length;
  const occupiedBeds = db.beds.filter((b) => b.status === "Occupied").length;

  const patientsByDepartment = departments
    .map((department) => {
      const list = db.patients.filter((p) => p.department === department);
      return {
        department,
        total: list.length,
        active: list.filter((p) => p.status === "Active").length,
        male: list.filter((p) => p.gender === "Male").length,
        female: list.filter((p) => p.gender === "Female").length
      };
    })
    .filter((d) => d.total > 0);

  const statuses = [...new Set(db.appointments.map((a) => a.status || "Unknown"))];

  const appointmentsByDepartment = departments
    .map((department) => {
      const list = db.appointments.filter((a) => a.department === department);
      const row = { department, total: list.length };
      statuses.forEach((status) => {
        row[status] = list.filter((a) => (a.status || "Unknown") === status).length;
      });
      return row;
    })
    .filter((d) => d.total > 0);

  const appointmentsByStatus = statuses.map((status) => ({
    status,
    count: db.appointments.filter((a) => (a.status || "Unknown") === status).length
  }));

  const admissionsByDepartment = departments
    .map((department) => {
      const list = db.admissions.filter((a) => a.department === department);
      return {
        department,
        admitted: list.filter((a) => a.status === "Admitted").length,
        discharged: list.filter((a) => a.status === "Discharged").length,
        total: list.length
      };
    })
    .filter((d) => d.total > 0);

  return {
    generatedAt: new Date().toISOString(),
    totals: {
      patients: db.patients.length,
      appointments: db.appointments.length,
      todayAppointments: db.appointments.filter((a) => a.date === todayISO()).length,
      occupiedBeds,
      totalBeds,
      occupancy: pct(occupiedBeds, totalBeds),
      activeAdmissions: db.admissions.filter((a) => a.status === "Admitted").length,
      doctors: db.doctors.length,
      departments: db.departments.length
    },
    patientsByDepartment,
    appointmentsByStatus,
    appointmentsByDepartment,
    appointmentStatuses: statuses,
    bedsByDepartment: beds,
    admissionsByDepartment
  };
}


// ======================================================================
// AI ASSISTANT
// ======================================================================

async function buildSnapshot(db) {
  const report = buildReportSummary(db);

  let predictions = null;
  try {
    predictions = await fetchPredictions(db);
  } catch (err) {
    predictions = null;
  }

  const beds = report.bedsByDepartment;

  return {
    today: todayISO(),
    hospital: {
      totalPatients: report.totals.patients,
      totalBeds: report.totals.totalBeds,
      occupiedBeds: report.totals.occupiedBeds,
      availableBeds: db.beds.filter((b) => b.status === "Available").length,
      maintenanceBeds: db.beds.filter((b) => b.status === "Maintenance").length,
      occupancyPercent: report.totals.occupancy,
      doctors: report.totals.doctors,
      departments: db.departments.map((d) => d.name)
    },
    beds,
    patientsByDepartment: report.patientsByDepartment.map((d) => ({
      department: d.department,
      patients: d.total
    })),
    appointments: {
      total: report.totals.appointments,
      today: report.totals.todayAppointments,
      byStatus: Object.fromEntries(
        report.appointmentsByStatus.map((s) => [s.status, s.count])
      ),
      byDepartment: Object.fromEntries(
        report.appointmentsByDepartment.map((d) => [d.department, d.total])
      )
    },
    admissions: {
      active: report.totals.activeAdmissions,
      discharged: db.admissions.filter((a) => a.status === "Discharged").length,
      activeByDepartment: Object.fromEntries(
        report.admissionsByDepartment
          .filter((d) => d.admitted > 0)
          .map((d) => [d.department, d.admitted])
      )
    },
    labs: {
      total: db.labs.length,
      pending: db.labs.filter((l) => l.status !== "Completed").length
    },
    predictions: predictions
      ? {
          forecastDate: predictions.forecastDate,
          tomorrowPatientDemand: predictions.summary.tomorrowDemand,
          demandChangePercentVs7DayAverage: predictions.summary.demandChangePct,
          predictedOverallOccupancyPercent: predictions.summary.predictedOccupancy,
          departments: predictions.departments.map((d) => ({
            department: d.department,
            currentOccupancyPercent: d.currentOccupancy,
            predictedOccupancyPercent: d.predictedOccupancy,
            predictedVisits: d.predictedVisits,
            demandChangePercent: d.demandChangePct,
            demandLevel: d.demandLevel,
            visitsLast7DaysAvg: d.trend.visits_7d,
            visitsPrevious7DaysAvg: d.trend.visits_prev_7d,
            emergencyCasesLast7DaysAvg: d.trend.emergency_7d,
            emergencyCasesPrevious7DaysAvg: d.trend.emergency_prev_7d
          })),
          alerts: predictions.alerts.map((a) => `${a.title}: ${a.message}`),
          model: `${predictions.model.type}, occupancy R2 ${predictions.model.occupancy_r2}, visits R2 ${predictions.model.visits_r2}`
        }
      : null
  };
}

const has = (text, ...words) => words.some((w) => text.includes(w));

function describeBeds(b) {
  return `${b.department}: ${b.occupied}/${b.total} beds occupied (${b.percentage}%), ${b.available} available${b.maintenance ? `, ${b.maintenance} under maintenance` : ""}`;
}

function describeChange(now, before) {
  if (!before) return "no comparison data";
  const change = Math.round(((now - before) / before) * 100);
  if (change > 0) return `up ${change}% from the previous week`;
  if (change < 0) return `down ${Math.abs(change)}% from the previous week`;
  return "unchanged from the previous week";
}

function departmentAnswer(dept, snap) {
  const bed = snap.beds.find((b) => b.department === dept);
  const lines = [`${dept} overview:`];

  if (bed) lines.push(`• Beds - ${describeBeds(bed)}.`);

  const patients = snap.patientsByDepartment.find((d) => d.department === dept);
  if (patients) lines.push(`• Registered patients: ${patients.patients}.`);

  const appts = snap.appointments.byDepartment[dept];
  if (appts) lines.push(`• Appointments on record: ${appts}.`);

  const admitted = snap.admissions.activeByDepartment[dept];
  if (admitted) lines.push(`• Currently admitted patients: ${admitted}.`);

  const p = snap.predictions && snap.predictions.departments.find((d) => d.department === dept);
  if (p) {
    lines.push(
      `• Forecast for ${snap.predictions.forecastDate}: about ${p.predictedVisits} visits (${p.demandLevel.toLowerCase()}, ${p.demandChangePercent >= 0 ? "+" : ""}${p.demandChangePercent}% vs the 7-day average) and ${p.predictedOccupancyPercent}% bed occupancy.`
    );
    lines.push(
      `• Visit trend: ${p.visitsLast7DaysAvg}/day this week, ${describeChange(p.visitsLast7DaysAvg, p.visitsPrevious7DaysAvg)}. Emergency cases: ${p.emergencyCasesLast7DaysAvg}/day, ${describeChange(p.emergencyCasesLast7DaysAvg, p.emergencyCasesPrevious7DaysAvg)}.`
    );
  }

  return lines.join("\n");
}

function overviewAnswer(snap) {
  const h = snap.hospital;
  const lines = [
    `Today's operational insights (${snap.today}):`,
    `• Bed occupancy is ${h.occupancyPercent}% (${h.occupiedBeds}/${h.totalBeds} beds), with ${h.availableBeds} beds available.`,
    `• ${snap.appointments.today} appointment(s) scheduled today and ${snap.admissions.active} patient(s) currently admitted.`,
    `• ${h.totalPatients} patients registered across ${h.departments.length} departments.`
  ];

  if (snap.predictions) {
    const p = snap.predictions;
    lines.push(
      `• Forecast for ${p.forecastDate}: ~${p.tomorrowPatientDemand} patient visits (${p.demandChangePercentVs7DayAverage >= 0 ? "+" : ""}${p.demandChangePercentVs7DayAverage}% vs 7-day average).`
    );
    lines.push(
      p.alerts.length
        ? `• ${p.alerts.length} prediction alert(s): ${p.alerts.slice(0, 2).join(" ")}`
        : "• No prediction alerts - all departments are within normal ranges."
    );
  } else {
    lines.push("• The prediction service is offline, so forecasts are unavailable right now.");
  }

  return lines.join("\n");
}

function ruleBasedAnswer(question, snap) {
  const q = question.toLowerCase();

  const mentioned = ML_DEPARTMENTS.concat(snap.hospital.departments)
    .filter((name, i, arr) => arr.indexOf(name) === i)
    .find((name) => q.includes(name.toLowerCase()));

  if (/^(hi|hello|hey|good (morning|afternoon|evening))\b/.test(q)) {
    return "Hello Doctor! Ask me about bed occupancy, patient load, appointments, admissions or tomorrow's predictions.";
  }

  if (has(q, "help", "what can you")) {
    return "I can answer questions using your live hospital data and the ML forecasts:\n• Bed occupancy and availability (overall or by department)\n• Patient load, appointments and admissions\n• Tomorrow's predicted patient demand and bed occupancy\n• Risk alerts and operational insights";
  }

  const superlative = has(q, "highest", "most", "busiest", "maximum", "top", "lowest", "least");
  const lowest = has(q, "lowest", "least");

  if (superlative && has(q, "occupan", "bed")) {
    const sorted = [...snap.beds].sort((a, b) => b.percentage - a.percentage);
    const pick = lowest ? sorted[sorted.length - 1] : sorted[0];
    return `${pick.department} has the ${lowest ? "lowest" : "highest"} bed occupancy at ${pick.percentage}% (${pick.occupied}/${pick.total} beds).\n\n${sorted.map((b) => `• ${describeBeds(b)}`).join("\n")}`;
  }

  if (superlative && has(q, "load", "patient", "department", "busy")) {
    if (snap.predictions) {
      const sorted = [...snap.predictions.departments].sort(
        (a, b) => b.visitsLast7DaysAvg - a.visitsLast7DaysAvg
      );
      const pick = lowest ? sorted[sorted.length - 1] : sorted[0];
      return `${pick.department} has the ${lowest ? "lowest" : "highest"} patient load, averaging ${pick.visitsLast7DaysAvg} visits/day over the last 7 days.\n\n${sorted.map((d) => `• ${d.department}: ${d.visitsLast7DaysAvg} visits/day`).join("\n")}`;
    }
    const sorted = [...snap.patientsByDepartment].sort((a, b) => b.patients - a.patients);
    const pick = lowest ? sorted[sorted.length - 1] : sorted[0];
    return `${pick.department} has the ${lowest ? "lowest" : "highest"} number of registered patients (${pick.patients}).`;
  }

  if (has(q, "alert", "risk", "warning", "critical")) {
    if (!snap.predictions) return "The prediction service is offline, so risk alerts are unavailable right now.";
    return snap.predictions.alerts.length
      ? `Current prediction alerts:\n${snap.predictions.alerts.map((a) => `• ${a}`).join("\n")}`
      : "There are no prediction alerts right now - all departments are within normal ranges.";
  }

  if (has(q, "predict", "forecast", "tomorrow", "expected", "next day", "demand")) {
    if (!snap.predictions) return "The prediction service is offline, so forecasts are unavailable right now.";
    const p = snap.predictions;
    return `Forecast for ${p.forecastDate}:\n• Patient demand: ~${p.tomorrowPatientDemand} visits (${p.demandChangePercentVs7DayAverage >= 0 ? "+" : ""}${p.demandChangePercentVs7DayAverage}% vs the 7-day average)\n• Overall bed occupancy: ~${p.predictedOverallOccupancyPercent}% (now ${snap.hospital.occupancyPercent}%)\n\nBy department:\n${p.departments.map((d) => `• ${d.department}: ${d.predictedVisits} visits (${d.demandLevel.toLowerCase()}), ${d.predictedOccupancyPercent}% occupancy`).join("\n")}\n\nModel: ${p.model}.`;
  }

  if (mentioned && !has(q, "doctor")) {
    return departmentAnswer(mentioned, snap);
  }

  if (has(q, "emergency", "visits", "increasing", "trend")) {
    if (snap.predictions) {
      const e = snap.predictions.departments.find((d) => d.department === "Emergency");
      if (e) return departmentAnswer("Emergency", snap);
    }
    return "Emergency trend data needs the prediction service, which is offline right now.";
  }

  if (has(q, "available", "free", "vacant", "empty")) {
    return `Bed availability: ${snap.hospital.availableBeds} of ${snap.hospital.totalBeds} beds are available.\n\n${snap.beds.map((b) => `• ${b.department}: ${b.available} available`).join("\n")}`;
  }

  if (has(q, "bed", "occupan", "capacity")) {
    return `Overall bed occupancy is ${snap.hospital.occupancyPercent}% (${snap.hospital.occupiedBeds}/${snap.hospital.totalBeds} beds).\n\n${snap.beds.map((b) => `• ${describeBeds(b)}`).join("\n")}`;
  }

  if (has(q, "appointment", "schedule", "booking")) {
    const statuses = Object.entries(snap.appointments.byStatus)
      .map(([status, count]) => `${status}: ${count}`)
      .join(", ");
    return `There are ${snap.appointments.today} appointment(s) scheduled today and ${snap.appointments.total} in total.\nBy status - ${statuses || "none"}.`;
  }

  if (has(q, "admission", "admitted", "discharge", "inpatient")) {
    const byDept = Object.entries(snap.admissions.activeByDepartment)
      .map(([d, n]) => `• ${d}: ${n}`)
      .join("\n");
    return `${snap.admissions.active} patient(s) are currently admitted and ${snap.admissions.discharged} have been discharged.${byDept ? `\n\nCurrently admitted by department:\n${byDept}` : ""}`;
  }

  if (has(q, "doctor", "staff")) {
    return `There are ${snap.hospital.doctors} doctors across ${snap.hospital.departments.length} departments (${snap.hospital.departments.join(", ")}).`;
  }

  if (has(q, "lab", "test")) {
    return `There are ${snap.labs.total} lab records, ${snap.labs.pending} still pending.`;
  }

  if (has(q, "patient")) {
    return `${snap.hospital.totalPatients} patients are registered.\n\n${snap.patientsByDepartment.map((d) => `• ${d.department}: ${d.patients}`).join("\n")}`;
  }

  if (has(q, "insight", "today", "summary", "overview", "status", "report")) {
    return overviewAnswer(snap);
  }

  return `${overviewAnswer(snap)}\n\nYou can also ask about a specific department, bed availability, appointments or tomorrow's forecast.`;
}

async function claudeAnswer(question, history, snap) {
  const system =
    "You are MediPulse AI, a hospital operations analytics assistant for doctors and administrators. " +
    "Answer ONLY from the hospital data JSON provided below. Be concise (under 120 words), use short bullet points where helpful, " +
    "and quote exact numbers. If the data does not contain the answer, say so. " +
    "Do not diagnose patients or give individual medical advice.\n\n" +
    `HOSPITAL DATA (live):\n${JSON.stringify(snap)}`;

  const messages = [
    ...history,
    { role: "user", content: question }
  ];

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    signal: AbortSignal.timeout(20000),
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 600,
      system,
      messages
    })
  });

  if (!response.ok) {
    throw new Error(`Claude API responded with ${response.status}`);
  }

  const data = await response.json();
  const text = (data.content || [])
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n")
    .trim();

  if (!text) throw new Error("Empty response from Claude API");
  return text;
}

function cleanHistory(history) {
  if (!Array.isArray(history)) return [];

  const cleaned = history
    .filter(
      (m) =>
        m &&
        (m.role === "user" || m.role === "assistant") &&
        typeof m.content === "string" &&
        m.content.trim()
    )
    .slice(-6)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 1500) }));

  // The Messages API requires the first message to be from the user
  while (cleaned.length && cleaned[0].role !== "user") cleaned.shift();
  return cleaned;
}


// ======================================================================
// ROUTES
// ======================================================================

module.exports = function registerAnalyticsRoutes(app, readDatabase, getMlHistory) {
  mlHistoryProvider = getMlHistory || null;

  app.get("/api/predictions", async (req, res) => {
    try {
      const db = readDatabase();
      res.json(await fetchPredictions(db));
    } catch (err) {
      console.error("Predictions error:", err.message);
      res.status(503).json({ message: mlUnavailableMessage() });
    }
  });

  app.get("/api/reports/summary", async (req, res) => {
    try {
      const db = readDatabase();
      const summary = buildReportSummary(db);

      try {
        summary.prediction = await fetchPredictions(db);
      } catch (err) {
        summary.prediction = null;
      }

      res.json(summary);
    } catch (err) {
      console.error("Report error:", err.message);
      res.status(500).json({ message: "Unable to generate report data" });
    }
  });

  app.post("/api/assistant", async (req, res) => {
    const question =
      typeof req.body.message === "string" ? req.body.message.trim() : "";

    if (!question) {
      return res.status(400).json({ message: "Please type a question" });
    }

    if (question.length > 1000) {
      return res.status(400).json({ message: "Question is too long" });
    }

    try {
      const db = readDatabase();
      const snapshot = await buildSnapshot(db);

      if (process.env.ANTHROPIC_API_KEY) {
        try {
          const reply = await claudeAnswer(
            question,
            cleanHistory(req.body.history),
            snapshot
          );
          return res.json({ reply, source: "ai" });
        } catch (err) {
          console.error("Claude API error, using built-in engine:", err.message);
        }
      }

      res.json({
        reply: ruleBasedAnswer(question, snapshot),
        source: "data-engine"
      });
    } catch (err) {
      console.error("Assistant error:", err.message);
      res.status(500).json({ message: "The assistant could not process that question" });
    }
  });
};
