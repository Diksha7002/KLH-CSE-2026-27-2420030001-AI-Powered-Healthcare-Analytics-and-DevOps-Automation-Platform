const express = require("express");
const cors = require("cors");
const path = require("path");

const store = require("./store");
const { refreshActivity } = require("./simulator");
const { DB_FILE } = require("./database");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());


// ===============================
// HEALTH CHECK
// ===============================

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    message: "MediPulse API is running",
    database: "SQLite"
  });
});


// ===============================
// DATABASE OVERVIEW (tables, row counts, consistency checks)
// ===============================

app.get("/api/db/overview", (req, res) => {
  res.json(store.databaseOverview());
});


// ===============================
// LOGIN
// ===============================

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: "Username and password are required"
    });
  }

  try {
    res.json({
      success: true,
      user: store.login(username, password)
    });
  } catch (err) {
    res.status(err.status || 500).json({
      success: false,
      message: err.message
    });
  }
});


// ===============================
// PATIENT REGISTRATION
// ===============================

app.post("/api/register", (req, res) => {
  try {
    const user = store.registerPatientUser(req.body);

    // Never send password back to frontend
    res.status(201).json({
      success: true,
      message: "Patient account created successfully",
      user
    });
  } catch (err) {
    res.status(err.status || 500).json({
      success: false,
      message: err.message
    });
  }
});


// ===============================
// DASHBOARD STATS
// ===============================

app.get("/api/dashboard/stats", (req, res) => {
  res.json(store.dashboardStats());
});


// ===============================
// PATIENTS
// ===============================

app.get("/api/patients", (req, res) => {
  res.json(store.listPatients());
});

app.get("/api/patients/:id", (req, res) => {
  const patient = store.getPatient(Number(req.params.id));

  if (!patient) {
    return res.status(404).json({ message: "Patient not found" });
  }

  res.json(patient);
});

app.post("/api/patients", (req, res) => {
  res.status(201).json(store.createPatient(req.body));
});

app.delete("/api/patients/:id", (req, res) => {
  store.deletePatient(Number(req.params.id));

  res.json({
    success: true,
    message: "Patient deleted"
  });
});


// ===============================
// APPOINTMENTS
// ===============================

app.get("/api/appointments", (req, res) => {
  res.json(store.listAppointments(req.query.patient));
});

app.post("/api/appointments", (req, res) => {
  res.status(201).json(store.createAppointment(req.body));
});

app.patch("/api/appointments/:id/status", (req, res) => {
  res.json(
    store.updateAppointmentStatus(Number(req.params.id), req.body.status)
  );
});


// ===============================
// DOCTORS
// ===============================

app.get("/api/doctors", (req, res) => {
  res.json(store.listDoctors());
});


// ===============================
// DEPARTMENTS
// ===============================

app.get("/api/departments", (req, res) => {
  res.json(store.listDepartments());
});


// ===============================
// BEDS
// ===============================

app.get("/api/beds", (req, res) => {
  res.json(store.listBeds());
});

app.patch("/api/beds/:id", (req, res) => {
  res.json(store.updateBed(Number(req.params.id), req.body));
});


// ===============================
// ADMISSIONS
// ===============================

app.get("/api/admissions", (req, res) => {
  res.json(store.listAdmissions());
});

app.post("/api/admissions", (req, res) => {
  res.status(201).json(store.createAdmission(req.body));
});

app.patch("/api/admissions/:id/discharge", (req, res) => {
  res.json(store.dischargeAdmission(Number(req.params.id)));
});


// ===============================
// LABS / PRESCRIPTIONS / MEDICAL RECORDS
// (optional ?patient=Name returns only that patient's rows)
// ===============================

app.get("/api/labs", (req, res) => {
  res.json(store.listLabs(req.query.patient));
});

app.get("/api/prescriptions", (req, res) => {
  res.json(store.listPrescriptions(req.query.patient));
});

app.get("/api/records", (req, res) => {
  res.json(store.listRecords(req.query.patient));
});


// ===============================
// ANALYTICS: PREDICTIONS, REPORTS, AI ASSISTANT
// ===============================

try {
  process.loadEnvFile(path.join(__dirname, ".env"));
} catch (err) {
  // .env is optional
}

// The analytics module reads a snapshot of the database and sends the
// hospital's recent history from the database to the ML service.
require("./analytics")(app, store.snapshot, () => store.mlHistory(14));


// ===============================
// ERROR HANDLING
// ===============================

app.use((err, req, res, next) => {
  if (err && err.status && err.status < 500) {
    return res.status(err.status).json({ message: err.message });
  }

  console.error("Server error:", err);
  res.status(500).json({ message: "Something went wrong on the server" });
});


// ===============================
// START SERVER
// ===============================

function prepareDatabase() {
  const result = refreshActivity();

  if (result.seeded) {
    console.log("New database created and filled with a consistent demo hospital.");
  } else if (result.simulated > 0) {
    console.log(`Hospital activity brought up to date (${result.simulated} day(s) simulated).`);
  }
}

prepareDatabase();

// keep the demo hospital current if the server stays up for days
setInterval(() => {
  try {
    prepareDatabase();
  } catch (err) {
    console.error("Activity refresh failed:", err.message);
  }
}, 60 * 60 * 1000).unref();

app.listen(PORT, () => {
  console.log(`MediPulse API running on http://localhost:${PORT}`);
  console.log(`Database: ${DB_FILE}`);
});
