// Deletes the database file and creates a fresh, consistent demo hospital.
//   npm run db:reset
const fs = require("fs");
const path = require("path");

const file = process.env.DB_PATH || path.join(__dirname, "data", "medipulse.sqlite");

fs.rmSync(file, { force: true });
fs.rmSync(`${file}-journal`, { force: true });

const { refreshActivity } = require("./simulator");
const { databaseOverview } = require("./store");

refreshActivity();

const overview = databaseOverview();

console.log(`New database created: ${overview.file}\n`);
overview.tables.forEach((t) => console.log(`  ${t.table.padEnd(14)} ${t.rows} rows`));
console.log(`\nIntegrity: ${overview.integrity.ok ? "all checks passed" : "PROBLEMS FOUND"}`);
