// ======================================================================
// MediPulse - Database layer (SQLite)
// ----------------------------------------------------------------------
// A real relational database stored in one file (default:
// server/data/medipulse.sqlite). It uses Node's built-in SQLite module,
// so there is nothing extra to install (Node.js 22.13+).
//
// Relationships are enforced by the database itself:
//   * foreign keys  (an admission must point to a real patient, doctor, bed)
//   * constraints   (valid statuses, one active admission per bed/patient)
//   * triggers      (admitting a patient occupies the bed, discharging frees it,
//                    a bed cannot be "Occupied" without an admitted patient)
// ======================================================================

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// The built-in SQLite module prints an "experimental" notice - keep the logs clean.
let DatabaseSync;
{
  const original = process.emitWarning;

  process.emitWarning = function (warning, ...args) {
    const text =
      typeof warning === "string" ? warning : (warning && warning.message) || "";
    if (/sqlite/i.test(text)) return;
    return original.call(process, warning, ...args);
  };

  try {
    ({ DatabaseSync } = require("node:sqlite"));
  } catch (err) {
    process.emitWarning = original;
    throw new Error(
      `MediPulse needs Node.js 22.13 or newer (built-in SQLite). You are running ${process.version}.`
    );
  }

  process.emitWarning = original;
}

const DB_FILE =
  process.env.DB_PATH || path.join(__dirname, "data", "medipulse.sqlite");

fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const db = new DatabaseSync(DB_FILE);

db.exec("PRAGMA foreign_keys = ON");
db.exec("PRAGMA busy_timeout = 5000");


// ======================================================================
// SCHEMA
// ======================================================================

db.exec(`
CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS departments (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS doctors (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL UNIQUE COLLATE NOCASE,
  department_id INTEGER NOT NULL REFERENCES departments(id)
);

CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  name          TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('doctor', 'patient', 'admin'))
);

CREATE TABLE IF NOT EXISTS patients (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        TEXT UNIQUE REFERENCES users(id),
  name           TEXT NOT NULL UNIQUE COLLATE NOCASE,
  age            INTEGER CHECK (age IS NULL OR (age >= 0 AND age <= 120)),
  gender         TEXT CHECK (gender IS NULL OR gender IN ('Male', 'Female', 'Other')),
  phone          TEXT,
  department_id  INTEGER NOT NULL REFERENCES departments(id),
  doctor_id      INTEGER REFERENCES doctors(id),
  status         TEXT NOT NULL DEFAULT 'Active'
                 CHECK (status IN ('Active', 'Admitted', 'Discharged')),
  blood_pressure TEXT,
  heart_rate     INTEGER,
  created_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS beds (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  bed_number    TEXT NOT NULL UNIQUE COLLATE NOCASE,
  department_id INTEGER NOT NULL REFERENCES departments(id),
  status        TEXT NOT NULL DEFAULT 'Available'
                CHECK (status IN ('Available', 'Occupied', 'Maintenance'))
);

CREATE TABLE IF NOT EXISTS admissions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id    INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id     INTEGER NOT NULL REFERENCES doctors(id),
  department_id INTEGER NOT NULL REFERENCES departments(id),
  bed_id        INTEGER NOT NULL REFERENCES beds(id),
  admitted_on   TEXT NOT NULL,
  discharged_on TEXT,
  status        TEXT NOT NULL CHECK (status IN ('Admitted', 'Discharged')),
  CHECK (
    (status = 'Admitted'   AND discharged_on IS NULL) OR
    (status = 'Discharged' AND discharged_on IS NOT NULL AND discharged_on >= admitted_on)
  )
);

-- A bed holds at most one admitted patient, and a patient occupies at most one bed.
CREATE UNIQUE INDEX IF NOT EXISTS ux_admission_active_bed
  ON admissions(bed_id) WHERE status = 'Admitted';
CREATE UNIQUE INDEX IF NOT EXISTS ux_admission_active_patient
  ON admissions(patient_id) WHERE status = 'Admitted';
CREATE INDEX IF NOT EXISTS ix_admissions_dates ON admissions(admitted_on, discharged_on);

CREATE TABLE IF NOT EXISTS appointments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id    INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id     INTEGER NOT NULL REFERENCES doctors(id),
  department_id INTEGER NOT NULL REFERENCES departments(id),
  date          TEXT NOT NULL,
  time          TEXT NOT NULL,
  type          TEXT NOT NULL DEFAULT 'Consultation',
  status        TEXT NOT NULL DEFAULT 'Upcoming'
                CHECK (status IN ('Upcoming', 'Confirmed', 'Waiting', 'Completed', 'Cancelled'))
);
CREATE INDEX IF NOT EXISTS ix_appointments_date ON appointments(date, department_id);
CREATE INDEX IF NOT EXISTS ix_appointments_patient ON appointments(patient_id);

CREATE TABLE IF NOT EXISTS labs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id  INTEGER NOT NULL REFERENCES doctors(id),
  test       TEXT NOT NULL,
  short_name TEXT NOT NULL,
  lab_name   TEXT NOT NULL DEFAULT 'MediPulse Diagnostic Lab',
  date       TEXT NOT NULL,
  result     TEXT NOT NULL,
  summary    TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'Completed' CHECK (status IN ('Completed', 'Pending'))
);

CREATE TABLE IF NOT EXISTS prescriptions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id   INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id    INTEGER NOT NULL REFERENCES doctors(id),
  medicine     TEXT NOT NULL,
  dosage       TEXT NOT NULL,
  frequency    TEXT NOT NULL,
  duration     TEXT NOT NULL,
  instructions TEXT NOT NULL,
  date         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS records (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id  INTEGER NOT NULL REFERENCES doctors(id),
  type       TEXT NOT NULL,
  date       TEXT NOT NULL,
  summary    TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- TRIGGERS: the database keeps beds, admissions and patients consistent
-- ---------------------------------------------------------------------

-- Only a free bed can be used for a new admission.
CREATE TRIGGER IF NOT EXISTS trg_admission_needs_free_bed
BEFORE INSERT ON admissions
WHEN NEW.status = 'Admitted'
BEGIN
  SELECT RAISE(ABORT, 'Bed is not available')
  WHERE (SELECT status FROM beds WHERE id = NEW.bed_id) <> 'Available';
END;

-- Admitting a patient occupies the bed and marks the patient Admitted.
CREATE TRIGGER IF NOT EXISTS trg_admission_occupies_bed
AFTER INSERT ON admissions
WHEN NEW.status = 'Admitted'
BEGIN
  UPDATE beds     SET status = 'Occupied' WHERE id = NEW.bed_id;
  UPDATE patients SET status = 'Admitted' WHERE id = NEW.patient_id;
END;

-- Discharging frees the bed and marks the patient Discharged.
CREATE TRIGGER IF NOT EXISTS trg_discharge_frees_bed
AFTER UPDATE OF status ON admissions
WHEN OLD.status = 'Admitted' AND NEW.status = 'Discharged'
BEGIN
  UPDATE beds     SET status = 'Available'  WHERE id = NEW.bed_id AND status = 'Occupied';
  UPDATE patients SET status = 'Discharged' WHERE id = NEW.patient_id;
END;

-- A bed can only be Occupied while a patient is admitted to it ...
CREATE TRIGGER IF NOT EXISTS trg_bed_occupied_needs_admission
BEFORE UPDATE OF status ON beds
WHEN NEW.status = 'Occupied' AND OLD.status <> 'Occupied'
BEGIN
  SELECT RAISE(ABORT, 'A bed becomes occupied only by admitting a patient')
  WHERE NOT EXISTS (SELECT 1 FROM admissions WHERE bed_id = NEW.id AND status = 'Admitted');
END;

-- ... and cannot be freed while that patient is still admitted.
CREATE TRIGGER IF NOT EXISTS trg_bed_release_needs_discharge
BEFORE UPDATE OF status ON beds
WHEN OLD.status = 'Occupied' AND NEW.status <> 'Occupied'
BEGIN
  SELECT RAISE(ABORT, 'Bed is occupied - discharge the patient first')
  WHERE EXISTS (SELECT 1 FROM admissions WHERE bed_id = NEW.id AND status = 'Admitted');
END;
`);


// ======================================================================
// HELPERS
// ======================================================================

// Run several statements as one all-or-nothing transaction.
function tx(fn) {
  db.exec("BEGIN");

  try {
    const result = fn();
    db.exec("COMMIT");
    return result;
  } catch (err) {
    try {
      db.exec("ROLLBACK");
    } catch (rollbackError) {
      // transaction already closed
    }
    throw err;
  }
}

// Same "today" rule as the frontend (UTC date, YYYY-MM-DD)
const todayISO = () => new Date().toISOString().split("T")[0];

function addDays(iso, days) {
  const date = new Date(`${iso}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().split("T")[0];
}

function daysBetween(fromISO, toISO) {
  return Math.round(
    (new Date(`${toISO}T00:00:00Z`) - new Date(`${fromISO}T00:00:00Z`)) / 86400000
  );
}

// Passwords are stored as salted scrypt hashes (never as plain text)
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

function verifyPassword(password, stored) {
  const [scheme, salt, hash] = String(stored).split("$");

  if (scheme !== "scrypt" || !salt || !hash) return false;

  const expected = Buffer.from(hash, "hex");
  const actual = crypto.scryptSync(String(password), salt, expected.length);

  return crypto.timingSafeEqual(expected, actual);
}

const getMeta = (key) => {
  const row = db.prepare("SELECT value FROM meta WHERE key = ?").get(key);
  return row ? row.value : null;
};

const setMeta = (key, value) =>
  db
    .prepare(
      "INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
    )
    .run(key, String(value));


module.exports = {
  db,
  DB_FILE,
  tx,
  todayISO,
  addDays,
  daysBetween,
  hashPassword,
  verifyPassword,
  getMeta,
  setMeta
};
