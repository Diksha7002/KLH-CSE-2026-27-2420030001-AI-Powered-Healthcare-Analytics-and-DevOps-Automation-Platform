// Prints a health report for the database. Exit code 1 if any check fails.
//   npm run db:check
const { databaseOverview } = require("./store");

const overview = databaseOverview();

console.log(`Database: ${overview.engine} - ${overview.file}\n`);
overview.tables.forEach((t) => console.log(`  ${t.table.padEnd(14)} ${String(t.rows).padStart(5)} rows`));
console.log("\nConsistency checks:");
overview.integrity.checks.forEach((c) =>
  console.log(`  ${c.ok ? "PASS" : "FAIL"}  ${c.name}  (${c.detail})`)
);

process.exit(overview.integrity.ok ? 0 : 1);
