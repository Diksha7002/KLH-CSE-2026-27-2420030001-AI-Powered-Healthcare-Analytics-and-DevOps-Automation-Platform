// ======================================================================
// MediPulse - Hospital data seeder / activity simulator
// ----------------------------------------------------------------------
// * First start (empty database): creates a coherent hospital - doctors,
//   beds, ~380 patients - and simulates the last 15 days of activity
//   (visits, admissions, discharges) day by day, so every bed that is
//   occupied really has an admitted patient.
// * Every later start: continues the simulation for the days that have
//   passed since the last run, so charts and predictions stay current.
//   (Set SIMULATE_ACTIVITY=false to turn this off.)
//
// The hospital profile below is the same one used to generate the machine
// learning training dataset (ml/generate_dataset.py) - keep them in sync.
// ======================================================================

const {
  db,
  tx,
  todayISO,
  addDays,
  hashPassword,
  getMeta,
  setMeta
} = require("./database");

const HISTORY_DAYS = 15;


// ----------------------------------------------------------------------
// Hospital profile (shared with ml/generate_dataset.py)
// ----------------------------------------------------------------------

const PROFILE = {
  "ICU":              { prefix: "ICU",  beds: 6, usable: 5, stay: 4.5, occ: 0.68, visits: 2,   emergency: 0.5 },
  "General Medicine": { prefix: "GEN",  beds: 8, usable: 8, stay: 3.8, occ: 0.62, visits: 9,   emergency: 0.15 },
  "Emergency":        { prefix: "EMR",  beds: 6, usable: 5, stay: 1.3, occ: 0.62, visits: 11,  emergency: 0.9 },
  "Pediatrics":       { prefix: "PED",  beds: 5, usable: 5, stay: 3.0, occ: 0.55, visits: 5,   emergency: 0.2 },
  "Cardiology":       { prefix: "CARD", beds: 5, usable: 5, stay: 4.2, occ: 0.58, visits: 5.5, emergency: 0.2 },
  "Neurology":        { prefix: "NEU",  beds: 4, usable: 4, stay: 4.0, occ: 0.55, visits: 3.5, emergency: 0.1 },
  "Orthopedics":      { prefix: "ORT",  beds: 4, usable: 4, stay: 3.5, occ: 0.55, visits: 4,   emergency: 0.2 }
};

// day of week multipliers (Mon..Sun)
const DOW = {
  "ICU":              [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
  "General Medicine": [1.15, 1.05, 1.0, 1.0, 1.02, 0.88, 0.8],
  "Emergency":        [1.05, 0.95, 0.95, 0.98, 1.08, 1.12, 1.1],
  "Pediatrics":       [1.1, 1.05, 1.0, 1.0, 1.0, 0.88, 0.82],
  "Cardiology":       [1.1, 1.08, 1.05, 1.05, 1.02, 0.6, 0.5],
  "Neurology":        [1.1, 1.05, 1.0, 1.0, 1.0, 0.7, 0.5],
  "Orthopedics":      [1.15, 1.1, 1.0, 1.0, 1.0, 0.8, 0.6]
};

// month multipliers (Jan..Dec)
const MONTH = {
  "ICU":              [1.08, 1.05, 1.0, 0.97, 0.97, 0.98, 1.02, 1.03, 1.03, 1.0, 1.02, 1.08],
  "General Medicine": [1.05, 1.0, 0.97, 0.95, 0.95, 1.0, 1.1, 1.12, 1.1, 1.0, 1.0, 1.03],
  "Emergency":        [1.0, 0.98, 1.0, 1.02, 1.05, 1.03, 1.0, 1.0, 1.0, 1.05, 1.03, 1.05],
  "Pediatrics":       [1.02, 0.98, 0.95, 0.92, 0.9, 1.0, 1.22, 1.28, 1.22, 1.05, 0.98, 1.0],
  "Cardiology":       [1.15, 1.12, 1.03, 0.97, 0.95, 0.93, 0.95, 0.95, 0.98, 1.02, 1.08, 1.15],
  "Neurology":        [1.05, 1.03, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.02, 1.05],
  "Orthopedics":      [1.0, 1.0, 1.0, 1.02, 1.05, 1.05, 1.08, 1.08, 1.05, 1.02, 1.0, 1.0]
};

// patients registered per department (named demo patients included)
const POOL_SIZE = {
  "ICU": 12, "General Medicine": 70, "Emergency": 110, "Pediatrics": 40,
  "Cardiology": 45, "Neurology": 35, "Orthopedics": 45
};

const ADMISSION_RATE = {};
Object.entries(PROFILE).forEach(([dept, p]) => {
  ADMISSION_RATE[dept] = (p.occ * p.usable / p.stay) / p.visits;
});

// Order matters: the first five keep the ids of the original project.
const DEPARTMENTS = [
  "Cardiology", "General Medicine", "Neurology", "Orthopedics", "Pediatrics",
  "Emergency", "ICU"
];

const DOCTORS = [
  ["Dr. Arjun Mehta", "Cardiology"],
  ["Dr. Priya Nair", "General Medicine"],
  ["Dr. Iyer", "Neurology"],
  ["Dr. Kapoor", "Orthopedics"],
  ["Dr. Shah", "Pediatrics"],
  ["Dr. Kavita Rao", "Cardiology"],
  ["Dr. Sameer Joshi", "General Medicine"],
  ["Dr. Meena Krishnan", "Neurology"],
  ["Dr. Rohit Desai", "Orthopedics"],
  ["Dr. Anjali Menon", "Pediatrics"],
  ["Dr. Vikram Singh", "Emergency"],
  ["Dr. Neha Bansal", "Emergency"],
  ["Dr. Sanjay Gupta", "ICU"],
  ["Dr. Farah Khan", "ICU"]
];

const WARD_BUILD_ORDER = ["ICU", "General Medicine", "Emergency", "Pediatrics", "Cardiology", "Neurology", "Orthopedics"];

// Demo patients (the original project's patients + the people who were only
// shown inside Beds / Appointments before) - all are real patient rows now.
const NAMED_PATIENTS = [
  ["Aarav Sharma", 34, "Male", "Cardiology", "Dr. Arjun Mehta", "9876543210"],
  ["Priya Verma", 29, "Female", "General Medicine", "Dr. Priya Nair", "9876543211"],
  ["Rohan Patel", 46, "Male", "Neurology", "Dr. Iyer", "9876543212"],
  ["Sneha Reddy", 25, "Female", "Orthopedics", "Dr. Kapoor", "9876543213"],
  ["Vihaan Shah", 12, "Male", "Pediatrics", "Dr. Shah", "9876543214"],
  ["Diksha", 22, "Female", "General Medicine", "Dr. Priya Nair", null],
  ["Rohan Verma", 52, "Male", "ICU", null, null],
  ["Ananya Rao", 61, "Female", "ICU", null, null],
  ["Karan Malhotra", 47, "Male", "ICU", null, null],
  ["Meera Sharma", 38, "Female", "General Medicine", null, null],
  ["Aditya Rao", 44, "Male", "General Medicine", null, null],
  ["Neeraj Kumar", 57, "Male", "General Medicine", null, null],
  ["Kiran Varma", 31, "Male", "General Medicine", "Dr. Priya Nair", null],
  ["Simran Patel", 27, "Female", "Emergency", null, null],
  ["Vikram Shah", 36, "Male", "Emergency", null, null],
  ["Nisha Reddy", 41, "Female", "Emergency", null, null],
  ["Aanya Mehta", 7, "Female", "Pediatrics", null, null],
  ["Arnav Gupta", 9, "Male", "Pediatrics", null, null],
  ["Rahul Sharma", 11, "Male", "Pediatrics", "Dr. Shah", null],
  ["Rahul Mehta", 58, "Male", "Cardiology", null, null],
  ["Pooja Nair", 49, "Female", "Cardiology", null, null]
];

const MALE_FIRST = ["Aarav","Vihaan","Arjun","Aditya","Rohan","Karan","Rahul","Vikram","Siddharth","Rajesh","Amit","Suresh","Manoj","Anil","Sanjay","Deepak","Nikhil","Pranav","Harsh","Kunal","Ishaan","Varun","Gaurav","Mohit","Ankit","Tarun","Yash","Dev","Kabir","Rohit","Naveen","Prakash","Ramesh","Sunil","Vivek","Abhishek","Ashok","Dinesh","Lokesh","Mahesh"];
const FEMALE_FIRST = ["Priya","Ananya","Sneha","Pooja","Meera","Kavya","Diya","Aanya","Neha","Riya","Sana","Isha","Nisha","Simran","Divya","Anjali","Shreya","Tanvi","Swati","Lakshmi","Sunita","Rekha","Geeta","Radha","Vidya","Mansi","Pallavi","Nandini","Bhavna","Aditi","Jyoti","Komal","Payal","Preeti","Ritu","Shalini","Usha","Varsha","Zoya","Harini"];
const SURNAMES = ["Sharma","Verma","Patel","Reddy","Shah","Mehta","Rao","Nair","Gupta","Kumar","Singh","Iyer","Menon","Joshi","Kapoor","Malhotra","Desai","Bansal","Agarwal","Chopra","Mishra","Pandey","Yadav","Khan","Naidu","Pillai","Das","Ghosh","Bose","Chatterjee","Banerjee","Saxena","Trivedi","Kulkarni","Patil","Jain","Bhatt","Thakur","Chauhan","Sinha"];

const SLOT_MINUTES = [];
for (let m = 9 * 60; m <= 20 * 60 + 30; m += 30) SLOT_MINUTES.push(m);

const formatSlot = (minutes) => {
  let hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  const marker = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 === 0 ? 12 : hours % 12;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")} ${marker}`;
};

const SLOTS = SLOT_MINUTES.map(formatSlot);
const WORKING_SLOTS = SLOTS.slice(0, 16);

const NON_EMERGENCY_TYPES = ["Consultation", "Follow-up", "Routine Checkup"];

// Clinical content used for records, labs and prescriptions
const CLINICAL = {
  "Cardiology": {
    records: ["Routine cardiac examination", "ECG reviewed - normal sinus rhythm", "Blood pressure follow-up", "Chest discomfort evaluation"],
    labs: [["Lipid Profile", "LIPID"], ["Cardiac Enzyme Panel", "TROP"]],
    meds: [["Aspirin 75mg", "1 tablet", "Once daily", "30 days", "Take after breakfast."], ["Atorvastatin 10mg", "1 tablet", "Once daily", "30 days", "Take after dinner."], ["Amlodipine 5mg", "1 tablet", "Once daily", "30 days", "Take in the morning."]]
  },
  "General Medicine": {
    records: ["General health consultation", "Seasonal fever - supportive treatment", "Diabetes follow-up", "Hypertension review"],
    labs: [["Complete Blood Count", "CBC"], ["Blood Glucose Test", "GLU"], ["Thyroid Function Test", "TFT"]],
    meds: [["Paracetamol 500mg", "1 tablet", "As needed", "7 days", "Take after food when required."], ["Vitamin D3", "1 capsule", "Once weekly", "8 weeks", "Take after a meal."], ["Metformin 500mg", "1 tablet", "Twice daily", "30 days", "Take with meals."]]
  },
  "Neurology": {
    records: ["Neurological follow-up examination", "Migraine assessment", "Dizziness evaluation"],
    labs: [["MRI Brain", "MRI"], ["EEG", "EEG"]],
    meds: [["Sumatriptan 50mg", "1 tablet", "As needed", "14 days", "Take at the onset of a migraine."], ["Gabapentin 100mg", "1 capsule", "Twice daily", "30 days", "Take after food."]]
  },
  "Orthopedics": {
    records: ["Routine orthopedic consultation", "Knee pain assessment", "Post-fracture follow-up"],
    labs: [["X-Ray", "XRAY"], ["Vitamin D Level", "VITD"]],
    meds: [["Ibuprofen 400mg", "1 tablet", "Twice daily", "7 days", "Take after food."], ["Calcium 500mg", "1 tablet", "Once daily", "60 days", "Take after lunch."]]
  },
  "Pediatrics": {
    records: ["Child wellness check", "Vaccination review", "Fever and cold - observation"],
    labs: [["Complete Blood Count", "CBC"], ["Hemoglobin Test", "HB"]],
    meds: [["Paracetamol Syrup 5ml", "5 ml", "As needed", "5 days", "Use the measuring cap provided."], ["ORS Sachet", "1 sachet", "Three times daily", "3 days", "Mix in one glass of clean water."]]
  },
  "Emergency": {
    records: ["Emergency assessment and treatment", "Minor injury - wound care", "Acute abdominal pain evaluation"],
    labs: [["Complete Blood Count", "CBC"], ["Electrolyte Panel", "ELEC"]],
    meds: [["Cetirizine 10mg", "1 tablet", "Once daily", "5 days", "Take at bedtime."], ["Pantoprazole 40mg", "1 tablet", "Once daily", "14 days", "Take before breakfast."]]
  },
  "ICU": {
    records: ["Critical care monitoring review", "Post-operative ICU review"],
    labs: [["Arterial Blood Gas", "ABG"], ["Electrolyte Panel", "ELEC"]],
    meds: [["Pantoprazole 40mg", "1 tablet", "Once daily", "14 days", "Take before breakfast."]]
  }
};


// ----------------------------------------------------------------------
// Small random helpers (seeded, so the demo data is reproducible)
// ----------------------------------------------------------------------

function hashString(text) {
  let h = 2166136261;
  for (const ch of text) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  return h;
}

class Rand {
  constructor(seed) {
    this.state = seed >>> 0;
  }

  next() {
    this.state = (this.state + 0x6d2b79f5) | 0;
    let t = Math.imul(this.state ^ (this.state >>> 15), 1 | this.state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  int(min, max) {
    return min + Math.floor(this.next() * (max - min + 1));
  }

  chance(p) {
    return this.next() < p;
  }

  pick(list) {
    return list[Math.floor(this.next() * list.length)];
  }

  normal(mean, sd) {
    const u = Math.max(this.next(), 1e-9);
    const v = this.next();
    return mean + sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  // 2.4 -> 2 or 3 (3 with 40% probability)
  probRound(x) {
    const base = Math.floor(x);
    return base + (this.next() < x - base ? 1 : 0);
  }
}

const weekdayIndex = (iso) => (new Date(`${iso}T00:00:00Z`).getUTCDay() + 6) % 7;
const monthIndex = (iso) => Number(iso.slice(5, 7)) - 1;

function visitsFor(dept, date, rand) {
  const mean = PROFILE[dept].visits * DOW[dept][weekdayIndex(date)] * MONTH[dept][monthIndex(date)];
  return Math.max(0, Math.round(mean * (1 + rand.normal(0, 0.12))));
}


// ----------------------------------------------------------------------
// Lookups used while simulating
// ----------------------------------------------------------------------

function loadContext() {
  const departments = db.prepare("SELECT id, name FROM departments").all();
  const deptId = Object.fromEntries(departments.map((d) => [d.name, d.id]));
  const deptName = Object.fromEntries(departments.map((d) => [d.id, d.name]));

  const doctorsByDept = {};
  db.prepare("SELECT id, department_id FROM doctors").all().forEach((d) => {
    (doctorsByDept[d.department_id] = doctorsByDept[d.department_id] || []).push(d.id);
  });

  const poolByDept = {};
  db.prepare("SELECT id, department_id FROM patients").all().forEach((p) => {
    (poolByDept[p.department_id] = poolByDept[p.department_id] || []).push(p.id);
  });

  return { deptId, deptName, doctorsByDept, poolByDept, taken: new Map() };
}

// free appointment slot for a doctor on a day (no double-booking)
function freeSlot(ctx, doctorId, date, rand, slots = WORKING_SLOTS) {
  const key = `${doctorId}|${date}`;

  if (!ctx.taken.has(key)) {
    const used = db
      .prepare("SELECT time FROM appointments WHERE doctor_id = ? AND date = ? AND status <> 'Cancelled'")
      .all(doctorId, date)
      .map((r) => r.time);
    ctx.taken.set(key, new Set(used));
  }

  const used = ctx.taken.get(key);
  const free = slots.filter((s) => !used.has(s));

  if (free.length === 0) return null;

  const slot = rand.pick(free);
  used.add(slot);
  return slot;
}

function insertAppointment(ctx, { patientId, doctorId, deptId, date, time, type, status }) {
  if (status !== "Cancelled" && time && ctx.taken.has(`${doctorId}|${date}`)) {
    ctx.taken.get(`${doctorId}|${date}`).add(time);
  }

  db.prepare(
    `INSERT INTO appointments (patient_id, doctor_id, department_id, date, time, type, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(patientId, doctorId, deptId, date, time, type, status);
}

// patients of a department that have no appointment yet on a given day
function availablePatients(ctx, deptId, date) {
  const busy = new Set(
    db
      .prepare("SELECT patient_id FROM appointments WHERE date = ? AND department_id = ?")
      .all(date, deptId)
      .map((r) => r.patient_id)
  );

  const pool = ctx.poolByDept[deptId] || [];
  const free = pool.filter((id) => !busy.has(id));

  return free.length ? free : pool;
}

function addAppointments(ctx, rand, dept, date, count, { status, emergencyShare, workingHours = false }) {
  const deptId = ctx.deptId[dept];
  const doctors = ctx.doctorsByDept[deptId];
  let patients = availablePatients(ctx, deptId, date);

  for (let i = 0; i < count && patients.length; i += 1) {
    const patientId = rand.pick(patients);
    patients = patients.filter((id) => id !== patientId);

    const doctorId = rand.pick(doctors);
    const emergency = rand.chance(emergencyShare);
    const time = freeSlot(ctx, doctorId, date, rand, emergency && !workingHours ? SLOTS : WORKING_SLOTS);

    if (!time) continue;

    insertAppointment(ctx, {
      patientId,
      doctorId,
      deptId,
      date,
      time,
      type: emergency ? "Emergency" : rand.pick(NON_EMERGENCY_TYPES),
      status: typeof status === "function" ? status(emergency, i, count) : status
    });
  }
}


// ----------------------------------------------------------------------
// One simulated day: visits, discharges, admissions
// ----------------------------------------------------------------------

function simulateDay(ctx, date, rand) {
  WARD_BUILD_ORDER.forEach((dept) => {
    const profile = PROFILE[dept];
    const deptId = ctx.deptId[dept];

    // ---- visits (top up to the expected volume for that day)
    const target = visitsFor(dept, date, rand);
    const existing = db
      .prepare("SELECT COUNT(*) AS n FROM appointments WHERE date = ? AND department_id = ? AND status <> 'Cancelled'")
      .get(date, deptId).n;

    addAppointments(ctx, rand, dept, date, Math.max(0, target - existing), {
      status: "Completed",
      emergencyShare: profile.emergency
    });

    addAppointments(ctx, rand, dept, date, rand.probRound(target * 0.06), {
      status: "Cancelled",
      emergencyShare: 0
    });

    const visits = db
      .prepare("SELECT COUNT(*) AS n FROM appointments WHERE date = ? AND department_id = ? AND status <> 'Cancelled'")
      .get(date, deptId).n;

    // ---- discharges
    const active = db
      .prepare(
        `SELECT a.id, a.admitted_on FROM admissions a JOIN beds b ON b.id = a.bed_id
         WHERE b.department_id = ? AND a.status = 'Admitted'`
      )
      .all(deptId);

    const eligible = active.filter((a) => a.admitted_on < date);
    let discharges = Math.min(
      eligible.length,
      rand.probRound(Math.max(0, (active.length / profile.stay) * rand.normal(1, 0.15)))
    );

    while (discharges > 0 && eligible.length) {
      // longer stays are more likely to be discharged first
      const weights = eligible.map(
        (a) => Math.max(1, Math.round((new Date(date) - new Date(a.admitted_on)) / 86400000)) + 1
      );
      let roll = rand.next() * weights.reduce((s, w) => s + w, 0);
      let index = 0;

      while (index < weights.length - 1 && roll >= weights[index]) {
        roll -= weights[index];
        index += 1;
      }

      const [chosen] = eligible.splice(index, 1);

      db.prepare("UPDATE admissions SET status = 'Discharged', discharged_on = ? WHERE id = ?").run(date, chosen.id);
      discharges -= 1;
    }

    // ---- admissions (cannot exceed free beds)
    const freeBeds = db
      .prepare("SELECT id FROM beds WHERE department_id = ? AND status = 'Available' ORDER BY id")
      .all(deptId)
      .map((b) => b.id);

    const wanted = rand.probRound(Math.max(0, visits * ADMISSION_RATE[dept] * rand.normal(1, 0.15)));
    const admissions = Math.min(wanted, freeBeds.length);

    for (let i = 0; i < admissions; i += 1) {
      const bedId = freeBeds.splice(rand.int(0, freeBeds.length - 1), 1)[0];

      // prefer someone who visited this department today, otherwise anyone not already admitted
      const visitors = db
        .prepare(
          `SELECT DISTINCT a.patient_id AS id FROM appointments a JOIN patients p ON p.id = a.patient_id
           WHERE a.date = ? AND a.department_id = ? AND a.status <> 'Cancelled' AND p.status <> 'Admitted'`
        )
        .all(date, deptId)
        .map((r) => r.id);

      const candidates = visitors.length
        ? visitors
        : (ctx.poolByDept[deptId] || []).filter(
            (id) => db.prepare("SELECT status FROM patients WHERE id = ?").get(id).status !== "Admitted"
          );

      if (!candidates.length) break;

      db.prepare(
        `INSERT INTO admissions (patient_id, doctor_id, department_id, bed_id, admitted_on, status)
         VALUES (?, ?, ?, ?, ?, 'Admitted')`
      ).run(rand.pick(candidates), rand.pick(ctx.doctorsByDept[deptId]), deptId, bedId, date);
    }
  });
}

// Patients already in hospital when the simulated period starts
function prefillAdmissions(ctx, rand, startDate) {
  WARD_BUILD_ORDER.forEach((dept) => {
    const profile = PROFILE[dept];
    const deptId = ctx.deptId[dept];

    const count = Math.max(0, Math.min(profile.usable, Math.round(profile.occ * profile.usable + rand.normal(0, 0.7))));
    const freeBeds = db
      .prepare("SELECT id FROM beds WHERE department_id = ? AND status = 'Available' ORDER BY id")
      .all(deptId)
      .map((b) => b.id);

    let pool = [...(ctx.poolByDept[deptId] || [])];

    for (let i = 0; i < count && freeBeds.length && pool.length; i += 1) {
      const bedId = freeBeds.splice(rand.int(0, freeBeds.length - 1), 1)[0];
      const patientId = pool.splice(rand.int(0, pool.length - 1), 1)[0];

      db.prepare(
        `INSERT INTO admissions (patient_id, doctor_id, department_id, bed_id, admitted_on, status)
         VALUES (?, ?, ?, ?, ?, 'Admitted')`
      ).run(
        patientId,
        rand.pick(ctx.doctorsByDept[deptId]),
        deptId,
        bedId,
        addDays(startDate, -rand.int(1, Math.ceil(profile.stay * 1.5)))
      );
    }
  });
}


// ----------------------------------------------------------------------
// Today's schedule and the coming week
// ----------------------------------------------------------------------

function scheduleToday(ctx, rand, today) {
  WARD_BUILD_ORDER.forEach((dept) => {
    const deptId = ctx.deptId[dept];
    const existing = db
      .prepare("SELECT COUNT(*) AS n FROM appointments WHERE date = ? AND department_id = ? AND status <> 'Cancelled'")
      .get(today, deptId).n;

    const target = Math.round(visitsFor(dept, today, rand) * (0.5 + rand.next() * 0.2));

    // earlier slots are already done, then someone is waiting, the rest are confirmed
    addAppointments(ctx, rand, dept, today, Math.max(0, target - existing), {
      emergencyShare: PROFILE[dept].emergency,
      status: (emergency, index, total) => {
        if (emergency) return index % 3 === 0 ? "Waiting" : "Completed";
        const position = index / Math.max(1, total);
        return position < 0.4 ? "Completed" : position < 0.55 ? "Waiting" : "Confirmed";
      }
    });

    addAppointments(ctx, rand, dept, today, rand.probRound(target * 0.05), {
      status: "Cancelled",
      emergencyShare: 0
    });
  });

  setMeta("today_scheduled", today);
}

function scheduleUpcoming(ctx, today) {
  const from = getMeta("scheduled_through") || today;
  const start = from > today ? addDays(from, 1) : addDays(today, 1);
  const end = addDays(today, 7);

  for (let date = start; date <= end; date = addDays(date, 1)) {
    const rand = new Rand(hashString(`upcoming${date}`));

    WARD_BUILD_ORDER.forEach((dept) => {
      const count = rand.probRound(visitsFor(dept, date, rand) * (1 - PROFILE[dept].emergency) * 0.75);

      addAppointments(ctx, rand, dept, date, count, {
        emergencyShare: 0,
        workingHours: true,
        status: () => (rand.chance(0.55) ? "Confirmed" : "Upcoming")
      });
    });
  }

  setMeta("scheduled_through", end);
}


// ----------------------------------------------------------------------
// Medical records, lab reports and prescriptions
// ----------------------------------------------------------------------

function addClinicalDocument(rand, kind, row, today, forcedPatient) {
  const content = CLINICAL[row.dept];
  const patientId = forcedPatient || row.patient_id;

  if (kind === "record") {
    db.prepare("INSERT INTO records (patient_id, doctor_id, type, date, summary) VALUES (?, ?, ?, ?, ?)").run(
      patientId, row.doctor_id, row.type, row.date, rand.pick(content.records)
    );
  } else if (kind === "lab") {
    const [test, shortName] = rand.pick(content.labs);
    const review = rand.chance(0.15);
    const pending = row.date >= addDays(today, -2) && rand.chance(0.5);

    db.prepare(
      `INSERT INTO labs (patient_id, doctor_id, test, short_name, date, result, summary, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      patientId, row.doctor_id, test, shortName, row.date,
      review ? "Review Required" : "Normal",
      review ? "Some values need review by your doctor." : "All parameters are within the reference range.",
      pending ? "Pending" : "Completed"
    );
  } else {
    const [medicine, dosage, frequency, duration, instructions] = rand.pick(content.meds);

    db.prepare(
      `INSERT INTO prescriptions (patient_id, doctor_id, medicine, dosage, frequency, duration, instructions, date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(patientId, row.doctor_id, medicine, dosage, frequency, duration, instructions, row.date);
  }
}

function generateClinicalDocuments(rand, today) {
  db.prepare(
    `SELECT a.patient_id, a.doctor_id, a.date, a.type, dep.name AS dept
     FROM appointments a JOIN departments dep ON dep.id = a.department_id
     WHERE a.status = 'Completed' AND a.date < ?`
  ).all(today).forEach((row) => {
    if (rand.chance(0.3)) addClinicalDocument(rand, "record", row, today);
    if (rand.chance(0.12)) addClinicalDocument(rand, "lab", row, today);
    if (rand.chance(0.22)) addClinicalDocument(rand, "rx", row, today);
  });
}

// The demo patient account ("diksha") has a complete history
function addDemoPatientHistory(ctx, today) {
  const patient = db.prepare("SELECT id FROM patients WHERE name = 'Diksha'").get();
  const doctor = (name) => db.prepare("SELECT id FROM doctors WHERE name = ?").get(name).id;

  const rec = (daysAgo, docName, type, summary) =>
    db.prepare("INSERT INTO records (patient_id, doctor_id, type, date, summary) VALUES (?, ?, ?, ?, ?)")
      .run(patient.id, doctor(docName), type, addDays(today, -daysAgo), summary);

  rec(10, "Dr. Priya Nair", "Consultation", "General health consultation");
  rec(25, "Dr. Arjun Mehta", "General Checkup", "Routine cardiac examination");
  rec(40, "Dr. Iyer", "Follow-up", "Neurological follow-up examination");
  rec(55, "Dr. Kapoor", "Consultation", "Routine orthopedic consultation");

  const lab = (daysAgo, docName, test, shortName, summary) =>
    db.prepare(
      `INSERT INTO labs (patient_id, doctor_id, test, short_name, date, result, summary, status)
       VALUES (?, ?, ?, ?, ?, 'Normal', ?, 'Completed')`
    ).run(patient.id, doctor(docName), test, shortName, addDays(today, -daysAgo), summary);

  lab(23, "Dr. Arjun Mehta", "Complete Blood Count", "CBC", "All major blood count parameters are within the normal range.");
  lab(25, "Dr. Arjun Mehta", "Lipid Profile", "LIPID", "Cholesterol and triglyceride levels are within the expected range.");
  lab(31, "Dr. Priya Nair", "Blood Glucose Test", "GLU", "Blood glucose level is within the reference range.");
  lab(36, "Dr. Priya Nair", "Thyroid Function Test", "TFT", "Thyroid hormone levels are within the reference range.");

  const rx = (daysAgo, docName, medicine, dosage, frequency, duration, instructions) =>
    db.prepare(
      `INSERT INTO prescriptions (patient_id, doctor_id, medicine, dosage, frequency, duration, instructions, date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(patient.id, doctor(docName), medicine, dosage, frequency, duration, instructions, addDays(today, -daysAgo));

  rx(10, "Dr. Priya Nair", "Vitamin D3", "1 capsule", "Once weekly", "8 weeks", "Take after a meal.");
  rx(15, "Dr. Priya Nair", "Paracetamol 500mg", "1 tablet", "As needed", "7 days", "Take after food when required.");
  rx(20, "Dr. Arjun Mehta", "Aspirin 75mg", "1 tablet", "Once daily", "30 days", "Take after breakfast.");
  rx(20, "Dr. Arjun Mehta", "Atorvastatin 10mg", "1 tablet", "Once daily", "30 days", "Take after dinner.");
}


// ----------------------------------------------------------------------
// First-time setup
// ----------------------------------------------------------------------

function uniqueName(rand, used, gender) {
  for (;;) {
    const name = `${rand.pick(gender === "Male" ? MALE_FIRST : FEMALE_FIRST)} ${rand.pick(SURNAMES)}`;

    if (!used.has(name.toLowerCase())) {
      used.add(name.toLowerCase());
      return name;
    }
  }
}

function seedEntities(rand, today) {
  const insertDept = db.prepare("INSERT INTO departments (name) VALUES (?)");
  DEPARTMENTS.forEach((name) => insertDept.run(name));

  const deptId = Object.fromEntries(db.prepare("SELECT id, name FROM departments").all().map((d) => [d.name, d.id]));

  const insertDoctor = db.prepare("INSERT INTO doctors (name, department_id) VALUES (?, ?)");
  DOCTORS.forEach(([name, dept]) => insertDoctor.run(name, deptId[dept]));

  const doctorsByDept = {};
  db.prepare("SELECT id, department_id FROM doctors").all().forEach((d) => {
    (doctorsByDept[d.department_id] = doctorsByDept[d.department_id] || []).push(d.id);
  });

  // Demo logins: doctor / doctor123 and diksha / diksha123
  const insertUser = db.prepare("INSERT INTO users (id, username, password_hash, name, role) VALUES (?, ?, ?, ?, ?)");
  insertUser.run("D001", "doctor", hashPassword("doctor123"), "Dr. Arjun Mehta", "doctor");
  insertUser.run("P001", "diksha", hashPassword("diksha123"), "Diksha", "patient");

  // Beds: 38 in total, the last bed of ICU and Emergency is under maintenance
  const insertBed = db.prepare("INSERT INTO beds (bed_number, department_id, status) VALUES (?, ?, ?)");

  WARD_BUILD_ORDER.forEach((dept) => {
    const profile = PROFILE[dept];

    for (let i = 1; i <= profile.beds; i += 1) {
      insertBed.run(
        `${profile.prefix}-${String(i).padStart(2, "0")}`,
        deptId[dept],
        i > profile.usable ? "Maintenance" : "Available"
      );
    }
  });

  // Patients: the named demo patients first, then generated ones up to each department's size
  const used = new Set(NAMED_PATIENTS.map((p) => p[0].toLowerCase()));
  const insertPatient = db.prepare(
    `INSERT INTO patients (user_id, name, age, gender, phone, department_id, doctor_id, status,
                           blood_pressure, heart_rate, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?)`
  );
  const doctorId = (name) => db.prepare("SELECT id FROM doctors WHERE name = ?").get(name).id;

  const vitals = () => [`${rand.int(104, 138)}/${rand.int(66, 90)}`, rand.int(58, 96)];

  NAMED_PATIENTS.forEach(([name, age, gender, dept, doctor, phone]) => {
    const [bp, hr] = name === "Diksha" ? ["118/76", 72] : vitals();

    insertPatient.run(
      name === "Diksha" ? "P001" : null,
      name, age, gender, phone, deptId[dept],
      doctor ? doctorId(doctor) : rand.pick(doctorsByDept[deptId[dept]]),
      bp, hr, addDays(today, -rand.int(30, 300))
    );
  });

  const counts = {};
  NAMED_PATIENTS.forEach((p) => { counts[p[3]] = (counts[p[3]] || 0) + 1; });

  Object.entries(POOL_SIZE).forEach(([dept, size]) => {
    for (let i = counts[dept] || 0; i < size; i += 1) {
      const gender = rand.chance(0.5) ? "Male" : "Female";
      const age =
        dept === "Pediatrics" ? rand.int(1, 14)
        : dept === "Cardiology" ? rand.int(40, 85)
        : dept === "ICU" ? rand.int(30, 85)
        : rand.int(18, 80);
      const [bp, hr] = vitals();

      insertPatient.run(
        null, uniqueName(rand, used, gender), age, gender, `9${rand.int(100000000, 999999999)}`,
        deptId[dept], rand.pick(doctorsByDept[deptId[dept]]), bp, hr, addDays(today, -rand.int(15, 400))
      );
    }
  });
}

function insertStoryAppointments(ctx, today) {
  const story = [
    ["Aarav Sharma", "Dr. Arjun Mehta", "Cardiology", 0, "10:30 AM", "Consultation", "Waiting"],
    ["Priya Verma", "Dr. Priya Nair", "General Medicine", 0, "02:00 PM", "Follow-up", "Confirmed"],
    ["Kiran Varma", "Dr. Priya Nair", "General Medicine", 0, "09:30 AM", "Routine Checkup", "Confirmed"],
    ["Rohan Patel", "Dr. Iyer", "Neurology", 1, "11:00 AM", "Consultation", "Confirmed"],
    ["Rahul Sharma", "Dr. Shah", "Pediatrics", 2, "02:00 PM", "Routine Checkup", "Upcoming"],
    ["Aarav Sharma", "Dr. Kapoor", "Orthopedics", 3, "09:00 AM", "Follow-up", "Upcoming"],
    ["Diksha", "Dr. Kapoor", "Orthopedics", 4, "09:00 AM", "Follow-up", "Upcoming"],
    ["Diksha", "Dr. Priya Nair", "General Medicine", -3, "04:00 PM", "Routine Checkup", "Completed"]
  ];

  story.forEach(([patient, doctor, dept, offset, time, type, status]) => {
    insertAppointment(ctx, {
      patientId: db.prepare("SELECT id FROM patients WHERE name = ?").get(patient).id,
      doctorId: db.prepare("SELECT id FROM doctors WHERE name = ?").get(doctor).id,
      deptId: ctx.deptId[dept],
      date: addDays(today, offset),
      time,
      type,
      status
    });
  });
}

function seedDatabase(today) {
  tx(() => {
    const rand = new Rand(hashString("medipulse-seed"));

    seedEntities(rand, today);

    const ctx = loadContext();
    const yesterday = addDays(today, -1);
    const start = addDays(yesterday, -(HISTORY_DAYS - 1));

    insertStoryAppointments(ctx, today);
    prefillAdmissions(ctx, rand, start);

    for (let date = start; date <= yesterday; date = addDays(date, 1)) {
      simulateDay(ctx, date, new Rand(hashString(`day${date}`)));
    }

    generateClinicalDocuments(rand, today);
    addDemoPatientHistory(ctx, today);

    scheduleToday(ctx, new Rand(hashString(`today${today}`)), today);
    scheduleUpcoming(ctx, today);

    setMeta("last_simulated_date", yesterday);
    setMeta("seeded_on", today);
  });
}


// ----------------------------------------------------------------------
// Keep the demo hospital "alive" (runs on every server start)
// ----------------------------------------------------------------------

function refreshActivity() {
  const today = todayISO();

  if (db.prepare("SELECT COUNT(*) AS n FROM departments").get().n === 0) {
    seedDatabase(today);
    return { seeded: true };
  }

  if (process.env.SIMULATE_ACTIVITY === "false") {
    return { seeded: false, simulated: 0 };
  }

  let simulated = 0;

  tx(() => {
    const ctx = loadContext();
    const yesterday = addDays(today, -1);

    // appointments in the past can no longer be waiting for the future
    db.prepare(
      "UPDATE appointments SET status = 'Completed' WHERE date < ? AND status IN ('Upcoming', 'Confirmed', 'Waiting')"
    ).run(today);

    const windowStart = addDays(yesterday, -(HISTORY_DAYS - 1));
    const last = getMeta("last_simulated_date");
    const from = last && addDays(last, 1) > windowStart ? addDays(last, 1) : windowStart;

    for (let date = from; date <= yesterday; date = addDays(date, 1)) {
      simulateDay(ctx, date, new Rand(hashString(`day${date}`)));
      simulated += 1;
    }

    if (simulated > 0) setMeta("last_simulated_date", yesterday);

    if (getMeta("today_scheduled") !== today) {
      scheduleToday(ctx, new Rand(hashString(`today${today}`)), today);
    }

    scheduleUpcoming(ctx, today);
  });

  return { seeded: false, simulated };
}


module.exports = { refreshActivity, seedDatabase, PROFILE, HISTORY_DAYS };
