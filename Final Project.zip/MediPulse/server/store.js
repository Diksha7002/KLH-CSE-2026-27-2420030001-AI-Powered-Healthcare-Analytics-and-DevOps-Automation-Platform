// ======================================================================
// MediPulse - Data access layer
// ----------------------------------------------------------------------
// All reads/writes go through here. Every function returns the same JSON
// shapes the frontend already uses (names instead of ids), but the data
// underneath is relational and validated.
// ======================================================================

const {
  db,
  tx,
  todayISO,
  addDays,
  daysBetween,
  hashPassword,
  verifyPassword,
  getMeta
} = require("./database");


class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const APPOINTMENT_STATUSES = [
  "Upcoming",
  "Confirmed",
  "Waiting",
  "Completed",
  "Cancelled"
];

// Wards are shown in this order (any other ward is appended)
const WARD_ORDER = [
  "ICU",
  "General Medicine",
  "Emergency",
  "Pediatrics",
  "Cardiology",
  "Neurology",
  "Orthopedics"
];

const clean = (value) => (value === undefined || value === null ? "" : String(value).trim());

const isISODate = (value) =>
  /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  !Number.isNaN(new Date(`${value}T00:00:00Z`).getTime());

const pct = (part, total) => (total === 0 ? 0 : Math.round((part / total) * 100));


// ======================================================================
// LOOKUPS
// ======================================================================

const findDepartment = (name) =>
  db.prepare("SELECT id, name FROM departments WHERE name = ?").get(clean(name));

const findDoctor = (name) =>
  db
    .prepare(
      `SELECT d.id, d.name, d.department_id, dep.name AS department
       FROM doctors d JOIN departments dep ON dep.id = d.department_id
       WHERE d.name = ?`
    )
    .get(clean(name));

const findPatient = (name) =>
  db.prepare("SELECT id, name, status FROM patients WHERE name = ?").get(clean(name));


// ======================================================================
// READ: PATIENTS / DOCTORS / DEPARTMENTS
// ======================================================================

const PATIENT_SQL = `
  SELECT p.id, p.user_id, p.name, p.age, p.gender, p.phone, p.status,
         p.blood_pressure, p.heart_rate, p.created_at,
         dep.name AS department, doc.name AS doctor
  FROM patients p
  JOIN departments dep ON dep.id = p.department_id
  LEFT JOIN doctors doc ON doc.id = p.doctor_id`;

const patientShape = (r) => ({
  id: r.id,
  userId: r.user_id,
  name: r.name,
  age: r.age === null ? "Not provided" : r.age,
  gender: r.gender === null ? "Not provided" : r.gender,
  department: r.department,
  doctor: r.doctor === null ? "Not assigned" : r.doctor,
  phone: r.phone,
  status: r.status,
  bloodPressure: r.blood_pressure,
  heartRate: r.heart_rate,
  createdAt: r.created_at
});

const listPatients = () =>
  db.prepare(`${PATIENT_SQL} ORDER BY p.id`).all().map(patientShape);

const getPatient = (id) => {
  const row = db.prepare(`${PATIENT_SQL} WHERE p.id = ?`).get(id);
  return row ? patientShape(row) : null;
};

const listDoctors = () =>
  db
    .prepare(
      `SELECT d.id, d.name, dep.name AS department
       FROM doctors d JOIN departments dep ON dep.id = d.department_id
       ORDER BY d.id`
    )
    .all()
    .map((r) => ({ id: r.id, name: r.name, department: r.department }));

// Counts are computed from real rows - never typed in by hand
const listDepartments = () =>
  db
    .prepare(
      `SELECT dep.id, dep.name,
         (SELECT COUNT(*) FROM doctors  d WHERE d.department_id = dep.id) AS doctorCount,
         (SELECT COUNT(*) FROM patients p WHERE p.department_id = dep.id) AS patientCount
       FROM departments dep ORDER BY dep.id`
    )
    .all()
    .map((r) => ({
      id: r.id,
      name: r.name,
      doctorCount: r.doctorCount,
      patientCount: r.patientCount
    }));


// ======================================================================
// READ: BEDS / ADMISSIONS
// ======================================================================

const listBeds = () =>
  db
    .prepare(
      `SELECT b.id, b.bed_number, b.status, dep.name AS department, p.name AS patient
       FROM beds b
       JOIN departments dep ON dep.id = b.department_id
       LEFT JOIN admissions a ON a.bed_id = b.id AND a.status = 'Admitted'
       LEFT JOIN patients p ON p.id = a.patient_id
       ORDER BY b.id`
    )
    .all()
    .map((r) => ({
      id: r.id,
      bedNumber: r.bed_number,
      department: r.department,
      status: r.status,
      patient: r.patient
    }));

const ADMISSION_SQL = `
  SELECT a.id, a.admitted_on, a.discharged_on, a.status,
         p.name AS patient, dep.name AS department, doc.name AS doctor,
         b.bed_number AS bed
  FROM admissions a
  JOIN patients p     ON p.id   = a.patient_id
  JOIN departments dep ON dep.id = a.department_id
  JOIN doctors doc    ON doc.id = a.doctor_id
  JOIN beds b         ON b.id   = a.bed_id`;

const admissionShape = (r) => ({
  id: r.id,
  patient: r.patient,
  department: r.department,
  doctor: r.doctor,
  bed: r.bed,
  date: r.admitted_on,
  dischargeDate: r.discharged_on,
  status: r.status
});

const listAdmissions = () =>
  db
    .prepare(
      `${ADMISSION_SQL}
       ORDER BY (a.status = 'Admitted') DESC, a.admitted_on DESC, a.id DESC`
    )
    .all()
    .map(admissionShape);

const getAdmission = (id) => {
  const row = db.prepare(`${ADMISSION_SQL} WHERE a.id = ?`).get(id);
  return row ? admissionShape(row) : null;
};


// ======================================================================
// READ: APPOINTMENTS
// ======================================================================

const APPOINTMENT_SQL = `
  SELECT a.id, a.date, a.time, a.type, a.status,
         p.name AS patient, doc.name AS doctor, dep.name AS department
  FROM appointments a
  JOIN patients p      ON p.id   = a.patient_id
  JOIN doctors doc     ON doc.id = a.doctor_id
  JOIN departments dep ON dep.id = a.department_id`;

const appointmentShape = (r) => ({
  id: r.id,
  patient: r.patient,
  doctor: r.doctor,
  department: r.department,
  date: r.date,
  time: r.time,
  type: r.type,
  status: r.status
});

// "09:30 AM", "02:00 PM" or "14:30" -> minutes since midnight
function timeToMinutes(text) {
  const match = /^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i.exec(clean(text));

  if (!match) return 0;

  let hours = Number(match[1]);
  const minutes = Number(match[2]);
  const marker = (match[3] || "").toUpperCase();

  if (marker === "PM" && hours < 12) hours += 12;
  if (marker === "AM" && hours === 12) hours = 0;

  return hours * 60 + minutes;
}

// Today and upcoming appointments first (soonest first), then past ones (latest first)
function listAppointments(patientName) {
  const today = todayISO();

  const rows = patientName
    ? db.prepare(`${APPOINTMENT_SQL} WHERE p.name = ?`).all(clean(patientName))
    : db.prepare(APPOINTMENT_SQL).all();

  return rows
    .map(appointmentShape)
    .sort((a, b) => {
      const aFuture = a.date >= today;
      const bFuture = b.date >= today;

      if (aFuture !== bFuture) return aFuture ? -1 : 1;

      if (a.date !== b.date) {
        return aFuture ? a.date.localeCompare(b.date) : b.date.localeCompare(a.date);
      }

      return timeToMinutes(a.time) - timeToMinutes(b.time) || a.id - b.id;
    });
}

const getAppointment = (id) => {
  const row = db.prepare(`${APPOINTMENT_SQL} WHERE a.id = ?`).get(id);
  return row ? appointmentShape(row) : null;
};


// ======================================================================
// READ: LABS / PRESCRIPTIONS / RECORDS
// ======================================================================

const listLabs = (patientName) => {
  const sql = `
    SELECT l.id, l.test, l.short_name, l.lab_name, l.date, l.result, l.summary, l.status,
           p.name AS patient, doc.name AS doctor
    FROM labs l
    JOIN patients p ON p.id = l.patient_id
    JOIN doctors doc ON doc.id = l.doctor_id`;

  const rows = patientName
    ? db.prepare(`${sql} WHERE p.name = ? ORDER BY l.date DESC, l.id DESC`).all(clean(patientName))
    : db.prepare(`${sql} ORDER BY l.date DESC, l.id DESC`).all();

  return rows.map((r) => ({
    id: r.id,
    patient: r.patient,
    test: r.test,
    shortName: r.short_name,
    doctor: r.doctor,
    date: r.date,
    lab: r.lab_name,
    result: r.result,
    summary: r.summary,
    status: r.status
  }));
};

const listPrescriptions = (patientName) => {
  const sql = `
    SELECT rx.id, rx.medicine, rx.dosage, rx.frequency, rx.duration, rx.instructions, rx.date,
           p.name AS patient, doc.name AS doctor, dep.name AS department
    FROM prescriptions rx
    JOIN patients p ON p.id = rx.patient_id
    JOIN doctors doc ON doc.id = rx.doctor_id
    JOIN departments dep ON dep.id = doc.department_id`;

  const rows = patientName
    ? db.prepare(`${sql} WHERE p.name = ? ORDER BY rx.date DESC, rx.id DESC`).all(clean(patientName))
    : db.prepare(`${sql} ORDER BY rx.date DESC, rx.id DESC`).all();

  const today = todayISO();

  return rows.map((r) => {
    const amount = Number((/(\d+)/.exec(r.duration) || [0, 0])[1]);
    const days = /week/i.test(r.duration) ? amount * 7 : amount;

    return {
      id: r.id,
      patient: r.patient,
      doctor: r.doctor,
      department: r.department,
      medicine: r.medicine,
      dosage: r.dosage,
      frequency: r.frequency,
      duration: r.duration,
      instructions: r.instructions,
      date: r.date,
      // Active while the course is still running
      status: addDays(r.date, days) >= today ? "Active" : "Completed"
    };
  });
};

const listRecords = (patientName) => {
  const sql = `
    SELECT r.id, r.type, r.date, r.summary,
           p.name AS patient, doc.name AS doctor, dep.name AS department
    FROM records r
    JOIN patients p ON p.id = r.patient_id
    JOIN doctors doc ON doc.id = r.doctor_id
    JOIN departments dep ON dep.id = doc.department_id`;

  const rows = patientName
    ? db.prepare(`${sql} WHERE p.name = ? ORDER BY r.date DESC, r.id DESC`).all(clean(patientName))
    : db.prepare(`${sql} ORDER BY r.date DESC, r.id DESC`).all();

  return rows.map((r) => ({
    id: r.id,
    patient: r.patient,
    type: r.type,
    doctor: r.doctor,
    department: r.department,
    date: r.date,
    summary: r.summary,
    diagnosis: r.summary,
    status: "Completed"
  }));
};


// ======================================================================
// AUTH
// ======================================================================

function login(username, password) {
  const user = db
    .prepare("SELECT id, username, password_hash, name, role FROM users WHERE username = ?")
    .get(clean(username));

  if (!user || !verifyPassword(password, user.password_hash)) {
    throw new HttpError(401, "Invalid username or password");
  }

  return { id: user.id, username: user.username, name: user.name, role: user.role };
}

function registerPatientUser({ name, username, password, age, gender }) {
  const cleanName = clean(name);
  const cleanUsername = clean(username).toLowerCase();

  if (!cleanName || !cleanUsername || !password) {
    throw new HttpError(400, "Name, username and password are required");
  }

  if (db.prepare("SELECT 1 FROM users WHERE username = ?").get(cleanUsername)) {
    throw new HttpError(409, "Username already exists");
  }

  if (findPatient(cleanName)) {
    throw new HttpError(
      409,
      `A patient named "${cleanName}" already exists. Please include a middle name or initial.`
    );
  }

  const ageNumber = clean(age) === "" ? null : Number(age);

  if (ageNumber !== null && (!Number.isInteger(ageNumber) || ageNumber < 0 || ageNumber > 120)) {
    throw new HttpError(400, "Age must be a whole number between 0 and 120");
  }

  const genderValue = ["Male", "Female", "Other"].includes(clean(gender)) ? clean(gender) : null;

  const generalMedicine = findDepartment("General Medicine");

  return tx(() => {
    const next =
      Number(
        (db
          .prepare("SELECT MAX(CAST(SUBSTR(id, 2) AS INTEGER)) AS n FROM users WHERE role = 'patient'")
          .get() || {}).n || 0
      ) + 1;

    const userId = `P${String(next).padStart(3, "0")}`;

    db.prepare(
      "INSERT INTO users (id, username, password_hash, name, role) VALUES (?, ?, ?, ?, 'patient')"
    ).run(userId, cleanUsername, hashPassword(password), cleanName);

    db.prepare(
      `INSERT INTO patients (user_id, name, age, gender, department_id, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'Active', ?)`
    ).run(userId, cleanName, ageNumber, genderValue, generalMedicine.id, todayISO());

    return { id: userId, username: cleanUsername, name: cleanName, role: "patient" };
  });
}


// ======================================================================
// WRITE: PATIENTS
// ======================================================================

function createPatient(body) {
  const name = clean(body.name);

  if (!name) throw new HttpError(400, "Patient name is required");

  if (findPatient(name)) {
    throw new HttpError(409, `A patient named "${name}" already exists`);
  }

  const department = findDepartment(body.department);

  if (!department) throw new HttpError(400, "Please choose a valid department");

  let age = null;

  if (clean(body.age) !== "") {
    age = Number(body.age);

    if (!Number.isInteger(age) || age < 0 || age > 120) {
      throw new HttpError(400, "Age must be a whole number between 0 and 120");
    }
  }

  const gender = clean(body.gender) || null;

  if (gender !== null && !["Male", "Female", "Other"].includes(gender)) {
    throw new HttpError(400, "Gender must be Male, Female or Other");
  }

  let doctorId = null;

  if (clean(body.doctor) && clean(body.doctor) !== "Not assigned") {
    const doctor = findDoctor(body.doctor);

    if (!doctor) throw new HttpError(400, `Doctor "${clean(body.doctor)}" was not found`);

    if (doctor.department_id !== department.id) {
      throw new HttpError(
        400,
        `${doctor.name} works in ${doctor.department}, not ${department.name}`
      );
    }

    doctorId = doctor.id;
  }

  const status = clean(body.status) || "Active";

  if (status === "Admitted") {
    throw new HttpError(
      400,
      "A patient becomes Admitted through the Admissions page (a bed is required). Please save as Active."
    );
  }

  if (status === "Discharged") {
    throw new HttpError(400, "A new patient cannot be Discharged - discharge happens after an admission.");
  }

  const result = db
    .prepare(
      `INSERT INTO patients (name, age, gender, phone, department_id, doctor_id, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'Active', ?)`
    )
    .run(name, age, gender, clean(body.phone) || null, department.id, doctorId, todayISO());

  return getPatient(Number(result.lastInsertRowid));
}

function deletePatient(id) {
  const patient = db.prepare("SELECT id, name, user_id FROM patients WHERE id = ?").get(id);

  if (!patient) throw new HttpError(404, "Patient not found");

  if (db.prepare("SELECT 1 FROM admissions WHERE patient_id = ? AND status = 'Admitted'").get(id)) {
    throw new HttpError(409, `${patient.name} is currently admitted. Discharge the patient first.`);
  }

  tx(() => {
    // appointments, labs, prescriptions, records and admission history are removed with the patient
    db.prepare("DELETE FROM patients WHERE id = ?").run(id);

    if (patient.user_id) {
      db.prepare("DELETE FROM users WHERE id = ?").run(patient.user_id);
    }
  });
}


// ======================================================================
// WRITE: APPOINTMENTS
// ======================================================================

function createAppointment(body) {
  const patient = findPatient(body.patient);

  if (!patient) {
    throw new HttpError(
      400,
      `Patient "${clean(body.patient)}" is not registered. Please add the patient first.`
    );
  }

  const doctor = findDoctor(body.doctor);

  if (!doctor) throw new HttpError(400, `Doctor "${clean(body.doctor)}" was not found`);

  const department = findDepartment(body.department);

  if (!department) throw new HttpError(400, "Please choose a valid department");

  if (doctor.department_id !== department.id) {
    throw new HttpError(400, `${doctor.name} works in ${doctor.department}, not ${department.name}`);
  }

  const date = clean(body.date);

  if (!isISODate(date)) throw new HttpError(400, "Please provide a valid appointment date");

  const time = clean(body.time);

  if (!time) throw new HttpError(400, "Please provide an appointment time");

  const status = clean(body.status) || "Upcoming";

  if (!APPOINTMENT_STATUSES.includes(status)) {
    throw new HttpError(400, `Status must be one of: ${APPOINTMENT_STATUSES.join(", ")}`);
  }

  const clash = db
    .prepare(
      `SELECT time FROM appointments
       WHERE doctor_id = ? AND date = ? AND status <> 'Cancelled'`
    )
    .all(doctor.id, date)
    .some((row) => timeToMinutes(row.time) === timeToMinutes(time));

  if (clash) {
    throw new HttpError(409, `${doctor.name} already has an appointment at ${time} on ${date}`);
  }

  const result = db
    .prepare(
      `INSERT INTO appointments (patient_id, doctor_id, department_id, date, time, type, status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(patient.id, doctor.id, department.id, date, time, clean(body.type) || "Consultation", status);

  return getAppointment(Number(result.lastInsertRowid));
}

function updateAppointmentStatus(id, status) {
  if (!APPOINTMENT_STATUSES.includes(clean(status))) {
    throw new HttpError(400, `Status must be one of: ${APPOINTMENT_STATUSES.join(", ")}`);
  }

  const result = db
    .prepare("UPDATE appointments SET status = ? WHERE id = ?")
    .run(clean(status), id);

  if (result.changes === 0) throw new HttpError(404, "Appointment not found");

  return getAppointment(id);
}


// ======================================================================
// WRITE: BEDS / ADMISSIONS
// ======================================================================

function updateBed(id, body) {
  const bed = db.prepare("SELECT id, status FROM beds WHERE id = ?").get(id);

  if (!bed) throw new HttpError(404, "Bed not found");

  const status = clean(body.status);

  if (status) {
    if (status === "Occupied") {
      throw new HttpError(400, "A bed becomes occupied by admitting a patient (Admissions page).");
    }

    if (!["Available", "Maintenance"].includes(status)) {
      throw new HttpError(400, "Bed status must be Available or Maintenance");
    }

    if (bed.status === "Occupied") {
      throw new HttpError(409, "Bed is occupied - discharge the patient first.");
    }

    db.prepare("UPDATE beds SET status = ? WHERE id = ?").run(status, id);
  }

  return listBeds().find((b) => b.id === id);
}

function createAdmission(body) {
  const { patient: patientName, department: departmentName, doctor: doctorName, bed: bedNumber, date } = body;

  if (!patientName || !departmentName || !doctorName || !bedNumber || !date) {
    throw new HttpError(400, "Please provide all admission details");
  }

  const patient = findPatient(patientName);

  if (!patient) {
    throw new HttpError(
      404,
      `Patient "${clean(patientName)}" is not registered. Please add the patient first.`
    );
  }

  const doctor = findDoctor(doctorName);

  if (!doctor) throw new HttpError(404, `Doctor "${clean(doctorName)}" was not found`);

  const department = findDepartment(departmentName);

  if (!department) throw new HttpError(404, "Department not found");

  const bed = db
    .prepare("SELECT id, bed_number, status FROM beds WHERE bed_number = ?")
    .get(clean(bedNumber));

  if (!bed) throw new HttpError(404, "Bed not found");

  if (bed.status === "Occupied") throw new HttpError(400, "Selected bed is already occupied");

  if (bed.status === "Maintenance") throw new HttpError(400, "Selected bed is under maintenance");

  if (patient.status === "Admitted") {
    throw new HttpError(409, `${patient.name} is already admitted`);
  }

  const admittedOn = clean(date);

  if (!isISODate(admittedOn)) throw new HttpError(400, "Please provide a valid admission date");

  if (admittedOn > todayISO()) {
    throw new HttpError(400, "Admission date cannot be in the future");
  }

  const result = db
    .prepare(
      `INSERT INTO admissions (patient_id, doctor_id, department_id, bed_id, admitted_on, status)
       VALUES (?, ?, ?, ?, ?, 'Admitted')`
    )
    .run(patient.id, doctor.id, department.id, bed.id, admittedOn);
  // triggers: bed -> Occupied, patient -> Admitted

  return getAdmission(Number(result.lastInsertRowid));
}

function dischargeAdmission(id) {
  const admission = db
    .prepare("SELECT id, admitted_on, status FROM admissions WHERE id = ?")
    .get(id);

  if (!admission) throw new HttpError(404, "Admission not found");

  if (admission.status === "Discharged") {
    throw new HttpError(400, "This patient has already been discharged");
  }

  const today = todayISO();
  const dischargedOn = today < admission.admitted_on ? admission.admitted_on : today;

  db.prepare(
    "UPDATE admissions SET status = 'Discharged', discharged_on = ? WHERE id = ?"
  ).run(dischargedOn, id);
  // triggers: bed -> Available, patient -> Discharged

  return getAdmission(id);
}


// ======================================================================
// DASHBOARD
// ======================================================================

const weekday = (iso) =>
  new Date(`${iso}T00:00:00Z`).toLocaleDateString("en-US", {
    weekday: "short",
    timeZone: "UTC"
  });

// Visits per day (cancelled appointments are not visits). The Dashboard chart and
// the Predictions chart both use this same data.
function visitsByDay(fromISO, toISO) {
  const rows = db
    .prepare(
      `SELECT date, COUNT(*) AS visits FROM appointments
       WHERE status <> 'Cancelled' AND date BETWEEN ? AND ?
       GROUP BY date`
    )
    .all(fromISO, toISO);

  const byDate = new Map(rows.map((r) => [r.date, r.visits]));
  const days = [];

  for (let d = fromISO; d <= toISO; d = addDays(d, 1)) {
    days.push({ date: d, visits: byDate.get(d) || 0 });
  }

  return days;
}

function dashboardStats() {
  const today = todayISO();

  const totalPatients = db.prepare("SELECT COUNT(*) AS n FROM patients").get().n;
  const todayAppointments = db
    .prepare("SELECT COUNT(*) AS n FROM appointments WHERE date = ?")
    .get(today).n;
  const totalBeds = db.prepare("SELECT COUNT(*) AS n FROM beds").get().n;
  const occupiedBeds = db
    .prepare("SELECT COUNT(*) AS n FROM beds WHERE status = 'Occupied'")
    .get().n;
  const admissions = db
    .prepare("SELECT COUNT(*) AS n FROM admissions WHERE status = 'Admitted'")
    .get().n;

  const beds = listBeds();
  const wardNames = [
    ...WARD_ORDER.filter((w) => beds.some((b) => b.department === w)),
    ...[...new Set(beds.map((b) => b.department))].filter((w) => !WARD_ORDER.includes(w))
  ];

  const bedOccupancy = wardNames.map((department) => {
    const wardBeds = beds.filter((b) => b.department === department);
    const occupied = wardBeds.filter((b) => b.status === "Occupied").length;

    return {
      department,
      occupied,
      total: wardBeds.length,
      percentage: pct(occupied, wardBeds.length)
    };
  });

  // last 7 completed days
  const yesterday = addDays(today, -1);

  const patientFlow = visitsByDay(addDays(yesterday, -6), yesterday).map((d) => ({
    day: weekday(d.date),
    patients: d.visits
  }));

  return {
    totalPatients,
    todayAppointments,
    occupiedBeds,
    totalBeds,
    occupancy: pct(occupiedBeds, totalBeds),
    admissions,
    bedOccupancy,
    patientFlow
  };
}


// ======================================================================
// ML HISTORY (sent to the Python prediction service)
// ----------------------------------------------------------------------
// One row per ward per day, built from the real admissions / appointments
// tables, in the same columns the model was trained on.
// ======================================================================

function mlHistory(days = 21) {
  const end = addDays(todayISO(), -1);
  const start = addDays(end, -(days - 1));

  const wards = db
    .prepare(
      `SELECT dep.id, dep.name, COUNT(b.id) AS total
       FROM departments dep JOIN beds b ON b.department_id = dep.id
       GROUP BY dep.id ORDER BY dep.id`
    )
    .all();

  const admissions = db
    .prepare(
      `SELECT a.admitted_on, a.discharged_on, b.department_id
       FROM admissions a JOIN beds b ON b.id = a.bed_id
       WHERE a.admitted_on <= ? AND (a.discharged_on IS NULL OR a.discharged_on >= ?)`
    )
    .all(end, start);

  const visits = db
    .prepare(
      `SELECT date, department_id, type FROM appointments
       WHERE status <> 'Cancelled' AND date BETWEEN ? AND ?`
    )
    .all(start, end);

  const rows = [];

  wards.forEach((ward) => {
    const wardAdmissions = admissions.filter((a) => a.department_id === ward.id);
    const wardVisits = visits.filter((v) => v.department_id === ward.id);

    const stays = wardAdmissions
      .filter((a) => a.discharged_on)
      .map((a) => Math.max(1, daysBetween(a.admitted_on, a.discharged_on)));
    const windowStay = stays.length ? stays.reduce((s, n) => s + n, 0) / stays.length : 3;

    for (let d = start; d <= end; d = addDays(d, 1)) {
      const occupied = wardAdmissions.filter(
        (a) => a.admitted_on <= d && (a.discharged_on === null || a.discharged_on > d)
      ).length;

      const discharged = wardAdmissions.filter((a) => a.discharged_on === d);
      const dayVisits = wardVisits.filter((v) => v.date === d);
      const emergency = dayVisits.filter((v) => v.type === "Emergency").length;

      const stay = discharged.length
        ? discharged.reduce((s, a) => s + Math.max(1, daysBetween(a.admitted_on, a.discharged_on)), 0) /
          discharged.length
        : windowStay;

      rows.push({
        date: d,
        department: ward.name,
        total_beds: ward.total,
        occupied_beds: occupied,
        admissions: wardAdmissions.filter((a) => a.admitted_on === d).length,
        discharges: discharged.length,
        emergency_cases: emergency,
        appointments: dayVisits.length - emergency,
        patient_visits: dayVisits.length,
        average_stay: Math.round(stay * 100) / 100,
        occupancy_rate: Math.round((occupied / ward.total) * 10000) / 100
      });
    }
  });

  return rows;
}


// ======================================================================
// SNAPSHOT (used by the reports / AI assistant module)
// ======================================================================

function snapshot() {
  return {
    patients: listPatients(),
    doctors: listDoctors(),
    departments: listDepartments(),
    appointments: listAppointments(),
    beds: listBeds(),
    admissions: listAdmissions(),
    labs: listLabs(),
    prescriptions: listPrescriptions(),
    records: listRecords()
  };
}


// ======================================================================
// INTEGRITY REPORT (database health - also used by `npm run db:check`)
// ======================================================================

function integrityReport() {
  const one = (sql, ...params) => db.prepare(sql).get(...params).n;
  const checks = [];

  const add = (name, ok, detail) => checks.push({ name, ok, detail });

  const occupiedBeds = one("SELECT COUNT(*) AS n FROM beds WHERE status = 'Occupied'");
  const activeAdmissions = one("SELECT COUNT(*) AS n FROM admissions WHERE status = 'Admitted'");
  const admittedPatients = one("SELECT COUNT(*) AS n FROM patients WHERE status = 'Admitted'");

  add(
    "Occupied beds = active admissions = admitted patients",
    occupiedBeds === activeAdmissions && activeAdmissions === admittedPatients,
    `${occupiedBeds} occupied beds, ${activeAdmissions} active admissions, ${admittedPatients} admitted patients`
  );

  const orphanBeds = one(
    `SELECT COUNT(*) AS n FROM beds b WHERE b.status = 'Occupied'
     AND NOT EXISTS (SELECT 1 FROM admissions a WHERE a.bed_id = b.id AND a.status = 'Admitted')`
  );
  add("Every occupied bed has an admitted patient", orphanBeds === 0, `${orphanBeds} occupied beds without a patient`);

  const wrongPatientStatus = one(
    `SELECT COUNT(*) AS n FROM patients p
     WHERE (p.status = 'Admitted') <>
           EXISTS (SELECT 1 FROM admissions a WHERE a.patient_id = p.id AND a.status = 'Admitted')`
  );
  add(
    "Patient status matches admissions",
    wrongPatientStatus === 0,
    `${wrongPatientStatus} patients with a wrong Admitted status`
  );

  const fkProblems = db.prepare("PRAGMA foreign_key_check").all().length;
  add("All foreign keys point to real rows", fkProblems === 0, `${fkProblems} broken references`);

  const doctorMismatch = one(
    `SELECT COUNT(*) AS n FROM appointments a JOIN doctors d ON d.id = a.doctor_id
     WHERE d.department_id <> a.department_id`
  );
  add(
    "Appointment doctor belongs to the appointment department",
    doctorMismatch === 0,
    `${doctorMismatch} mismatches`
  );

  const stale = one(
    `SELECT COUNT(*) AS n FROM appointments
     WHERE date < ? AND status IN ('Upcoming', 'Confirmed', 'Waiting')`,
    todayISO()
  );
  add("No past appointment is still Upcoming/Confirmed/Waiting", stale === 0, `${stale} stale appointments`);

  const departmentSums = listDepartments();
  const patientTotal = one("SELECT COUNT(*) AS n FROM patients");
  const doctorTotal = one("SELECT COUNT(*) AS n FROM doctors");

  add(
    "Department patient counts add up to total patients",
    departmentSums.reduce((s, d) => s + d.patientCount, 0) === patientTotal,
    `${patientTotal} patients in total`
  );
  add(
    "Department doctor counts add up to total doctors",
    departmentSums.reduce((s, d) => s + d.doctorCount, 0) === doctorTotal,
    `${doctorTotal} doctors in total`
  );

  const stats = dashboardStats();
  const flowTotal = stats.patientFlow.reduce((s, d) => s + d.patients, 0);
  const history = mlHistory(7);
  const historyTotal = history.reduce((s, r) => s + r.patient_visits, 0);

  add(
    "Dashboard patient flow = visits sent to the prediction model",
    flowTotal === historyTotal,
    `dashboard ${flowTotal} vs model input ${historyTotal} visits (last 7 days)`
  );

  return { ok: checks.every((c) => c.ok), checks };
}

function databaseOverview() {
  const tables = [
    "departments",
    "doctors",
    "users",
    "patients",
    "beds",
    "admissions",
    "appointments",
    "labs",
    "prescriptions",
    "records"
  ];

  return {
    engine: "SQLite",
    file: require("./database").DB_FILE,
    lastSimulatedDate: getMeta("last_simulated_date"),
    tables: tables.map((table) => ({
      table,
      rows: db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get().n
    })),
    integrity: integrityReport()
  };
}


module.exports = {
  HttpError,
  APPOINTMENT_STATUSES,
  WARD_ORDER,
  login,
  registerPatientUser,
  listPatients,
  getPatient,
  createPatient,
  deletePatient,
  listDoctors,
  listDepartments,
  listBeds,
  updateBed,
  listAdmissions,
  createAdmission,
  dischargeAdmission,
  listAppointments,
  createAppointment,
  updateAppointmentStatus,
  listLabs,
  listPrescriptions,
  listRecords,
  dashboardStats,
  visitsByDay,
  mlHistory,
  snapshot,
  integrityReport,
  databaseOverview
};
